import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { User } from "@/types/user";

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  token: string | null;
  login: (email: string, password: string) => Promise<void>;
  signup: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  updateUser: (user: User) => void;
}

// Mock user data with complete profile
const mockUser: User = {
  id: "user-1",
  name: "John Doe",
  email: "john.doe@example.com",
  phone: "+1 (555) 123-4567",
  avatar: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
  bio: "Passionate about fitness and healthy living. I enjoy hiking, cooking, and spending time with my family.",
  dateOfBirth: "1985-06-15",
  gender: "Male",
  addresses: [
    {
      id: "address-1",
      name: "Home",
      street: "123 Main St",
      city: "Panama City",
      state: "Panama",
      zipCode: "00000",
      country: "Panama",
      isDefault: true,
      latitude: 8.9824,
      longitude: -79.5199,
    },
    {
      id: "address-2",
      name: "Work",
      street: "456 Business Ave",
      city: "Panama City",
      state: "Panama",
      zipCode: "00000",
      country: "Panama",
      isDefault: false,
      latitude: 8.9758,
      longitude: -79.5308,
    }
  ],
};

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      // Start with user logged in for demo purposes
      user: mockUser,
      isAuthenticated: true,
      token: "mock-jwt-token",
      login: async (email, password) => {
        // In a real app, this would make an API call to authenticate
        // For now, we'll just simulate a successful login with mock data
        set({
          user: mockUser,
          isAuthenticated: true,
          token: "mock-jwt-token",
        });
      },
      signup: async (name, email, password) => {
        // In a real app, this would make an API call to register a new user
        // For now, we'll just simulate a successful signup with mock data
        const newUser = {
          ...mockUser,
          id: "user-" + Date.now(),
          name,
          email,
        };
        
        set({
          user: newUser,
          isAuthenticated: true,
          token: "mock-jwt-token",
        });
      },
      logout: () => {
        set({
          user: null,
          isAuthenticated: false,
          token: null,
        });
      },
      updateUser: (updatedUser) => {
        set({
          user: updatedUser,
        });
      },
    }),
    {
      name: "auth-storage",
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);