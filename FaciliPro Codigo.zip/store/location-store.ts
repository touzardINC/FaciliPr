import { create } from "zustand";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { persist, createJSONStorage } from "zustand/middleware";
import * as Location from "expo-location";

interface LocationState {
  currentLocation: {
    latitude: number;
    longitude: number;
    address: string;
  } | null;
  savedLocations: {
    id: string;
    name: string;
    address: string;
    latitude: number;
    longitude: number;
    isDefault: boolean;
  }[];
  isLoading: boolean;
  error: string | null;
  setCurrentLocation: (location: {
    latitude: number;
    longitude: number;
    address: string;
  }) => void;
  getCurrentLocation: () => Promise<void>;
  addSavedLocation: (location: {
    name: string;
    address: string;
    latitude: number;
    longitude: number;
    isDefault?: boolean;
  }) => void;
  removeSavedLocation: (id: string) => void;
  setDefaultLocation: (id: string) => void;
}

// Default locations for demo
const defaultLocations = [
  {
    id: "loc1",
    name: "Home",
    address: "123 Main St, Panama City, Panama",
    latitude: 8.9824,
    longitude: -79.5199,
    isDefault: true,
  },
  {
    id: "loc2",
    name: "Work",
    address: "456 Business Ave, Panama City, Panama",
    latitude: 8.9758,
    longitude: -79.5308,
    isDefault: false,
  },
];

export const useLocationStore = create<LocationState>()(
  persist(
    (set, get) => ({
      currentLocation: null,
      savedLocations: defaultLocations,
      isLoading: false,
      error: null,

      setCurrentLocation: (location) => {
        set({ currentLocation: location });
      },

      getCurrentLocation: async () => {
        set({ isLoading: true, error: null });

        try {
          const { status } = await Location.requestForegroundPermissionsAsync();
          
          if (status !== "granted") {
            set({
              isLoading: false,
              error: "Permission to access location was denied",
            });
            return;
          }

          const location = await Location.getCurrentPositionAsync({
            accuracy: Location.Accuracy.Balanced,
          });

          // Reverse geocode to get address
          const addressResponse = await Location.reverseGeocodeAsync({
            latitude: location.coords.latitude,
            longitude: location.coords.longitude,
          });

          let address = "Unknown location";
          if (addressResponse && addressResponse.length > 0) {
            const addressObj = addressResponse[0];
            address = `${addressObj.street || ""} ${addressObj.name || ""}, ${
              addressObj.city || ""
            }, ${addressObj.region || ""}, ${addressObj.country || ""}`.trim();
          }

          set({
            currentLocation: {
              latitude: location.coords.latitude,
              longitude: location.coords.longitude,
              address,
            },
            isLoading: false,
          });
        } catch (error) {
          set({
            isLoading: false,
            error: "Could not fetch location. Please try again.",
          });
        }
      },

      addSavedLocation: (location) => {
        const newLocation = {
          id: `loc_${Date.now()}`,
          name: location.name,
          address: location.address,
          latitude: location.latitude,
          longitude: location.longitude,
          isDefault: location.isDefault || false,
        };

        set((state) => {
          let updatedLocations = [...state.savedLocations];
          
          // If the new location is set as default, update all others
          if (newLocation.isDefault) {
            updatedLocations = updatedLocations.map((loc) => ({
              ...loc,
              isDefault: false,
            }));
          }
          
          return {
            savedLocations: [...updatedLocations, newLocation],
          };
        });
      },

      removeSavedLocation: (id) => {
        set((state) => {
          const updatedLocations = state.savedLocations.filter(
            (loc) => loc.id !== id
          );
          
          // If we removed the default location and there are other locations,
          // make the first one the default
          if (
            state.savedLocations.find((loc) => loc.id === id)?.isDefault &&
            updatedLocations.length > 0
          ) {
            updatedLocations[0].isDefault = true;
          }
          
          return {
            savedLocations: updatedLocations,
          };
        });
      },

      setDefaultLocation: (id) => {
        set((state) => ({
          savedLocations: state.savedLocations.map((loc) => ({
            ...loc,
            isDefault: loc.id === id,
          })),
        }));
      },
    }),
    {
      name: "location-storage",
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);