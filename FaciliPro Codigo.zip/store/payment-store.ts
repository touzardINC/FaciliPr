import { create } from "zustand";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { persist, createJSONStorage } from "zustand/middleware";
import { PaymentMethod, Transaction } from "@/types/payment";
import { paymentMethods as mockPaymentMethods } from "@/mocks/payments";

interface PaymentState {
  paymentMethods: PaymentMethod[];
  transactions: Transaction[];
  isLoading: boolean;
  getPaymentMethods: () => Promise<void>;
  addPaymentMethod: (paymentMethod: Omit<PaymentMethod, "id">) => Promise<PaymentMethod>;
  removePaymentMethod: (id: string) => Promise<void>;
  setDefaultPaymentMethod: (id: string) => Promise<void>;
  processPayment: (
    bookingId: string,
    amount: number,
    paymentMethodId: string
  ) => Promise<Transaction>;
}

// Sample transactions for demo
const sampleTransactions: Transaction[] = [
  {
    id: "txn_123456",
    userId: "user-1",
    bookingId: "booking-1",
    amount: 35,
    currency: "USD",
    status: "completed",
    paymentMethodId: "pm_1",
    createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days ago
    updatedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: "txn_234567",
    userId: "user-1",
    bookingId: "booking-2",
    amount: 80,
    currency: "USD",
    status: "completed",
    paymentMethodId: "pm_1",
    createdAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(), // 14 days ago
    updatedAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: "txn_345678",
    userId: "user-1",
    bookingId: "booking-3",
    amount: 120,
    currency: "USD",
    status: "completed",
    paymentMethodId: "pm_2",
    createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days ago
    updatedAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
  },
];

export const usePaymentStore = create<PaymentState>()(
  persist(
    (set, get) => ({
      // Initialize with mock payment methods for demo
      paymentMethods: mockPaymentMethods,
      transactions: sampleTransactions,
      isLoading: false,
      
      getPaymentMethods: async () => {
        set({ isLoading: true });
        
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000));
        
        // In a real app, you would fetch from an API
        set({ paymentMethods: mockPaymentMethods, isLoading: false });
      },
      
      addPaymentMethod: async (paymentMethodData) => {
        set({ isLoading: true });
        
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000));
        
        const newPaymentMethod: PaymentMethod = {
          ...paymentMethodData,
          id: `pm_${Date.now()}`,
        };
        
        set((state) => {
          // If this is the first payment method or marked as default, make it default
          // and ensure all others are not default
          if (newPaymentMethod.isDefault || state.paymentMethods.length === 0) {
            return {
              paymentMethods: [
                ...state.paymentMethods.map(pm => ({ ...pm, isDefault: false })),
                { ...newPaymentMethod, isDefault: true }
              ],
              isLoading: false,
            };
          }
          
          return {
            paymentMethods: [...state.paymentMethods, newPaymentMethod],
            isLoading: false,
          };
        });
        
        return newPaymentMethod;
      },
      
      removePaymentMethod: async (id) => {
        set({ isLoading: true });
        
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000));
        
        set((state) => {
          const updatedPaymentMethods = state.paymentMethods.filter(
            (pm) => pm.id !== id
          );
          
          // If we removed the default payment method, make another one default
          if (state.paymentMethods.find(pm => pm.id === id)?.isDefault && 
              updatedPaymentMethods.length > 0) {
            updatedPaymentMethods[0].isDefault = true;
          }
          
          return {
            paymentMethods: updatedPaymentMethods,
            isLoading: false,
          };
        });
      },
      
      setDefaultPaymentMethod: async (id) => {
        set({ isLoading: true });
        
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000));
        
        set((state) => ({
          paymentMethods: state.paymentMethods.map((pm) => ({
            ...pm,
            isDefault: pm.id === id,
          })),
          isLoading: false,
        }));
      },
      
      processPayment: async (bookingId, amount, paymentMethodId) => {
        set({ isLoading: true });
        
        // Simulate API call with payment processing
        await new Promise((resolve) => setTimeout(resolve, 2000));
        
        const transaction: Transaction = {
          id: `txn_${Date.now()}`,
          userId: "user-1", // In a real app, get this from auth store
          bookingId,
          amount,
          currency: "USD",
          status: "completed",
          paymentMethodId,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        
        set((state) => ({
          transactions: [...state.transactions, transaction],
          isLoading: false,
        }));
        
        return transaction;
      },
    }),
    {
      name: "payment-storage",
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);