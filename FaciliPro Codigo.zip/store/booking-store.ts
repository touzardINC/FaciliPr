import { create } from "zustand";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { persist, createJSONStorage } from "zustand/middleware";
import { Booking, BookingStatus } from "@/types/booking";
import { bookings as mockBookings } from "@/mocks/bookings";

interface BookingState {
  bookings: Booking[];
  isLoading: boolean;
  getBookings: () => Promise<void>;
  addBooking: (booking: Omit<Booking, "id" | "createdAt">) => Promise<Booking>;
  updateBookingStatus: (id: string, status: BookingStatus) => Promise<void>;
  addReview: (bookingId: string, rating: number, comment: string) => Promise<void>;
}

// Add a confirmed booking for demo purposes
const confirmedBooking: Booking = {
  id: "4",
  userId: "user1",
  professionalId: "5",
  serviceId: "1",
  date: "2023-11-18",
  time: "13:00",
  status: "confirmed",
  price: 70,
  address: "Calle 50, Panama City",
  notes: "Need to repair a broken chair leg",
  createdAt: "2023-11-15T10:30:00Z",
};

// Add all bookings including the confirmed one
const allBookings = [...mockBookings, confirmedBooking];

export const useBookingStore = create<BookingState>()(
  persist(
    (set, get) => ({
      bookings: allBookings,
      isLoading: false,
      
      getBookings: async () => {
        set({ isLoading: true });
        
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000));
        
        // In a real app, you would fetch from an API
        set({ bookings: allBookings, isLoading: false });
      },
      
      addBooking: async (bookingData) => {
        set({ isLoading: true });
        
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000));
        
        const newBooking: Booking = {
          ...bookingData,
          id: `booking-${Date.now()}`,
          createdAt: new Date().toISOString(),
        };
        
        set((state) => ({
          bookings: [...state.bookings, newBooking],
          isLoading: false,
        }));
        
        return newBooking;
      },
      
      updateBookingStatus: async (id, status) => {
        set({ isLoading: true });
        
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000));
        
        set((state) => ({
          bookings: state.bookings.map((booking) =>
            booking.id === id ? { ...booking, status } : booking
          ),
          isLoading: false,
        }));
      },
      
      addReview: async (bookingId, rating, comment) => {
        set({ isLoading: true });
        
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000));
        
        set((state) => ({
          bookings: state.bookings.map((booking) =>
            booking.id === bookingId
              ? {
                  ...booking,
                  status: "completed" as BookingStatus,
                  review: {
                    rating,
                    comment,
                    date: new Date().toISOString(),
                  },
                }
              : booking
          ),
          isLoading: false,
        }));
      },
    }),
    {
      name: "booking-storage",
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);