import React from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { Category } from "@/types/category";
import Colors from "@/constants/colors";
import { 
  Droplet, 
  Flower, 
  Zap, 
  SprayCan, 
  Hammer, 
  Paintbrush, 
  HelpCircle,
  Utensils,
  Wrench,
  Music,
  Palette,
  BookOpen,
  Scissors
} from "lucide-react-native";

interface CategoryCardProps {
  category: Category;
  onPress: (category: Category) => void;
  isSelected?: boolean;
}

// Map category icon names to actual icon components
const getCategoryIcon = (iconName: string) => {
  switch (iconName) {
    case "droplet":
      return <Droplet color={Colors.white} size={24} />;
    case "flower":
      return <Flower color={Colors.white} size={24} />;
    case "zap":
      return <Zap color={Colors.white} size={24} />;
    case "spray-can":
      return <SprayCan color={Colors.white} size={24} />;
    case "hammer":
      return <Hammer color={Colors.white} size={24} />;
    case "paintbrush":
      return <Paintbrush color={Colors.white} size={24} />;
    case "utensils":
      return <Utensils color={Colors.white} size={24} />;
    case "wrench":
      return <Wrench color={Colors.white} size={24} />;
    case "music":
      return <Music color={Colors.white} size={24} />;
    case "palette":
      return <Palette color={Colors.white} size={24} />;
    case "book-open":
      return <BookOpen color={Colors.white} size={24} />;
    case "scissors":
      return <Scissors color={Colors.white} size={24} />;
    default:
      return <HelpCircle color={Colors.white} size={24} />;
  }
};

export default function CategoryCard({
  category,
  onPress,
  isSelected = false,
}: CategoryCardProps) {
  return (
    <TouchableOpacity
      style={[
        styles.container,
        isSelected && styles.selectedContainer,
        { borderColor: category.color },
      ]}
      onPress={() => onPress(category)}
      activeOpacity={0.7}
    >
      <View style={[styles.iconContainer, { backgroundColor: category.color }]}>
        {getCategoryIcon(category.icon)}
      </View>
      <Text style={styles.name}>{category.name}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    width: 100,
    height: 100,
    borderRadius: 12,
    padding: 12,
    backgroundColor: Colors.white,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 12,
    shadowColor: Colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    borderWidth: 2,
    borderColor: "transparent",
  },
  selectedContainer: {
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8,
  },
  name: {
    fontSize: 14,
    fontWeight: "500",
    color: Colors.text.primary,
    textAlign: "center",
  },
});