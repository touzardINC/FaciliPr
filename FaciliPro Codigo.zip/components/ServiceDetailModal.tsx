import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  Modal,
  TouchableOpacity,
  ScrollView,
  Image,
  Dimensions,
} from "react-native";
import { X, Clock, DollarSign } from "lucide-react-native";
import Colors from "@/constants/colors";
import { Service, ServiceMedia } from "@/types/professional";
import Button from "@/components/Button";
import MediaGallery from "@/components/MediaGallery";

interface ServiceDetailModalProps {
  visible: boolean;
  service: Service | null;
  onClose: () => void;
  onBook: (service: Service) => void;
}

const { width } = Dimensions.get("window");

export default function ServiceDetailModal({
  visible,
  service,
  onClose,
  onBook,
}: ServiceDetailModalProps) {
  const [showFullGallery, setShowFullGallery] = useState(false);
  const [initialMediaIndex, setInitialMediaIndex] = useState(0);

  if (!service) return null;

  // Convert legacy imageUrl to media format if needed
  const serviceMedia: ServiceMedia[] = service.media || 
    (service.imageUrl ? [{ id: "legacy", type: "image", url: service.imageUrl }] : []);

  const handleMediaPress = (index: number) => {
    setInitialMediaIndex(index);
    setShowFullGallery(true);
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={onClose}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContainer}>
          <TouchableOpacity style={styles.closeButton} onPress={onClose}>
            <X size={24} color={Colors.text.primary} />
          </TouchableOpacity>

          <ScrollView showsVerticalScrollIndicator={false}>
            {serviceMedia.length > 0 ? (
              <TouchableOpacity 
                activeOpacity={0.9}
                onPress={() => setShowFullGallery(true)}
              >
                <MediaGallery media={serviceMedia} />
              </TouchableOpacity>
            ) : (
              <View style={styles.noMediaContainer}>
                <Text style={styles.noMediaText}>No images available</Text>
              </View>
            )}

            <View style={styles.serviceContent}>
              <Text style={styles.serviceName}>{service.name}</Text>
              
              <View style={styles.serviceMetaContainer}>
                <View style={styles.serviceMeta}>
                  <DollarSign size={16} color={Colors.primary} />
                  <Text style={styles.serviceMetaText}>${service.price}</Text>
                </View>
                
                {service.duration && (
                  <View style={styles.serviceMeta}>
                    <Clock size={16} color={Colors.primary} />
                    <Text style={styles.serviceMetaText}>{service.duration}</Text>
                  </View>
                )}
              </View>
              
              <Text style={styles.descriptionTitle}>Description</Text>
              <Text style={styles.description}>{service.description}</Text>
              
              <Button
                title="Book This Service"
                onPress={() => {
                  onBook(service);
                  onClose();
                }}
                style={styles.bookButton}
              />
            </View>
          </ScrollView>
        </View>
      </View>

      {/* Full screen media gallery */}
      <Modal
        visible={showFullGallery}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowFullGallery(false)}
      >
        <View style={styles.fullGalleryContainer}>
          <MediaGallery 
            media={serviceMedia} 
            onClose={() => setShowFullGallery(false)} 
            fullscreen={true}
            initialIndex={initialMediaIndex}
          />
        </View>
      </Modal>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "flex-end",
  },
  modalContainer: {
    backgroundColor: Colors.white,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    maxHeight: "90%",
  },
  closeButton: {
    position: "absolute",
    top: 16,
    right: 16,
    zIndex: 10,
    backgroundColor: Colors.white,
    borderRadius: 20,
    padding: 8,
    shadowColor: Colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },
  noMediaContainer: {
    height: 250,
    backgroundColor: Colors.background,
    justifyContent: "center",
    alignItems: "center",
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  noMediaText: {
    color: Colors.text.secondary,
    fontSize: 16,
  },
  serviceContent: {
    padding: 20,
    paddingBottom: 40,
  },
  serviceName: {
    fontSize: 24,
    fontWeight: "700",
    color: Colors.text.primary,
    marginBottom: 12,
  },
  serviceMetaContainer: {
    flexDirection: "row",
    marginBottom: 20,
  },
  serviceMeta: {
    flexDirection: "row",
    alignItems: "center",
    marginRight: 20,
  },
  serviceMetaText: {
    fontSize: 16,
    color: Colors.text.secondary,
    marginLeft: 6,
    fontWeight: "500",
  },
  descriptionTitle: {
    fontSize: 18,
    fontWeight: "600",
    color: Colors.text.primary,
    marginBottom: 8,
  },
  description: {
    fontSize: 16,
    color: Colors.text.primary,
    lineHeight: 24,
    marginBottom: 24,
  },
  bookButton: {
    marginTop: 16,
  },
  fullGalleryContainer: {
    flex: 1,
    backgroundColor: "black",
  },
});