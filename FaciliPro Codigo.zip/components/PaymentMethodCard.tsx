import React from "react";
import { StyleSheet, Text, View, TouchableOpacity } from "react-native";
import { PaymentMethod } from "@/types/payment";
import Colors from "@/constants/colors";
import { CreditCard, CheckCircle, Trash2 } from "lucide-react-native";

interface PaymentMethodCardProps {
  paymentMethod: PaymentMethod;
  onSelect?: (paymentMethod: PaymentMethod) => void;
  onDelete?: (id: string) => void;
  onSetDefault?: (id: string) => void;
  isSelected?: boolean;
  showActions?: boolean;
}

export default function PaymentMethodCard({
  paymentMethod,
  onSelect,
  onDelete,
  onSetDefault,
  isSelected = false,
  showActions = true,
}: PaymentMethodCardProps) {
  const getCardIcon = () => {
    switch (paymentMethod.brand?.toLowerCase()) {
      case "visa":
        return <CreditCard size={24} color={Colors.primary} />;
      case "mastercard":
        return <CreditCard size={24} color={Colors.primary} />;
      case "paypal":
        return <CreditCard size={24} color={Colors.primary} />;
      default:
        return <CreditCard size={24} color={Colors.primary} />;
    }
  };

  return (
    <TouchableOpacity
      style={[
        styles.container,
        isSelected && styles.selectedContainer,
        paymentMethod.isDefault && styles.defaultContainer,
      ]}
      onPress={() => onSelect && onSelect(paymentMethod)}
      disabled={!onSelect}
      activeOpacity={onSelect ? 0.7 : 1}
    >
      <View style={styles.content}>
        <View style={styles.iconContainer}>{getCardIcon()}</View>
        <View style={styles.details}>
          <Text style={styles.name}>{paymentMethod.name}</Text>
          {paymentMethod.expiryDate && (
            <Text style={styles.expiry}>Expires {paymentMethod.expiryDate}</Text>
          )}
          {paymentMethod.isDefault && (
            <View style={styles.defaultBadge}>
              <Text style={styles.defaultText}>Default</Text>
            </View>
          )}
        </View>
      </View>

      {showActions && (
        <View style={styles.actions}>
          {!paymentMethod.isDefault && onSetDefault && (
            <TouchableOpacity
              style={styles.actionButton}
              onPress={() => onSetDefault(paymentMethod.id)}
            >
              <CheckCircle size={20} color={Colors.primary} />
            </TouchableOpacity>
          )}
          {onDelete && (
            <TouchableOpacity
              style={styles.actionButton}
              onPress={() => onDelete(paymentMethod.id)}
            >
              <Trash2 size={20} color={Colors.error} />
            </TouchableOpacity>
          )}
        </View>
      )}

      {isSelected && (
        <View style={styles.selectedIndicator}>
          <CheckCircle size={20} color={Colors.white} fill={Colors.primary} />
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: Colors.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  selectedContainer: {
    borderColor: Colors.primary,
    backgroundColor: Colors.background,
  },
  defaultContainer: {
    borderColor: Colors.primary,
  },
  content: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.background,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 12,
  },
  details: {
    flex: 1,
  },
  name: {
    fontSize: 16,
    fontWeight: "500",
    color: Colors.text.primary,
    marginBottom: 4,
  },
  expiry: {
    fontSize: 14,
    color: Colors.text.secondary,
  },
  defaultBadge: {
    backgroundColor: Colors.primary,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
    alignSelf: "flex-start",
    marginTop: 4,
  },
  defaultText: {
    color: Colors.white,
    fontSize: 12,
    fontWeight: "500",
  },
  actions: {
    flexDirection: "row",
    alignItems: "center",
  },
  actionButton: {
    padding: 8,
    marginLeft: 8,
  },
  selectedIndicator: {
    position: "absolute",
    top: 12,
    right: 12,
  },
});