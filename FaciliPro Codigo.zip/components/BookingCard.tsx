import React from "react";
import { StyleSheet, Text, View, TouchableOpacity } from "react-native";
import { Booking } from "@/types/booking";
import Colors from "@/constants/colors";
import { Calendar, Clock, MapPin } from "lucide-react-native";
import { professionals } from "@/mocks/professionals";

interface BookingCardProps {
  booking: Booking;
  onPress: (booking: Booking) => void;
}

export default function BookingCard({ booking, onPress }: BookingCardProps) {
  const professional = professionals.find(p => p.id === booking.professionalId);
  const service = professional?.services.find(s => s.id === booking.serviceId);
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return Colors.primary; // Green
      case "pending":
        return Colors.accent; // Light Tan
      case "completed":
        return Colors.success; // Green
      case "cancelled":
        return Colors.red; // Red
      default:
        return Colors.text.secondary;
    }
  };

  return (
    <TouchableOpacity
      style={styles.container}
      onPress={() => onPress(booking)}
      activeOpacity={0.7}
    >
      <View style={styles.header}>
        <Text style={styles.serviceName}>{service?.name || "Service"}</Text>
        <View
          style={[
            styles.statusBadge,
            { backgroundColor: getStatusColor(booking.status) },
          ]}
        >
          <Text style={styles.statusText}>
            {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
          </Text>
        </View>
      </View>

      <View style={styles.details}>
        <View style={styles.detailRow}>
          <Calendar size={16} color={Colors.text.secondary} />
          <Text style={styles.detailText}>{booking.date}</Text>
        </View>
        
        <View style={styles.detailRow}>
          <Clock size={16} color={Colors.text.secondary} />
          <Text style={styles.detailText}>{booking.time}</Text>
        </View>
        
        <View style={styles.detailRow}>
          <MapPin size={16} color={Colors.text.secondary} />
          <Text style={styles.detailText} numberOfLines={1}>
            {booking.address}
          </Text>
        </View>
      </View>

      <View style={styles.footer}>
        <Text style={styles.professionalName}>
          {professional?.name || "Professional"}
        </Text>
        <Text style={styles.price}>${booking.price}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: Colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  serviceName: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.text.primary,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  statusText: {
    color: Colors.white,
    fontSize: 12,
    fontWeight: "500",
  },
  details: {
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  detailText: {
    fontSize: 14,
    color: Colors.text.secondary,
    marginLeft: 8,
  },
  footer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    paddingTop: 12,
  },
  professionalName: {
    fontSize: 14,
    fontWeight: "500",
    color: Colors.text.primary,
  },
  price: {
    fontSize: 16,
    fontWeight: "700",
    color: Colors.primary,
  },
});