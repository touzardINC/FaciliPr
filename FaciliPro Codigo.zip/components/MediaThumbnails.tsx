import React from "react";
import {
  StyleSheet,
  View,
  ScrollView,
  Image,
  TouchableOpacity,
  Text,
} from "react-native";
import { Play } from "lucide-react-native";
import Colors from "@/constants/colors";

interface MediaItem {
  id: string;
  type: "image" | "video";
  url: string;
  thumbnailUrl?: string;
  duration?: number;
}

interface MediaThumbnailsProps {
  media: MediaItem[];
  onPress: (index: number) => void;
  maxDisplay?: number;
}

export default function MediaThumbnails({
  media,
  onPress,
  maxDisplay = 3,
}: MediaThumbnailsProps) {
  const displayMedia = media.slice(0, maxDisplay);
  const remainingCount = media.length - maxDisplay;

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.container}
    >
      {displayMedia.map((item, index) => (
        <TouchableOpacity
          key={item.id}
          style={styles.thumbnailContainer}
          onPress={() => onPress(index)}
        >
          <Image
            source={{ uri: item.thumbnailUrl || item.url }}
            style={styles.thumbnail}
            resizeMode="cover"
          />
          {item.type === "video" && (
            <View style={styles.videoIndicator}>
              <Play size={16} color={Colors.white} fill={Colors.white} />
            </View>
          )}
        </TouchableOpacity>
      ))}
      
      {remainingCount > 0 && (
        <TouchableOpacity
          style={styles.moreContainer}
          onPress={() => onPress(maxDisplay)}
        >
          <Text style={styles.moreText}>+{remainingCount}</Text>
          <Text style={styles.moreSubtext}>more</Text>
        </TouchableOpacity>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: 8,
  },
  thumbnailContainer: {
    marginRight: 8,
    borderRadius: 8,
    overflow: "hidden",
    position: "relative",
  },
  thumbnail: {
    width: 80,
    height: 80,
    borderRadius: 8,
  },
  videoIndicator: {
    position: "absolute",
    bottom: 4,
    right: 4,
    backgroundColor: "rgba(0, 0, 0, 0.6)",
    borderRadius: 12,
    width: 24,
    height: 24,
    justifyContent: "center",
    alignItems: "center",
  },
  moreContainer: {
    width: 80,
    height: 80,
    borderRadius: 8,
    backgroundColor: Colors.background,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 1,
    borderColor: Colors.border,
  },
  moreText: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.primary,
  },
  moreSubtext: {
    fontSize: 12,
    color: Colors.text.secondary,
  },
});