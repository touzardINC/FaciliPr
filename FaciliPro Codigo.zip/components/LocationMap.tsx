import React from "react";
import { StyleSheet, View, Text, Dimensions, Platform } from "react-native";
import Colors from "@/constants/colors";
import { MapPin } from "lucide-react-native";

interface LocationMapProps {
  latitude: number;
  longitude: number;
}

export default function LocationMap({ latitude, longitude }: LocationMapProps) {
  // On web, we can't use MapView from expo-location, so we'll show a placeholder
  if (Platform.OS === "web") {
    return (
      <View style={styles.webPlaceholder}>
        <MapPin size={24} color={Colors.primary} />
        <Text style={styles.webPlaceholderText}>
          Location: {latitude.toFixed(6)}, {longitude.toFixed(6)}
        </Text>
      </View>
    );
  }

  // For native platforms, we would use MapView from react-native-maps
  // But since we can't install custom native packages, we'll use a placeholder
  return (
    <View style={styles.mapContainer}>
      <View style={styles.mapPlaceholder}>
        <MapPin size={32} color={Colors.primary} />
        <Text style={styles.mapText}>
          Location: {latitude.toFixed(6)}, {longitude.toFixed(6)}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  mapContainer: {
    width: "100%",
    height: 200,
    borderRadius: 12,
    overflow: "hidden",
    marginBottom: 16,
  },
  mapPlaceholder: {
    width: "100%",
    height: "100%",
    backgroundColor: "#e8f5e9",
    alignItems: "center",
    justifyContent: "center",
  },
  mapText: {
    marginTop: 8,
    color: Colors.text.primary,
    fontSize: 14,
  },
  webPlaceholder: {
    width: "100%",
    height: 200,
    backgroundColor: "#e8f5e9",
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 16,
  },
  webPlaceholderText: {
    marginTop: 8,
    color: Colors.text.primary,
    fontSize: 14,
  },
});