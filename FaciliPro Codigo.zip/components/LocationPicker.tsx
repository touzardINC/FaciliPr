import React, { useState, useEffect } from "react";
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Platform,
} from "react-native";
import * as Location from "expo-location";
import { MapPin, Navigation } from "lucide-react-native";
import Colors from "@/constants/colors";

interface LocationPickerProps {
  onLocationSelect: (location: {
    latitude: number;
    longitude: number;
    address: string;
  }) => void;
  initialAddress?: string;
}

export default function LocationPicker({
  onLocationSelect,
  initialAddress,
}: LocationPickerProps) {
  const [location, setLocation] = useState<Location.LocationObject | null>(null);
  const [address, setAddress] = useState<string>(initialAddress || "");
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        setErrorMsg("Permission to access location was denied");
        return;
      }
    })();
  }, []);

  const getLocationHandler = async () => {
    setIsLoading(true);
    setErrorMsg(null);

    try {
      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });
      setLocation(location);

      // Reverse geocode to get address
      const addressResponse = await Location.reverseGeocodeAsync({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      });

      if (addressResponse && addressResponse.length > 0) {
        const addressObj = addressResponse[0];
        const formattedAddress = `${addressObj.street || ""} ${
          addressObj.name || ""
        }, ${addressObj.city || ""}, ${addressObj.region || ""}, ${
          addressObj.country || ""
        }`.trim();
        
        setAddress(formattedAddress);
        
        onLocationSelect({
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
          address: formattedAddress,
        });
      }
    } catch (error) {
      setErrorMsg("Could not fetch location. Please try again.");
      Alert.alert("Error", "Failed to get your location. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.addressContainer}>
        <MapPin size={20} color={Colors.primary} />
        <Text style={styles.addressText}>
          {address || "Select your location"}
        </Text>
      </View>

      <TouchableOpacity
        style={styles.locationButton}
        onPress={getLocationHandler}
        disabled={isLoading}
      >
        {isLoading ? (
          <ActivityIndicator size="small" color={Colors.white} />
        ) : (
          <>
            <Navigation size={16} color={Colors.white} />
            <Text style={styles.locationButtonText}>Current Location</Text>
          </>
        )}
      </TouchableOpacity>

      {errorMsg && <Text style={styles.errorText}>{errorMsg}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  addressContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.white,
    borderRadius: 8,
    padding: 12,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: 8,
  },
  addressText: {
    flex: 1,
    marginLeft: 8,
    fontSize: 14,
    color: Colors.text.primary,
  },
  locationButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.primary,
    borderRadius: 8,
    padding: 12,
  },
  locationButtonText: {
    color: Colors.white,
    fontWeight: "500",
    marginLeft: 8,
  },
  errorText: {
    color: Colors.error,
    fontSize: 12,
    marginTop: 4,
  },
});