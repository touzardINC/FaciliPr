import React from "react";
import { StyleSheet, View, TouchableOpacity, Linking, Text } from "react-native";
import {
  Instagram,
  Facebook,
  Twitter,
  Linkedin,
  Youtube,
  Globe,
  ExternalLink,
  Music,
  Github,
} from "lucide-react-native";
import Colors from "@/constants/colors";
import { SocialMedia } from "@/types/professional";

interface SocialMediaLinksProps {
  socialMedia: SocialMedia[];
  size?: "small" | "medium" | "large";
  showLabels?: boolean;
}

export default function SocialMediaLinks({
  socialMedia,
  size = "medium",
  showLabels = false,
}: SocialMediaLinksProps) {
  if (!socialMedia || socialMedia.length === 0) {
    return null;
  }

  const getIconSize = () => {
    switch (size) {
      case "small":
        return 16;
      case "large":
        return 24;
      case "medium":
      default:
        return 20;
    }
  };

  const getIconColor = (platform: string) => {
    switch (platform) {
      case "instagram":
        return "#E1306C";
      case "facebook":
        return "#1877F2";
      case "twitter":
        return "#1DA1F2";
      case "linkedin":
        return "#0077B5";
      case "youtube":
        return "#FF0000";
      case "tiktok":
        return "#000000";
      case "pinterest":
        return "#BD081C";
      case "soundcloud":
        return "#FF7700";
      case "github":
        return "#333333";
      case "website":
      default:
        return Colors.primary;
    }
  };

  const getIcon = (platform: string, iconSize: number, color: string) => {
    switch (platform) {
      case "instagram":
        return <Instagram size={iconSize} color={color} />;
      case "facebook":
        return <Facebook size={iconSize} color={color} />;
      case "twitter":
        return <Twitter size={iconSize} color={color} />;
      case "linkedin":
        return <Linkedin size={iconSize} color={color} />;
      case "youtube":
        return <Youtube size={iconSize} color={color} />;
      case "tiktok":
        // Lucide doesn't have a TikTok icon, so we'll use a text alternative
        return (
          <View style={styles.tiktokIcon}>
            <Text style={[styles.tiktokText, { fontSize: iconSize * 0.7 }]}>TT</Text>
          </View>
        );
      case "pinterest":
        // Using a custom icon for Pinterest
        return (
          <View style={styles.customIcon}>
            <Text style={[styles.customIconText, { fontSize: iconSize * 0.7, color }]}>P</Text>
          </View>
        );
      case "soundcloud":
        // Using Music icon for SoundCloud
        return <Music size={iconSize} color={color} />;
      case "github":
        return <Github size={iconSize} color={color} />;
      case "website":
      default:
        return <Globe size={iconSize} color={color} />;
    }
  };

  const handlePress = (url: string) => {
    Linking.openURL(url).catch((err) => console.error("Error opening URL:", err));
  };

  const iconSize = getIconSize();

  return (
    <View style={styles.container}>
      {socialMedia.map((item, index) => (
        <TouchableOpacity
          key={`${item.platform}-${index}`}
          style={[
            styles.iconButton,
            { 
              padding: size === "small" ? 6 : size === "large" ? 10 : 8,
              marginRight: index < socialMedia.length - 1 ? 8 : 0 
            }
          ]}
          onPress={() => handlePress(item.url)}
        >
          {getIcon(item.platform, iconSize, getIconColor(item.platform))}
          {showLabels && item.username && (
            <Text style={styles.label}>{item.username}</Text>
          )}
          {showLabels && !item.username && (
            <View style={styles.externalLinkIcon}>
              <ExternalLink size={12} color={Colors.text.secondary} />
            </View>
          )}
        </TouchableOpacity>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    flexWrap: "wrap",
  },
  iconButton: {
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    marginBottom: 8,
  },
  label: {
    marginLeft: 6,
    fontSize: 14,
    color: Colors.text.secondary,
  },
  externalLinkIcon: {
    marginLeft: 4,
  },
  tiktokIcon: {
    alignItems: "center",
    justifyContent: "center",
  },
  tiktokText: {
    fontWeight: "700",
    color: "#000000",
  },
  customIcon: {
    alignItems: "center",
    justifyContent: "center",
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: "#BD081C",
  },
  customIconText: {
    fontWeight: "700",
    color: "#FFFFFF",
  },
});