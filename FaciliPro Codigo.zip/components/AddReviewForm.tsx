import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  Image,
  ScrollView,
  Alert,
  Platform,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import { Star, Camera, X, Video as VideoIcon } from "lucide-react-native";
import { Video, ResizeMode } from "expo-av";
import Colors from "@/constants/colors";
import Button from "@/components/Button";
import { ReviewMedia } from "@/types/professional";

interface AddReviewFormProps {
  onSubmit: (rating: number, comment: string, media: ReviewMedia[]) => Promise<void>;
  onCancel: () => void;
  isLoading: boolean;
}

export default function AddReviewForm({
  onSubmit,
  onCancel,
  isLoading,
}: AddReviewFormProps) {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [media, setMedia] = useState<ReviewMedia[]>([]);

  const handleImagePick = async () => {
    // Request permissions
    if (Platform.OS !== "web") {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== "granted") {
        Alert.alert(
          "Permission Required",
          "Sorry, we need camera roll permissions to upload images!"
        );
        return;
      }
    }

    // Pick image
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled && result.assets && result.assets.length > 0) {
        // Limit to 5 media items total
        if (media.length >= 5) {
          Alert.alert("Limit Reached", "You can only upload up to 5 media items");
          return;
        }
        
        const newMedia: ReviewMedia = {
          id: `img-${Date.now()}`,
          type: "image",
          url: result.assets[0].uri,
          thumbnailUrl: result.assets[0].uri,
        };
        
        setMedia([...media, newMedia]);
      }
    } catch (error) {
      Alert.alert("Error", "Failed to pick image");
    }
  };

  const handleVideoPick = async () => {
    // Request permissions
    if (Platform.OS !== "web") {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== "granted") {
        Alert.alert(
          "Permission Required",
          "Sorry, we need camera roll permissions to upload videos!"
        );
        return;
      }
    }

    // Pick video
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Videos,
        allowsEditing: true,
        aspect: [16, 9],
        quality: 0.8,
        videoMaxDuration: 60, // 1 minute max
      });

      if (!result.canceled && result.assets && result.assets.length > 0) {
        // Limit to 5 media items total
        if (media.length >= 5) {
          Alert.alert("Limit Reached", "You can only upload up to 5 media items");
          return;
        }
        
        // In a real app, you would generate a thumbnail from the video
        // For this demo, we'll just use a placeholder
        const newMedia: ReviewMedia = {
          id: `video-${Date.now()}`,
          type: "video",
          url: result.assets[0].uri,
          thumbnailUrl: result.assets[0].uri, // In a real app, generate a thumbnail
          duration: result.assets[0].duration || 0,
        };
        
        setMedia([...media, newMedia]);
      }
    } catch (error) {
      Alert.alert("Error", "Failed to pick video");
    }
  };

  const removeMedia = (index: number) => {
    setMedia(media.filter((_, i) => i !== index));
  };

  const handleSubmit = async () => {
    if (rating === 0) {
      Alert.alert("Error", "Please select a rating");
      return;
    }

    if (!comment.trim()) {
      Alert.alert("Error", "Please write a review comment");
      return;
    }

    try {
      await onSubmit(rating, comment, media);
    } catch (error) {
      Alert.alert("Error", "Failed to submit review");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Write a Review</Text>
      
      <View style={styles.ratingContainer}>
        <Text style={styles.label}>Rating</Text>
        <View style={styles.starsContainer}>
          {[1, 2, 3, 4, 5].map((star) => (
            <TouchableOpacity
              key={star}
              onPress={() => setRating(star)}
              style={styles.starButton}
            >
              <Star
                size={32}
                color={Colors.accent}
                fill={star <= rating ? Colors.accent : "transparent"}
              />
            </TouchableOpacity>
          ))}
        </View>
      </View>
      
      <View style={styles.commentContainer}>
        <Text style={styles.label}>Your Review</Text>
        <TextInput
          style={styles.commentInput}
          placeholder="Share your experience with this service..."
          value={comment}
          onChangeText={setComment}
          multiline
          numberOfLines={4}
          textAlignVertical="top"
        />
      </View>
      
      <View style={styles.mediaContainer}>
        <Text style={styles.label}>Add Photos & Videos (Optional)</Text>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.mediaScrollContent}
        >
          {media.map((item, index) => (
            <View key={item.id} style={styles.mediaPreviewContainer}>
              {item.type === "image" ? (
                <Image source={{ uri: item.url }} style={styles.mediaPreview} />
              ) : (
                <View style={styles.videoPreviewContainer}>
                  <Video
                    source={{ uri: item.url }}
                    style={styles.mediaPreview}
                    resizeMode={ResizeMode.COVER}
                    isLooping
                    isMuted
                  />
                  <View style={styles.videoIndicator}>
                    <VideoIcon size={16} color={Colors.white} />
                  </View>
                </View>
              )}
              <TouchableOpacity
                style={styles.removeMediaButton}
                onPress={() => removeMedia(index)}
              >
                <X size={16} color={Colors.white} />
              </TouchableOpacity>
            </View>
          ))}
          
          {media.length < 5 && (
            <View style={styles.addMediaButtonsContainer}>
              <TouchableOpacity
                style={styles.addMediaButton}
                onPress={handleImagePick}
              >
                <Camera size={24} color={Colors.primary} />
                <Text style={styles.addMediaText}>Photo</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={styles.addMediaButton}
                onPress={handleVideoPick}
              >
                <VideoIcon size={24} color={Colors.primary} />
                <Text style={styles.addMediaText}>Video</Text>
              </TouchableOpacity>
            </View>
          )}
        </ScrollView>
      </View>
      
      <View style={styles.buttonContainer}>
        <Button
          title="Submit Review"
          onPress={handleSubmit}
          loading={isLoading}
          style={styles.submitButton}
        />
        <Button
          title="Cancel"
          onPress={onCancel}
          variant="outline"
          style={styles.cancelButton}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: "700",
    color: Colors.text.primary,
    marginBottom: 16,
    textAlign: "center",
  },
  label: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.text.primary,
    marginBottom: 8,
  },
  ratingContainer: {
    marginBottom: 16,
  },
  starsContainer: {
    flexDirection: "row",
    justifyContent: "center",
  },
  starButton: {
    padding: 4,
  },
  commentContainer: {
    marginBottom: 16,
  },
  commentInput: {
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    minHeight: 100,
  },
  mediaContainer: {
    marginBottom: 20,
  },
  mediaScrollContent: {
    paddingVertical: 8,
  },
  mediaPreviewContainer: {
    marginRight: 12,
    position: "relative",
  },
  mediaPreview: {
    width: 100,
    height: 100,
    borderRadius: 8,
  },
  videoPreviewContainer: {
    position: "relative",
  },
  videoIndicator: {
    position: "absolute",
    bottom: 8,
    right: 8,
    backgroundColor: "rgba(0, 0, 0, 0.6)",
    borderRadius: 12,
    width: 24,
    height: 24,
    alignItems: "center",
    justifyContent: "center",
  },
  removeMediaButton: {
    position: "absolute",
    top: -8,
    right: -8,
    backgroundColor: Colors.error,
    borderRadius: 12,
    width: 24,
    height: 24,
    alignItems: "center",
    justifyContent: "center",
  },
  addMediaButtonsContainer: {
    flexDirection: "column",
    gap: 8,
  },
  addMediaButton: {
    width: 100,
    height: 46,
    borderRadius: 8,
    borderWidth: 1,
    borderStyle: "dashed",
    borderColor: Colors.primary,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.background,
    flexDirection: "row",
    gap: 6,
  },
  addMediaText: {
    color: Colors.primary,
    fontSize: 14,
  },
  buttonContainer: {
    flexDirection: "column",
    gap: 12,
  },
  submitButton: {
    marginBottom: 8,
  },
  cancelButton: {
    borderColor: Colors.border,
  },
});