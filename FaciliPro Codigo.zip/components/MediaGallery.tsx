import React, { useState, useRef } from "react";
import {
  StyleSheet,
  View,
  ScrollView,
  Image,
  TouchableOpacity,
  Dimensions,
  Text,
  Platform,
} from "react-native";
import { Video, ResizeMode } from "expo-av";
import { ChevronLeft, ChevronRight, Play, X } from "lucide-react-native";
import Colors from "@/constants/colors";

interface MediaItem {
  id: string;
  type: "image" | "video";
  url: string;
  thumbnailUrl?: string;
  duration?: number;
}

interface MediaGalleryProps {
  media: MediaItem[];
  onClose?: () => void;
  fullscreen?: boolean;
  initialIndex?: number;
}

const { width, height } = Dimensions.get("window");

export default function MediaGallery({
  media,
  onClose,
  fullscreen = false,
  initialIndex = 0,
}: MediaGalleryProps) {
  const [activeIndex, setActiveIndex] = useState(initialIndex);
  const scrollViewRef = useRef<ScrollView>(null);
  const videoRef = useRef<Video>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const handleScroll = (event: any) => {
    const contentOffsetX = event.nativeEvent.contentOffset.x;
    const newIndex = Math.round(contentOffsetX / width);
    if (newIndex !== activeIndex) {
      setActiveIndex(newIndex);
      // Pause any playing video when scrolling away
      if (isPlaying) {
        videoRef.current?.pauseAsync();
        setIsPlaying(false);
      }
    }
  };

  const goToMedia = (index: number) => {
    if (index >= 0 && index < media.length) {
      scrollViewRef.current?.scrollTo({
        x: index * width,
        animated: true,
      });
      setActiveIndex(index);
    }
  };

  const togglePlayPause = async () => {
    if (videoRef.current) {
      if (isPlaying) {
        await videoRef.current.pauseAsync();
      } else {
        await videoRef.current.playAsync();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleVideoStatusUpdate = (status: any) => {
    if (status.isLoaded) {
      setIsPlaying(status.isPlaying);
    }
  };

  const renderMediaItem = (item: MediaItem, index: number) => {
    if (item.type === "image") {
      return (
        <Image
          key={item.id}
          source={{ uri: item.url }}
          style={fullscreen ? styles.fullscreenImage : styles.image}
          resizeMode="contain"
        />
      );
    } else {
      return (
        <View key={item.id} style={fullscreen ? styles.fullscreenVideoContainer : styles.videoContainer}>
          <Video
            ref={index === activeIndex ? videoRef : undefined}
            source={{ uri: item.url }}
            style={fullscreen ? styles.fullscreenVideo : styles.video}
            useNativeControls={Platform.OS !== "web"}
            resizeMode={ResizeMode.CONTAIN}
            isLooping
            onPlaybackStatusUpdate={handleVideoStatusUpdate}
          />
          {Platform.OS === "web" && (
            <TouchableOpacity
              style={styles.playButton}
              onPress={togglePlayPause}
            >
              <Play
                size={fullscreen ? 48 : 32}
                color={Colors.white}
                fill={Colors.white}
              />
            </TouchableOpacity>
          )}
        </View>
      );
    }
  };

  return (
    <View style={[styles.container, fullscreen && styles.fullscreenContainer]}>
      {onClose && (
        <TouchableOpacity style={styles.closeButton} onPress={onClose}>
          <X size={24} color={fullscreen ? Colors.white : Colors.text.primary} />
        </TouchableOpacity>
      )}

      <ScrollView
        ref={scrollViewRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={handleScroll}
        scrollEventThrottle={16}
        style={styles.scrollView}
      >
        {media.map((item, index) => (
          <View key={item.id} style={{ width, height: fullscreen ? height : 250 }}>
            {renderMediaItem(item, index)}
          </View>
        ))}
      </ScrollView>

      {media.length > 1 && (
        <View style={styles.pagination}>
          {media.map((_, index) => (
            <View
              key={index}
              style={[
                styles.paginationDot,
                index === activeIndex && styles.paginationDotActive,
              ]}
            />
          ))}
        </View>
      )}

      {media.length > 1 && (
        <>
          {activeIndex > 0 && (
            <TouchableOpacity
              style={[styles.navButton, styles.navButtonLeft]}
              onPress={() => goToMedia(activeIndex - 1)}
            >
              <ChevronLeft size={24} color={fullscreen ? Colors.white : Colors.text.primary} />
            </TouchableOpacity>
          )}
          {activeIndex < media.length - 1 && (
            <TouchableOpacity
              style={[styles.navButton, styles.navButtonRight]}
              onPress={() => goToMedia(activeIndex + 1)}
            >
              <ChevronRight size={24} color={fullscreen ? Colors.white : Colors.text.primary} />
            </TouchableOpacity>
          )}
        </>
      )}

      {fullscreen && (
        <View style={styles.counter}>
          <Text style={styles.counterText}>
            {activeIndex + 1} / {media.length}
          </Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: "relative",
    backgroundColor: Colors.white,
  },
  fullscreenContainer: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.9)",
  },
  scrollView: {
    flex: 1,
  },
  image: {
    width: "100%",
    height: 250,
  },
  fullscreenImage: {
    width: "100%",
    height: "100%",
  },
  videoContainer: {
    width: "100%",
    height: 250,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: Colors.background,
  },
  fullscreenVideoContainer: {
    width: "100%",
    height: "100%",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "black",
  },
  video: {
    width: "100%",
    height: 250,
  },
  fullscreenVideo: {
    width: "100%",
    height: "100%",
  },
  playButton: {
    position: "absolute",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    borderRadius: 40,
    padding: 12,
  },
  pagination: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    position: "absolute",
    bottom: 16,
    width: "100%",
  },
  paginationDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "rgba(255, 255, 255, 0.5)",
    marginHorizontal: 4,
  },
  paginationDotActive: {
    backgroundColor: Colors.white,
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  navButton: {
    position: "absolute",
    top: "50%",
    transform: [{ translateY: -20 }],
    backgroundColor: "rgba(255, 255, 255, 0.3)",
    borderRadius: 20,
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  navButtonLeft: {
    left: 16,
  },
  navButtonRight: {
    right: 16,
  },
  closeButton: {
    position: "absolute",
    top: 16,
    right: 16,
    zIndex: 10,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    borderRadius: 20,
    padding: 8,
  },
  counter: {
    position: "absolute",
    top: 16,
    left: 16,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    borderRadius: 12,
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  counterText: {
    color: Colors.white,
    fontSize: 12,
    fontWeight: "600",
  },
});