import React from "react";
import { StyleSheet, TextInput, View, TouchableOpacity } from "react-native";
import { Search, MapPin, X } from "lucide-react-native";
import Colors from "@/constants/colors";

interface SearchBarProps {
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
  showLocationIcon?: boolean;
  onLocationPress?: () => void;
  onClear?: () => void;
}

export default function SearchBar({
  value,
  onChangeText,
  placeholder = "Search for services...",
  showLocationIcon = true,
  onLocationPress,
  onClear,
}: SearchBarProps) {
  return (
    <View style={styles.container}>
      <Search size={20} color={Colors.text.secondary} style={styles.searchIcon} />
      
      <TextInput
        style={styles.input}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={Colors.text.secondary}
      />
      
      {value.length > 0 && (
        <TouchableOpacity onPress={onClear} style={styles.clearButton}>
          <X size={18} color={Colors.text.secondary} />
        </TouchableOpacity>
      )}
      
      {showLocationIcon && (
        <>
          <View style={styles.divider} />
          <TouchableOpacity onPress={onLocationPress} style={styles.locationButton}>
            <MapPin size={20} color={Colors.primary} />
          </TouchableOpacity>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.white,
    borderRadius: 12,
    paddingHorizontal: 12,
    height: 50,
    shadowColor: Colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  searchIcon: {
    marginRight: 8,
  },
  input: {
    flex: 1,
    height: "100%",
    fontSize: 16,
    color: Colors.text.primary,
  },
  clearButton: {
    padding: 4,
  },
  divider: {
    width: 1,
    height: 24,
    backgroundColor: Colors.border,
    marginHorizontal: 8,
  },
  locationButton: {
    padding: 4,
  },
});