import React from "react";
import { StyleSheet, Text, View, TouchableOpacity } from "react-native";
import { Service } from "@/types/professional";
import Colors from "@/constants/colors";
import { Check } from "lucide-react-native";

interface ServiceItemProps {
  service: Service;
  isSelected: boolean;
  onSelect: (service: Service) => void;
}

export default function ServiceItem({
  service,
  isSelected,
  onSelect,
}: ServiceItemProps) {
  return (
    <TouchableOpacity
      style={[styles.container, isSelected && styles.selectedContainer]}
      onPress={() => onSelect(service)}
      activeOpacity={0.7}
    >
      <View style={styles.content}>
        <Text style={styles.name}>{service.name}</Text>
        <Text style={styles.price}>${service.price}</Text>
      </View>
      
      {isSelected && (
        <View style={styles.checkContainer}>
          <Check size={16} color={Colors.white} />
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: Colors.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  selectedContainer: {
    borderColor: Colors.primary,
    backgroundColor: Colors.background,
  },
  content: {
    flex: 1,
  },
  name: {
    fontSize: 16,
    fontWeight: "500",
    color: Colors.text.primary,
    marginBottom: 4,
  },
  price: {
    fontSize: 14,
    color: Colors.primary,
    fontWeight: "600",
  },
  checkContainer: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: Colors.primary,
    alignItems: "center",
    justifyContent: "center",
  },
});