import React from "react";
import { StyleSheet, Text, View, TouchableOpacity, Image } from "react-native";
import { Professional } from "@/types/professional";
import Colors from "@/constants/colors";
import { Star, MapPin } from "lucide-react-native";

interface ProfessionalCardProps {
  professional: Professional;
  onPress: (professional: Professional) => void;
}

export default function ProfessionalCard({
  professional,
  onPress,
}: ProfessionalCardProps) {
  return (
    <TouchableOpacity
      style={styles.container}
      onPress={() => onPress(professional)}
      activeOpacity={0.7}
    >
      <Image source={{ uri: professional.avatar }} style={styles.avatar} />
      <View style={styles.content}>
        <Text style={styles.name}>{professional.name}</Text>
        
        <View style={styles.ratingContainer}>
          <Star size={16} color={Colors.accent} fill={Colors.accent} />
          <Text style={styles.rating}>
            {professional.rating.toFixed(1)} ({professional.reviewCount})
          </Text>
        </View>
        
        <View style={styles.locationContainer}>
          <MapPin size={14} color={Colors.text.secondary} />
          <Text style={styles.location}>
            {professional.location} • {professional.distance} km
          </Text>
        </View>
      </View>
      
      <View style={styles.priceContainer}>
        <Text style={styles.price}>${professional.hourlyRate}</Text>
        <Text style={styles.priceUnit}>/hr</Text>
      </View>
      
      {!professional.available && (
        <View style={styles.unavailableBadge}>
          <Text style={styles.unavailableText}>Unavailable</Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    backgroundColor: Colors.white,
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 16,
    marginBottom: 16,
    shadowColor: Colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 12,
  },
  content: {
    flex: 1,
    justifyContent: "center",
  },
  name: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.text.primary,
    marginBottom: 4,
  },
  ratingContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 4,
  },
  rating: {
    fontSize: 14,
    color: Colors.text.secondary,
    marginLeft: 4,
  },
  locationContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  location: {
    fontSize: 12,
    color: Colors.text.secondary,
    marginLeft: 4,
  },
  priceContainer: {
    alignItems: "flex-end",
    justifyContent: "center",
  },
  price: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.primary,
  },
  priceUnit: {
    fontSize: 12,
    color: Colors.text.secondary,
  },
  unavailableBadge: {
    position: "absolute",
    top: 12,
    right: 12,
    backgroundColor: Colors.red,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  unavailableText: {
    color: Colors.white,
    fontSize: 10,
    fontWeight: "600",
  },
});