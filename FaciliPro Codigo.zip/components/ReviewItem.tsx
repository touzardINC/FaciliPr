import React, { useState } from "react";
import { StyleSheet, Text, View, TouchableOpacity, Image, Modal } from "react-native";
import { Review, ReviewMedia } from "@/types/professional";
import Colors from "@/constants/colors";
import { Star, X, Play } from "lucide-react-native";
import MediaThumbnails from "@/components/MediaThumbnails";
import MediaGallery from "@/components/MediaGallery";

interface ReviewItemProps {
  review: Review;
}

export default function ReviewItem({ review }: ReviewItemProps) {
  const [showMediaGallery, setShowMediaGallery] = useState(false);
  const [initialMediaIndex, setInitialMediaIndex] = useState(0);
  
  // Format date to a more readable format
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  // Convert legacy images to media format if needed
  const reviewMedia: ReviewMedia[] = review.images || [];

  const handleMediaPress = (index: number) => {
    setInitialMediaIndex(index);
    setShowMediaGallery(true);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.ratingContainer}>
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              size={16}
              color={Colors.accent}
              fill={i < review.rating ? Colors.accent : "transparent"}
            />
          ))}
        </View>
        <Text style={styles.date}>{formatDate(review.date)}</Text>
      </View>
      
      <Text style={styles.comment}>{review.comment}</Text>
      
      {reviewMedia.length > 0 && (
        <View style={styles.mediaContainer}>
          <MediaThumbnails 
            media={reviewMedia}
            onPress={handleMediaPress}
          />
        </View>
      )}
      
      {/* Full-screen media gallery modal */}
      <Modal
        visible={showMediaGallery}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowMediaGallery(false)}
      >
        <View style={styles.fullGalleryContainer}>
          <MediaGallery 
            media={reviewMedia} 
            onClose={() => setShowMediaGallery(false)} 
            fullscreen={true}
            initialIndex={initialMediaIndex}
          />
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: Colors.shadow,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  ratingContainer: {
    flexDirection: "row",
  },
  date: {
    fontSize: 12,
    color: Colors.text.secondary,
  },
  comment: {
    fontSize: 14,
    color: Colors.text.primary,
    lineHeight: 20,
    marginBottom: 12,
  },
  mediaContainer: {
    marginTop: 8,
  },
  fullGalleryContainer: {
    flex: 1,
    backgroundColor: "black",
  },
});