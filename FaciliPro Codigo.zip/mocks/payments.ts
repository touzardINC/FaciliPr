import { PaymentMethod } from "@/types/payment";

export const paymentMethods: PaymentMethod[] = [
  {
    id: "pm_1",
    type: "credit_card",
    name: "Visa ending in 4242",
    last4: "4242",
    expiryDate: "12/25",
    isDefault: true,
    brand: "visa",
    icon: "credit-card",
  },
  {
    id: "pm_2",
    type: "credit_card",
    name: "Mastercard ending in 5555",
    last4: "5555",
    expiryDate: "10/24",
    isDefault: false,
    brand: "mastercard",
    icon: "credit-card",
  },
  {
    id: "pm_3",
    type: "paypal",
    name: "PayPal - john.doe@example.com",
    last4: "",
    isDefault: false,
    brand: "paypal",
    icon: "credit-card",
  },
];