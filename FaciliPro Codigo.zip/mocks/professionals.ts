import { Professional } from "@/types/professional";

export const professionals: Professional[] = [
  // PLUMBING PROFESSIONALS (Category 1)
  {
    id: "1",
    name: "Carlos Mendez",
    categoryId: "1",
    avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.8,
    reviewCount: 124,
    hourlyRate: 25,
    description: "Professional plumber with 10+ years of experience in residential and commercial plumbing. Specializing in pipe repairs, installations, and maintenance.",
    location: "Panama City",
    distance: 2.5,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/carlosplumbing",
        username: "carlosplumbing"
      },
      {
        platform: "facebook",
        url: "https://facebook.com/carlosplumbing",
        username: "Carlos Plumbing Services"
      },
      {
        platform: "website",
        url: "https://carlosplumbing.com"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Pipe Repair", 
        price: 35,
        description: "Complete repair of damaged or leaking pipes. Includes diagnosis, replacement of affected sections, and testing to ensure proper function.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          },
          {
            id: "img2",
            type: "image",
            url: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          },
          {
            id: "video1",
            type: "video",
            url: "https://assets.mixkit.co/videos/preview/mixkit-plumber-working-on-a-pipe-with-a-wrench-9103-large.mp4",
            thumbnailUrl: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-2 hours"
      },
      { 
        id: "2", 
        name: "Sink Installation", 
        price: 80,
        description: "Professional installation of new sinks or replacement of existing ones. Includes removal of old sink, installation of new sink, and connection to existing plumbing.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          },
          {
            id: "video1",
            type: "video",
            url: "https://assets.mixkit.co/videos/preview/mixkit-installing-a-sink-in-a-bathroom-9096-large.mp4",
            thumbnailUrl: "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-3 hours"
      },
      { 
        id: "3", 
        name: "Toilet Repair", 
        price: 45,
        description: "Diagnosis and repair of toilet issues including leaks, running water, clogging, or flushing problems. Includes replacement of internal components if needed.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1597527724979-14d6e4d5c2b6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1 hour"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "101", 
        rating: 5, 
        comment: "Excellent service! Fixed my leaking pipe quickly and professionally. Would definitely recommend Carlos to anyone needing plumbing work.", 
        date: "2023-10-15",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1585704032915-c3400305e979?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1585704032915-c3400305e979?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          },
          {
            id: "video1",
            type: "video",
            url: "https://assets.mixkit.co/videos/preview/mixkit-water-dripping-from-a-tap-1698-large.mp4",
            thumbnailUrl: "https://images.unsplash.com/photo-1585704032915-c3400305e979?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "102", 
        rating: 4, 
        comment: "Good work, arrived on time and fixed the issue efficiently. The only reason I'm not giving 5 stars is because the price was slightly higher than quoted.", 
        date: "2023-09-22" 
      },
    ],
  },
  {
    id: "p1-2",
    name: "Elena Rodriguez",
    categoryId: "1",
    avatar: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.9,
    reviewCount: 87,
    hourlyRate: 28,
    description: "Master plumber with expertise in modern plumbing systems. I specialize in eco-friendly solutions and water-saving installations.",
    location: "Panama City",
    distance: 3.2,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/elenaplumbing",
        username: "elenaplumbing"
      },
      {
        platform: "facebook",
        url: "https://facebook.com/elenaplumbing",
        username: "Elena's Eco Plumbing"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Water Heater Installation", 
        price: 120,
        description: "Professional installation of tankless or traditional water heaters. Includes removal of old unit, installation of new heater, and all necessary connections.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1585704032915-c3400305e979?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "3-4 hours"
      },
      { 
        id: "2", 
        name: "Eco-Friendly Fixtures", 
        price: 65,
        description: "Installation of water-saving fixtures including low-flow toilets, faucets, and showerheads. Helps reduce water consumption and utility bills.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1584622781564-1d987f7333c1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-2 hours per fixture"
      },
      { 
        id: "3", 
        name: "Drain Cleaning", 
        price: 55,
        description: "Professional cleaning of clogged or slow drains using eco-friendly methods. Includes inspection, cleaning, and preventative maintenance advice.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-2 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "103", 
        rating: 5, 
        comment: "Elena installed a tankless water heater in our home and we couldn't be happier. She was professional, knowledgeable, and left everything spotless.", 
        date: "2023-10-10",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1585704032915-c3400305e979?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1585704032915-c3400305e979?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "104", 
        rating: 5, 
        comment: "We hired Elena to install eco-friendly fixtures throughout our house. She was fantastic - explained everything, worked efficiently, and the fixtures are saving us money already!", 
        date: "2023-09-15" 
      },
    ],
  },
  {
    id: "p1-3",
    name: "Miguel Torres",
    categoryId: "1",
    avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.7,
    reviewCount: 62,
    hourlyRate: 22,
    description: "Emergency plumbing specialist available 24/7. Fast response for leaks, clogs, and plumbing emergencies of all kinds.",
    location: "David",
    distance: 4.1,
    available: true,
    socialMedia: [
      {
        platform: "facebook",
        url: "https://facebook.com/miguelsemergencyplumbing",
        username: "Miguel's 24/7 Plumbing"
      },
      {
        platform: "website",
        url: "https://miguelsplumbing.com"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Emergency Leak Repair", 
        price: 75,
        description: "Rapid response service for water leaks and pipe bursts. Available 24/7 including holidays. Includes temporary fixes and permanent solutions.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-3 hours"
      },
      { 
        id: "2", 
        name: "Drain Unclogging", 
        price: 50,
        description: "Fast and effective unclogging of drains, toilets, and sewer lines. Uses professional-grade equipment to clear even the toughest blockages.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-2 hours"
      },
      { 
        id: "3", 
        name: "Water Pressure Issues", 
        price: 60,
        description: "Diagnosis and repair of water pressure problems. Includes checking pressure regulators, looking for leaks, and clearing pipe obstructions.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-2 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "105", 
        rating: 5, 
        comment: "Miguel saved us from a disaster! A pipe burst at 2am and he was at our house within 30 minutes. Professional, fast, and reasonably priced even for an emergency call.", 
        date: "2023-10-05" 
      },
      { 
        id: "2", 
        userId: "106", 
        rating: 4, 
        comment: "Great emergency service. Fixed our clogged drain quickly and gave us tips to prevent future issues. Would use again.", 
        date: "2023-09-18" 
      },
    ],
  },

  // GARDENING PROFESSIONALS (Category 2)
  {
    id: "2",
    name: "Maria Gonzalez",
    categoryId: "2",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.9,
    reviewCount: 89,
    hourlyRate: 20,
    description: "Experienced gardener specializing in tropical plants and landscaping. I can help with lawn care, plant selection, and garden maintenance.",
    location: "Colon",
    distance: 3.8,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/mariagardening",
        username: "mariagardening"
      },
      {
        platform: "youtube",
        url: "https://youtube.com/c/mariagardening",
        username: "Maria's Garden Tips"
      },
      {
        platform: "tiktok",
        url: "https://tiktok.com/@mariagardening",
        username: "@mariagardening"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Lawn Mowing", 
        price: 30,
        description: "Complete lawn mowing service for residential properties. Includes edging, trimming around obstacles, and cleanup of clippings.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1589923188900-85dae523342b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          },
          {
            id: "video1",
            type: "video",
            url: "https://assets.mixkit.co/videos/preview/mixkit-man-cutting-the-grass-with-a-lawn-mower-42483-large.mp4",
            thumbnailUrl: "https://images.unsplash.com/photo-1589923188900-85dae523342b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-2 hours"
      },
      { 
        id: "2", 
        name: "Garden Design", 
        price: 150,
        description: "Professional garden design consultation. Includes assessment of your space, plant recommendations suited to the local climate, and a detailed design plan.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          },
          {
            id: "img2",
            type: "image",
            url: "https://images.unsplash.com/photo-1558293842-c0fd3db86157?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          },
          {
            id: "img3",
            type: "image",
            url: "https://images.unsplash.com/photo-1598902108854-10e335adac99?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "3-4 hours"
      },
      { 
        id: "3", 
        name: "Plant Care", 
        price: 25,
        description: "Specialized care for indoor and outdoor plants. Includes pruning, fertilizing, pest control, and advice on optimal growing conditions.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1599685315640-4a9ba2613f46?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          },
          {
            id: "video1",
            type: "video",
            url: "https://assets.mixkit.co/videos/preview/mixkit-gardener-watering-plants-in-a-greenhouse-12902-large.mp4",
            thumbnailUrl: "https://images.unsplash.com/photo-1599685315640-4a9ba2613f46?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1 hour"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "103", 
        rating: 5, 
        comment: "Maria transformed my garden! Highly recommend her services. She has an incredible knowledge of tropical plants and created a beautiful design that's easy to maintain.", 
        date: "2023-10-05",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1558293842-c0fd3db86157?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1558293842-c0fd3db86157?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          },
          {
            id: "img2",
            type: "image",
            url: "https://images.unsplash.com/photo-1598902108854-10e335adac99?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1598902108854-10e335adac99?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          },
          {
            id: "video1",
            type: "video",
            url: "https://assets.mixkit.co/videos/preview/mixkit-gardener-watering-plants-in-a-greenhouse-12902-large.mp4",
            thumbnailUrl: "https://images.unsplash.com/photo-1598902108854-10e335adac99?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "104", 
        rating: 5, 
        comment: "Very knowledgeable about tropical plants. Maria helped me select the perfect plants for my patio and gave me great care instructions.", 
        date: "2023-09-18" 
      },
    ],
  },
  {
    id: "p2-2",
    name: "Luis Palacios",
    categoryId: "2",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.8,
    reviewCount: 73,
    hourlyRate: 22,
    description: "Landscape designer specializing in sustainable gardens and native plants. Creating beautiful outdoor spaces that thrive in the local climate.",
    location: "Panama City",
    distance: 2.7,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/luislandscapes",
        username: "luislandscapes"
      },
      {
        platform: "pinterest",
        url: "https://pinterest.com/luislandscapes",
        username: "Luis Landscapes"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Landscape Design", 
        price: 200,
        description: "Complete landscape design service including hardscaping and planting plans. Focuses on sustainable, low-maintenance designs using native plants.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1558293842-c0fd3db86157?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "4-6 hours"
      },
      { 
        id: "2", 
        name: "Irrigation Installation", 
        price: 120,
        description: "Installation of efficient irrigation systems including drip irrigation and smart controllers. Helps conserve water while keeping plants healthy.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1599685315640-4a9ba2613f46?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "3-5 hours"
      },
      { 
        id: "3", 
        name: "Native Plant Installation", 
        price: 85,
        description: "Selection and installation of native plants suited to the local climate. Includes soil preparation, planting, and initial care instructions.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-4 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "107", 
        rating: 5, 
        comment: "Luis redesigned our entire backyard and it's absolutely stunning. He used native plants that are thriving with minimal maintenance. Worth every penny!", 
        date: "2023-10-12",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1558293842-c0fd3db86157?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1558293842-c0fd3db86157?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "108", 
        rating: 4, 
        comment: "Great work on our irrigation system. Luis was knowledgeable and installed a system that's saving us water and keeping our plants healthy.", 
        date: "2023-09-25" 
      },
    ],
  },
  {
    id: "p2-3",
    name: "Sofia Vega",
    categoryId: "2",
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.7,
    reviewCount: 51,
    hourlyRate: 18,
    description: "Organic gardening specialist focusing on vegetable gardens, fruit trees, and edible landscapes. I can help you grow your own food sustainably.",
    location: "David",
    distance: 5.3,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/sofiasorganicgardens",
        username: "sofiasorganicgardens"
      },
      {
        platform: "youtube",
        url: "https://youtube.com/c/sofiasorganicgardens",
        username: "Sofia's Organic Gardens"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Vegetable Garden Setup", 
        price: 95,
        description: "Complete setup of organic vegetable gardens. Includes bed preparation, soil amendment, planting, and care instructions for a successful harvest.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "3-4 hours"
      },
      { 
        id: "2", 
        name: "Fruit Tree Planting", 
        price: 70,
        description: "Selection and planting of fruit trees suited to the local climate. Includes site selection, planting, and care instructions for optimal fruit production.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1599685315640-4a9ba2613f46?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-3 hours"
      },
      { 
        id: "3", 
        name: "Organic Pest Control", 
        price: 45,
        description: "Natural and organic solutions for garden pests and diseases. Includes inspection, treatment, and preventative measures without harmful chemicals.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1589923188900-85dae523342b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-2 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "109", 
        rating: 5, 
        comment: "Sofia helped us set up our first vegetable garden and we're already harvesting! Her knowledge of organic methods is impressive and she made it easy for beginners like us.", 
        date: "2023-10-08" 
      },
      { 
        id: "2", 
        userId: "110", 
        rating: 4, 
        comment: "Great service. Sofia planted fruit trees for us and gave excellent care instructions. One tree didn't survive but she came back and replaced it at no charge.", 
        date: "2023-09-20" 
      },
    ],
  },

  // ELECTRICAL PROFESSIONALS (Category 3)
  {
    id: "3",
    name: "Roberto Sanchez",
    categoryId: "3",
    avatar: "https://images.unsplash.com/photo-1566753323558-f4e0952af115?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.7,
    reviewCount: 56,
    hourlyRate: 30,
    description: "Certified electrician with expertise in residential wiring, installations, and repairs. Safety is my top priority.",
    location: "Panama City",
    distance: 1.2,
    available: false,
    socialMedia: [
      {
        platform: "facebook",
        url: "https://facebook.com/robertoelectrical",
        username: "Roberto's Electrical Services"
      },
      {
        platform: "linkedin",
        url: "https://linkedin.com/in/robertosanchez",
        username: "Roberto Sanchez"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Electrical Repair", 
        price: 40,
        description: "Diagnosis and repair of electrical issues including outlets, switches, circuit breakers, and wiring problems.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          },
          {
            id: "video1",
            type: "video",
            url: "https://assets.mixkit.co/videos/preview/mixkit-electrician-working-on-electrical-panel-4488-large.mp4",
            thumbnailUrl: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-2 hours"
      },
      { 
        id: "2", 
        name: "Light Installation", 
        price: 60,
        description: "Professional installation of light fixtures, ceiling fans, and other lighting elements. Includes removal of old fixtures if needed.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-3 hours"
      },
      { 
        id: "3", 
        name: "Wiring", 
        price: 85,
        description: "Installation or replacement of electrical wiring for new construction or renovations. All work complies with local electrical codes.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1558402529-d2638a7023e9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "3-5 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "105", 
        rating: 5, 
        comment: "Very professional and knowledgeable. Roberto installed new lighting in our kitchen and fixed some electrical issues we'd been having for months.", 
        date: "2023-09-30",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1565538810643-b5bdb714032a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1565538810643-b5bdb714032a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "106", 
        rating: 4, 
        comment: "Fixed our electrical issues quickly. Very thorough and explained everything he was doing.", 
        date: "2023-09-10" 
      },
    ],
  },
  {
    id: "p3-2",
    name: "Daniela Ortiz",
    categoryId: "3",
    avatar: "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.9,
    reviewCount: 67,
    hourlyRate: 32,
    description: "Master electrician specializing in smart home installations and energy-efficient electrical solutions. Licensed and insured with 12 years of experience.",
    location: "Panama City",
    distance: 2.3,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/danielaelectrical",
        username: "danielaelectrical"
      },
      {
        platform: "linkedin",
        url: "https://linkedin.com/in/danielaortiz",
        username: "Daniela Ortiz"
      },
      {
        platform: "website",
        url: "https://danielaelectrical.com"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Smart Home Installation", 
        price: 120,
        description: "Installation and setup of smart home systems including lighting, thermostats, security, and home automation. Compatible with major platforms like Alexa and Google Home.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1558402529-d2638a7023e9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "3-6 hours"
      },
      { 
        id: "2", 
        name: "Electrical Panel Upgrade", 
        price: 350,
        description: "Complete upgrade of electrical panels to support modern power needs. Includes assessment, installation, and ensuring code compliance.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "4-8 hours"
      },
      { 
        id: "3", 
        name: "Energy Efficiency Audit", 
        price: 75,
        description: "Comprehensive assessment of your home's electrical usage with recommendations for energy-saving improvements. Includes thermal imaging and load analysis.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-3 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "111", 
        rating: 5, 
        comment: "Daniela installed a complete smart home system for us and it's amazing! She was incredibly knowledgeable and helped us choose the right components for our needs. Everything works perfectly.", 
        date: "2023-10-15",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1558402529-d2638a7023e9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1558402529-d2638a7023e9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "112", 
        rating: 5, 
        comment: "We had Daniela upgrade our electrical panel and the difference is night and day. No more tripped breakers and we can finally run all our appliances at once. Very professional service.", 
        date: "2023-09-28" 
      },
    ],
  },
  {
    id: "p3-3",
    name: "Alejandro Diaz",
    categoryId: "3",
    avatar: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.6,
    reviewCount: 42,
    hourlyRate: 28,
    description: "Specialized in solar power installations and renewable energy solutions. Helping homes and businesses reduce their carbon footprint and energy bills.",
    location: "Colon",
    distance: 4.8,
    available: true,
    socialMedia: [
      {
        platform: "facebook",
        url: "https://facebook.com/alejandrosolar",
        username: "Alejandro's Solar Solutions"
      },
      {
        platform: "youtube",
        url: "https://youtube.com/c/alejandrosolar",
        username: "Solar Power with Alejandro"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Solar Panel Installation", 
        price: 500,
        description: "Complete solar panel system installation including panels, inverters, and battery storage options. Includes assessment, design, and installation.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1509391366360-2e959784a276?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-2 days"
      },
      { 
        id: "2", 
        name: "Solar Assessment", 
        price: 80,
        description: "Comprehensive assessment of your property's solar potential. Includes roof analysis, shading study, and detailed report with cost-benefit analysis.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1559302995-f8d3d980e2d3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-3 hours"
      },
      { 
        id: "3", 
        name: "Battery Backup Installation", 
        price: 300,
        description: "Installation of battery backup systems for existing solar installations or as standalone power backup solutions. Includes system sizing and integration.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1569691105751-88df003de7a2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "4-6 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "113", 
        rating: 5, 
        comment: "Alejandro installed a solar system on our roof and we couldn't be happier. The installation was clean and professional, and we're already seeing significant savings on our electric bill.", 
        date: "2023-10-02",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1509391366360-2e959784a276?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1509391366360-2e959784a276?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "114", 
        rating: 4, 
        comment: "Good service and knowledge. The solar assessment was thorough and helped us make an informed decision. Installation took a bit longer than expected, but the results are great.", 
        date: "2023-09-15" 
      },
    ],
  },

  // CLEANING PROFESSIONALS (Category 4)
  {
    id: "4",
    name: "Ana Castillo",
    categoryId: "4",
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.6,
    reviewCount: 78,
    hourlyRate: 18,
    description: "Professional cleaner with attention to detail. I provide thorough cleaning services for homes and small offices.",
    location: "David",
    distance: 4.5,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/anacleaningservices",
        username: "anacleaningservices"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Deep Cleaning", 
        price: 120,
        description: "Comprehensive cleaning of your entire home or office. Includes cleaning of all surfaces, floors, bathrooms, kitchen, and hard-to-reach areas.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "4-6 hours"
      },
      { 
        id: "2", 
        name: "Regular Cleaning", 
        price: 80,
        description: "Standard cleaning service for maintenance between deep cleanings. Includes dusting, vacuuming, mopping, and cleaning of bathrooms and kitchen.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1563453392212-326f5e854473?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-3 hours"
      },
      { 
        id: "3", 
        name: "Window Cleaning", 
        price: 40,
        description: "Professional cleaning of windows, inside and out. Includes cleaning of frames, sills, and screens if applicable.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-2 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "107", 
        rating: 5, 
        comment: "My house has never been cleaner! Ana is thorough, efficient, and pays attention to every detail. I'm so impressed with her work.", 
        date: "2023-10-12",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1584622781564-1d987f7333c1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1584622781564-1d987f7333c1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "108", 
        rating: 4, 
        comment: "Great service, very thorough. Ana cleaned areas I didn't even think about. Will definitely book again.", 
        date: "2023-09-25" 
      },
    ],
  },
  {
    id: "p4-2",
    name: "Marco Herrera",
    categoryId: "4",
    avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.8,
    reviewCount: 63,
    hourlyRate: 20,
    description: "Commercial cleaning specialist with experience in offices, retail spaces, and medical facilities. Using eco-friendly products and advanced cleaning techniques.",
    location: "Panama City",
    distance: 2.1,
    available: true,
    socialMedia: [
      {
        platform: "facebook",
        url: "https://facebook.com/marcocommercialcleaning",
        username: "Marco's Commercial Cleaning"
      },
      {
        platform: "linkedin",
        url: "https://linkedin.com/in/marcoherrera",
        username: "Marco Herrera"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Office Cleaning", 
        price: 150,
        description: "Complete cleaning service for office spaces. Includes cleaning of workstations, common areas, restrooms, and kitchen facilities. Available after business hours.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "3-5 hours"
      },
      { 
        id: "2", 
        name: "Medical Facility Cleaning", 
        price: 200,
        description: "Specialized cleaning for medical offices and facilities. Follows strict protocols for sanitization and disinfection to maintain a safe environment.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1563453392212-326f5e854473?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "4-6 hours"
      },
      { 
        id: "3", 
        name: "Post-Construction Cleaning", 
        price: 250,
        description: "Thorough cleaning after construction or renovation projects. Removes dust, debris, paint splatter, and construction residue from all surfaces.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1584622781564-1d987f7333c1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "6-8 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "115", 
        rating: 5, 
        comment: "Marco and his team clean our medical office weekly and do an outstanding job. They're thorough, reliable, and follow all our sanitization protocols perfectly.", 
        date: "2023-10-18" 
      },
      { 
        id: "2", 
        userId: "116", 
        rating: 5, 
        comment: "We hired Marco for post-construction cleaning of our new office space and the results were amazing. They removed all traces of construction and left the place spotless.", 
        date: "2023-09-30",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1584622781564-1d987f7333c1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1584622781564-1d987f7333c1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
    ],
  },
  {
    id: "p4-3",
    name: "Isabella Fuentes",
    categoryId: "4",
    avatar: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.7,
    reviewCount: 54,
    hourlyRate: 19,
    description: "Specialized in eco-friendly and non-toxic cleaning for homes with children, pets, or individuals with sensitivities. Using only natural, sustainable products.",
    location: "Panama City",
    distance: 3.4,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/isabellaecoclean",
        username: "isabellaecoclean"
      },
      {
        platform: "facebook",
        url: "https://facebook.com/isabellaecoclean",
        username: "Isabella's Eco-Friendly Cleaning"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Eco-Friendly Home Cleaning", 
        price: 100,
        description: "Complete home cleaning using only natural, non-toxic products. Safe for children, pets, and people with allergies or chemical sensitivities.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "3-4 hours"
      },
      { 
        id: "2", 
        name: "Allergy-Friendly Deep Clean", 
        price: 140,
        description: "Specialized deep cleaning service focused on removing allergens, dust mites, and other irritants. Includes HEPA vacuuming and dust-trapping techniques.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1563453392212-326f5e854473?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "4-5 hours"
      },
      { 
        id: "3", 
        name: "Natural Carpet Cleaning", 
        price: 80,
        description: "Chemical-free carpet cleaning using plant-based solutions and steam. Removes stains and odors without harsh chemicals or residues.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-3 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "117", 
        rating: 5, 
        comment: "Isabella's eco-friendly cleaning is perfect for our family. My son has asthma and we've noticed a huge improvement since switching to her services. The house smells fresh without any chemical odors.", 
        date: "2023-10-10" 
      },
      { 
        id: "2", 
        userId: "118", 
        rating: 4, 
        comment: "Great service! Isabella did an allergy-friendly deep clean of our home and it made a noticeable difference. My allergies have improved and the house feels so much cleaner.", 
        date: "2023-09-22",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
    ],
  },

  // CARPENTRY PROFESSIONALS (Category 5)
  {
    id: "5",
    name: "Javier Morales",
    categoryId: "5",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.9,
    reviewCount: 45,
    hourlyRate: 28,
    description: "Master carpenter with 15 years of experience. Specializing in custom furniture, repairs, and woodworking projects.",
    location: "Panama City",
    distance: 3.0,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/javierwoodworks",
        username: "javierwoodworks"
      },
      {
        platform: "youtube",
        url: "https://youtube.com/c/javierwoodworks",
        username: "Javier's Woodworking"
      },
      {
        platform: "website",
        url: "https://javierwoodworks.com"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Furniture Repair", 
        price: 70,
        description: "Repair of damaged furniture including chairs, tables, cabinets, and other wooden items. Includes fixing structural issues and refinishing if needed.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1581244277943-fe4a9c777189?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-4 hours"
      },
      { 
        id: "2", 
        name: "Custom Shelving", 
        price: 150,
        description: "Design and installation of custom shelving units tailored to your space and needs. Includes consultation, material selection, and professional installation.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1594125674956-61a9b49c8ecc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "4-6 hours"
      },
      { 
        id: "3", 
        name: "Door Installation", 
        price: 90,
        description: "Professional installation of interior or exterior doors. Includes removal of old door, fitting and hanging of new door, and hardware installation.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1517646331032-9e8d5f373a70?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-3 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "109", 
        rating: 5, 
        comment: "Amazing craftsmanship! My table looks brand new after Javier's repair work. He's incredibly skilled and professional.", 
        date: "2023-10-08",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1611486212557-88be5ff6f941?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1611486212557-88be5ff6f941?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "110", 
        rating: 5, 
        comment: "Very skilled and professional. Javier built custom shelves for my living room and they're absolutely perfect. Great attention to detail.", 
        date: "2023-09-20" 
      },
    ],
  },
  {
    id: "p5-2",
    name: "Carmen Vargas",
    categoryId: "5",
    avatar: "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.8,
    reviewCount: 38,
    hourlyRate: 26,
    description: "Fine woodworking specialist with a focus on custom furniture design and creation. Combining traditional techniques with modern aesthetics.",
    location: "Panama City",
    distance: 2.8,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/carmenwoodcraft",
        username: "carmenwoodcraft"
      },
      {
        platform: "pinterest",
        url: "https://pinterest.com/carmenwoodcraft",
        username: "Carmen's Woodcraft"
      },
      {
        platform: "website",
        url: "https://carmenwoodcraft.com"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Custom Furniture Design", 
        price: 300,
        description: "Design and creation of custom furniture pieces tailored to your specifications. Includes consultation, sketches, material selection, and crafting.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1581244277943-fe4a9c777189?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "Varies by project"
      },
      { 
        id: "2", 
        name: "Wood Restoration", 
        price: 120,
        description: "Restoration of antique or damaged wooden furniture and items. Includes repair, refinishing, and preservation techniques to maintain original character.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1611486212557-88be5ff6f941?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "3-8 hours"
      },
      { 
        id: "3", 
        name: "Custom Cabinetry", 
        price: 250,
        description: "Design and installation of custom cabinets for kitchens, bathrooms, or other spaces. Includes measurement, design, construction, and installation.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1594125674956-61a9b49c8ecc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "Multiple days"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "119", 
        rating: 5, 
        comment: "Carmen created a custom dining table for our family and it's absolutely stunning. Her craftsmanship is exceptional and she was a pleasure to work with throughout the design process.", 
        date: "2023-10-15",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1581244277943-fe4a9c777189?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1581244277943-fe4a9c777189?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "120", 
        rating: 5, 
        comment: "We hired Carmen to restore an antique cabinet that's been in our family for generations. She did an incredible job preserving its character while making it functional again. Highly recommend!", 
        date: "2023-09-28" 
      },
    ],
  },
  {
    id: "p5-3",
    name: "Diego Reyes",
    categoryId: "5",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.7,
    reviewCount: 42,
    hourlyRate: 25,
    description: "Specializing in home renovations and carpentry projects. From kitchen remodels to custom built-ins, I bring quality craftsmanship to every project.",
    location: "David",
    distance: 4.9,
    available: true,
    socialMedia: [
      {
        platform: "facebook",
        url: "https://facebook.com/diegocarpentry",
        username: "Diego's Carpentry & Renovations"
      },
      {
        platform: "instagram",
        url: "https://instagram.com/diegocarpentry",
        username: "diegocarpentry"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Kitchen Renovation", 
        price: 500,
        description: "Carpentry work for kitchen renovations including cabinet installation, custom islands, pantries, and trim work. Coordination with other trades available.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1594125674956-61a9b49c8ecc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "5-10 days"
      },
      { 
        id: "2", 
        name: "Built-In Bookcases", 
        price: 200,
        description: "Custom built-in bookcases and shelving units designed to fit your space perfectly. Includes design, construction, and installation.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1594125674956-61a9b49c8ecc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-3 days"
      },
      { 
        id: "3", 
        name: "Deck Construction", 
        price: 350,
        description: "Design and construction of custom outdoor decks. Includes planning, material selection, construction, and finishing with stain or sealant.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1517646331032-9e8d5f373a70?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "3-5 days"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "121", 
        rating: 5, 
        comment: "Diego renovated our kitchen and the results are fantastic. His attention to detail and craftsmanship are evident in every aspect of the work. He stayed on schedule and was a pleasure to work with.", 
        date: "2023-10-05" 
      },
      { 
        id: "2", 
        userId: "122", 
        rating: 4, 
        comment: "We hired Diego to build custom bookcases in our living room and they look amazing. He took our ideas and improved upon them with his expertise. The only reason for 4 stars instead of 5 is that the project took a bit longer than estimated.", 
        date: "2023-09-18",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1594125674956-61a9b49c8ecc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1594125674956-61a9b49c8ecc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
    ],
  },

  // PAINTING PROFESSIONALS (Category 6)
  {
    id: "p6-1",
    name: "Gabriela Navarro",
    categoryId: "6",
    avatar: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.9,
    reviewCount: 68,
    hourlyRate: 22,
    description: "Professional painter with expertise in interior and exterior painting. Specializing in color consultation and premium finishes.",
    location: "Panama City",
    distance: 2.3,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/gabrielapaints",
        username: "gabrielapaints"
      },
      {
        platform: "facebook",
        url: "https://facebook.com/gabrielapainting",
        username: "Gabriela's Painting Services"
      },
      {
        platform: "pinterest",
        url: "https://pinterest.com/gabrielapaints",
        username: "Gabriela Paints"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Interior Painting", 
        price: 180,
        description: "Complete interior painting service for residential spaces. Includes surface preparation, priming, and application of premium paints in your choice of finish.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1562259929-b4e1fd230771?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-3 days"
      },
      { 
        id: "2", 
        name: "Exterior Painting", 
        price: 250,
        description: "Professional exterior painting for homes and buildings. Includes thorough preparation, repairs, priming, and application of weather-resistant paints.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1589939705384-5185137a7f0f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-5 days"
      },
      { 
        id: "3", 
        name: "Color Consultation", 
        price: 60,
        description: "Professional color consultation to help you select the perfect colors for your space. Includes color samples, mood boards, and personalized recommendations.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1615529328331-f8917597711f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-2 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "123", 
        rating: 5, 
        comment: "Gabriela painted our entire house interior and did an amazing job. Her attention to detail is impressive, and she helped us choose the perfect colors. The finish is flawless!", 
        date: "2023-10-20",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1562259929-b4e1fd230771?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1562259929-b4e1fd230771?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "124", 
        rating: 5, 
        comment: "We hired Gabriela for exterior painting and couldn't be happier. She was thorough with preparation, which I know is key for exterior work. The house looks brand new!", 
        date: "2023-09-25" 
      },
    ],
  },
  {
    id: "p6-2",
    name: "Hector Ramirez",
    categoryId: "6",
    avatar: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.7,
    reviewCount: 53,
    hourlyRate: 20,
    description: "Specialized in decorative painting techniques and murals. Creating unique, custom finishes and artwork for residential and commercial spaces.",
    location: "Panama City",
    distance: 3.1,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/hectorartpainting",
        username: "hectorartpainting"
      },
      {
        platform: "facebook",
        url: "https://facebook.com/hectorartpainting",
        username: "Hector's Decorative Painting"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Decorative Finishes", 
        price: 150,
        description: "Application of specialty decorative finishes including faux finishes, textured walls, metallic paints, and other custom techniques.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1615529328331-f8917597711f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-3 days"
      },
      { 
        id: "2", 
        name: "Custom Murals", 
        price: 300,
        description: "Hand-painted custom murals for interior or exterior walls. Includes design consultation, sketching, and painting of unique artwork tailored to your space.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1551913902-c92207136625?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-5 days"
      },
      { 
        id: "3", 
        name: "Furniture Painting", 
        price: 90,
        description: "Artistic painting and refinishing of furniture pieces. Includes preparation, painting with specialty paints, and protective finishing.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1562259929-b4e1fd230771?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-2 days"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "125", 
        rating: 5, 
        comment: "Hector created a stunning mural in our daughter's room that exceeded all expectations. His artistic talent is incredible, and he was a pleasure to work with from concept to completion.", 
        date: "2023-10-12",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1551913902-c92207136625?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1551913902-c92207136625?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "126", 
        rating: 4, 
        comment: "We hired Hector to apply a metallic finish in our dining room and it looks amazing. He's clearly very skilled with specialty finishes. The only reason for 4 stars is that it took a bit longer than expected.", 
        date: "2023-09-30" 
      },
    ],
  },
  {
    id: "p6-3",
    name: "Fernando Lopez",
    categoryId: "6",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.8,
    reviewCount: 61,
    hourlyRate: 21,
    description: "Commercial painting specialist with experience in office buildings, retail spaces, and industrial facilities. Efficient, clean, and minimally disruptive.",
    location: "David",
    distance: 5.2,
    available: true,
    socialMedia: [
      {
        platform: "facebook",
        url: "https://facebook.com/fernandocommercialpainting",
        username: "Fernando's Commercial Painting"
      },
      {
        platform: "linkedin",
        url: "https://linkedin.com/in/fernandolopez",
        username: "Fernando Lopez"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Commercial Interior Painting", 
        price: 300,
        description: "Professional painting services for commercial interiors including offices, retail spaces, and restaurants. Includes preparation, painting, and cleanup.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1562259929-b4e1fd230771?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-5 days"
      },
      { 
        id: "2", 
        name: "Industrial Painting", 
        price: 400,
        description: "Specialized painting for industrial facilities including warehouses, factories, and production areas. Uses durable, chemical-resistant coatings.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1589939705384-5185137a7f0f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-7 days"
      },
      { 
        id: "3", 
        name: "Epoxy Floor Coating", 
        price: 250,
        description: "Application of epoxy coatings for concrete floors in commercial and industrial spaces. Includes surface preparation, priming, and application of epoxy system.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1615529328331-f8917597711f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-3 days"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "127", 
        rating: 5, 
        comment: "Fernando and his team painted our entire office building over a weekend so there was no disruption to our business. The work was excellent, clean, and exactly what we wanted.", 
        date: "2023-10-08" 
      },
      { 
        id: "2", 
        userId: "128", 
        rating: 5, 
        comment: "We hired Fernando to apply epoxy coating in our warehouse and the results are fantastic. The floor looks amazing and is much more durable. His team was professional and efficient.", 
        date: "2023-09-22",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1615529328331-f8917597711f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1615529328331-f8917597711f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
    ],
  },

  // CATERING PROFESSIONALS (Category 7)
  {
    id: "p7-1",
    name: "Lucia Martinez",
    categoryId: "7",
    avatar: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.9,
    reviewCount: 72,
    hourlyRate: 30,
    description: "Professional chef and caterer specializing in Latin American cuisine. Creating memorable dining experiences for events of all sizes.",
    location: "Panama City",
    distance: 2.4,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/luciascatering",
        username: "luciascatering"
      },
      {
        platform: "facebook",
        url: "https://facebook.com/luciascatering",
        username: "Lucia's Catering"
      },
      {
        platform: "website",
        url: "https://luciascatering.com"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Full-Service Event Catering", 
        price: 35,
        description: "Complete catering service for events including menu planning, food preparation, service staff, and cleanup. Price is per person with minimum guest count.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1555244162-803834f70033?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "4-8 hours"
      },
      { 
        id: "2", 
        name: "Private Chef Experience", 
        price: 200,
        description: "Personalized in-home dining experience with a custom menu prepared in your kitchen. Includes grocery shopping, cooking, service, and kitchen cleanup.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1600565193348-f74bd3c7ccdf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "3-5 hours"
      },
      { 
        id: "3", 
        name: "Cooking Classes", 
        price: 45,
        description: "Interactive cooking classes for individuals or groups. Learn to prepare authentic Latin American dishes with professional techniques. Price is per person.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1556910103-1c02745aae4d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-3 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "129", 
        rating: 5, 
        comment: "Lucia catered our wedding and the food was absolutely amazing! Our guests are still talking about it months later. Her team was professional and the presentation was beautiful.", 
        date: "2023-10-18",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1555244162-803834f70033?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1555244162-803834f70033?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "130", 
        rating: 5, 
        comment: "We hired Lucia for a private chef experience for our anniversary and it was incredible. The food was restaurant quality but in the comfort of our home. She even left the kitchen cleaner than she found it!", 
        date: "2023-09-30" 
      },
    ],
  },
  {
    id: "p7-2",
    name: "Ricardo Flores",
    categoryId: "7",
    avatar: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.8,
    reviewCount: 58,
    hourlyRate: 28,
    description: "Pastry chef and dessert specialist. Creating stunning custom cakes, pastries, and dessert tables for special events and celebrations.",
    location: "Panama City",
    distance: 3.0,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/ricardosweets",
        username: "ricardosweets"
      },
      {
        platform: "facebook",
        url: "https://facebook.com/ricardosweets",
        username: "Ricardo's Sweet Creations"
      },
      {
        platform: "pinterest",
        url: "https://pinterest.com/ricardosweets",
        username: "Ricardo's Pastries"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Custom Cakes", 
        price: 120,
        description: "Handcrafted custom cakes for birthdays, weddings, and special occasions. Includes consultation, design, and creation of a cake tailored to your event.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "Consultation plus delivery"
      },
      { 
        id: "2", 
        name: "Dessert Table", 
        price: 300,
        description: "Complete dessert table setup for events including a variety of pastries, mini desserts, and sweet treats. Customized to your event theme and preferences.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1555244162-803834f70033?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "Setup plus event duration"
      },
      { 
        id: "3", 
        name: "Pastry Workshops", 
        price: 50,
        description: "Hands-on pastry workshops teaching techniques for creating professional-quality desserts. Includes all ingredients and equipment. Price is per person.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1556910103-1c02745aae4d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-3 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "131", 
        rating: 5, 
        comment: "Ricardo created the most beautiful and delicious wedding cake for us! It was exactly what we envisioned and tasted even better than it looked. He was a pleasure to work with throughout the process.", 
        date: "2023-10-15",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "132", 
        rating: 4, 
        comment: "We hired Ricardo for a dessert table at our corporate event and it was a huge hit. Everything was delicious and beautifully presented. The only reason for 4 stars is that one of the items we requested wasn't available.", 
        date: "2023-09-28" 
      },
    ],
  },
  {
    id: "p7-3",
    name: "Isabel Vega",
    categoryId: "7",
    avatar: "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.7,
    reviewCount: 49,
    hourlyRate: 26,
    description: "Specialized in corporate catering and business events. Providing professional food service for meetings, conferences, and company celebrations.",
    location: "Colon",
    distance: 4.7,
    available: true,
    socialMedia: [
      {
        platform: "linkedin",
        url: "https://linkedin.com/in/isabelvega",
        username: "Isabel Vega"
      },
      {
        platform: "facebook",
        url: "https://facebook.com/isabelcorporatecatering",
        username: "Isabel's Corporate Catering"
      },
      {
        platform: "website",
        url: "https://isabelcatering.com"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Business Lunch Catering", 
        price: 18,
        description: "Professional lunch catering for business meetings and corporate events. Includes setup, quality disposable serviceware, and cleanup. Price is per person.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1555244162-803834f70033?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-4 hours"
      },
      { 
        id: "2", 
        name: "Conference Catering", 
        price: 25,
        description: "Full-day catering service for conferences and seminars. Includes breakfast, lunch, and snack options with beverage service throughout the day. Price is per person.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1600565193348-f74bd3c7ccdf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "6-8 hours"
      },
      { 
        id: "3", 
        name: "Corporate Event Catering", 
        price: 35,
        description: "Premium catering for corporate events, holiday parties, and company celebrations. Includes appetizers, main courses, desserts, and professional service staff. Price is per person.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1555244162-803834f70033?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "4-6 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "133", 
        rating: 5, 
        comment: "Isabel has been handling our company's lunch meetings for months and always delivers excellent service. The food is consistently good, arrives on time, and is professionally presented.", 
        date: "2023-10-10" 
      },
      { 
        id: "2", 
        userId: "134", 
        rating: 4, 
        comment: "We hired Isabel for our annual company party and the food was excellent. Her team was professional and accommodating with dietary restrictions. The only issue was that they ran out of one dish earlier than expected.", 
        date: "2023-09-25",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1555244162-803834f70033?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1555244162-803834f70033?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
    ],
  },

  // MECHANIC PROFESSIONALS (Category 8)
  {
    id: "p8-1",
    name: "Antonio Ruiz",
    categoryId: "8",
    avatar: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.8,
    reviewCount: 76,
    hourlyRate: 35,
    description: "Certified auto mechanic with 15+ years of experience. Specializing in diagnostics, repairs, and maintenance for all vehicle makes and models.",
    location: "Panama City",
    distance: 2.6,
    available: true,
    socialMedia: [
      {
        platform: "facebook",
        url: "https://facebook.com/antonioautorepair",
        username: "Antonio's Auto Repair"
      },
      {
        platform: "instagram",
        url: "https://instagram.com/antonioautorepair",
        username: "antonioautorepair"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Vehicle Diagnostics", 
        price: 60,
        description: "Comprehensive diagnostic service to identify vehicle issues using professional-grade equipment. Includes detailed report and repair recommendations.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-2 hours"
      },
      { 
        id: "2", 
        name: "Brake Service", 
        price: 120,
        description: "Complete brake service including inspection, pad replacement, rotor resurfacing or replacement, and system testing. Includes parts and labor.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-3 hours"
      },
      { 
        id: "3", 
        name: "Oil Change Service", 
        price: 45,
        description: "Professional oil change service using high-quality oil and filters. Includes inspection of fluid levels, filters, and basic vehicle systems.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1635006459449-25c2109d011e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "30-45 minutes"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "135", 
        rating: 5, 
        comment: "Antonio is an excellent mechanic. He diagnosed and fixed an issue that two other shops couldn't figure out. Fair pricing, honest service, and great communication throughout the process.", 
        date: "2023-10-20",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "136", 
        rating: 5, 
        comment: "I've been taking my cars to Antonio for years and he never disappoints. He's thorough, explains everything clearly, and never tries to sell unnecessary services. Highly recommend!", 
        date: "2023-09-30" 
      },
    ],
  },
  {
    id: "p8-2",
    name: "Sofia Mendoza",
    categoryId: "8",
    avatar: "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.9,
    reviewCount: 64,
    hourlyRate: 38,
    description: "Specialized in European luxury vehicles including BMW, Mercedes, and Audi. Factory-trained with advanced diagnostic equipment and genuine parts.",
    location: "Panama City",
    distance: 3.2,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/sofiaeuroauto",
        username: "sofiaeuroauto"
      },
      {
        platform: "facebook",
        url: "https://facebook.com/sofiaeuroauto",
        username: "Sofia's European Auto"
      },
      {
        platform: "website",
        url: "https://sofiaeuroauto.com"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "European Vehicle Service", 
        price: 150,
        description: "Comprehensive service for European luxury vehicles following manufacturer specifications. Includes inspection, fluid changes, and system checks.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-4 hours"
      },
      { 
        id: "2", 
        name: "Performance Tuning", 
        price: 300,
        description: "Professional performance tuning for European vehicles. Includes diagnostic assessment, ECU programming, and performance testing.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "3-5 hours"
      },
      { 
        id: "3", 
        name: "Electrical System Diagnosis", 
        price: 90,
        description: "Specialized diagnosis of electrical and computer systems in European vehicles. Includes comprehensive testing and detailed report.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1635006459449-25c2109d011e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-2 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "137", 
        rating: 5, 
        comment: "Sofia is the only person I trust with my BMW. She knows these cars inside and out, uses genuine parts, and her prices are fair for the level of expertise she provides. Wouldn't go anywhere else!", 
        date: "2023-10-15" 
      },
      { 
        id: "2", 
        userId: "138", 
        rating: 5, 
        comment: "After dealerships quoted me thousands for repairs on my Audi, Sofia diagnosed the actual issue which was much simpler and less expensive. She's honest, knowledgeable, and saved me a lot of money.", 
        date: "2023-09-28",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
    ],
  },
  {
    id: "p8-3",
    name: "Miguel Ortega",
    categoryId: "8",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.7,
    reviewCount: 58,
    hourlyRate: 32,
    description: "Mobile mechanic bringing professional auto repair services to your home or office. Convenient, reliable service with transparent pricing.",
    location: "David",
    distance: 5.0,
    available: true,
    socialMedia: [
      {
        platform: "facebook",
        url: "https://facebook.com/miguelmobilemechanic",
        username: "Miguel's Mobile Mechanic"
      },
      {
        platform: "instagram",
        url: "https://instagram.com/miguelmobilemechanic",
        username: "miguelmobilemechanic"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Mobile Auto Repair", 
        price: 80,
        description: "Professional auto repair service at your location. Includes diagnostic assessment, repair work, and testing. Additional parts costs may apply.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1635006459449-25c2109d011e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "Varies by repair"
      },
      { 
        id: "2", 
        name: "On-Site Oil Change", 
        price: 55,
        description: "Convenient oil change service performed at your home or workplace. Includes premium oil, filter, and basic vehicle inspection.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1635006459449-25c2109d011e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "45-60 minutes"
      },
      { 
        id: "3", 
        name: "Pre-Purchase Inspection", 
        price: 100,
        description: "Thorough inspection of a vehicle you're considering purchasing. Includes mechanical assessment, test drive, and detailed report of findings.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-2 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "139", 
        rating: 5, 
        comment: "Miguel's mobile service is a game-changer! He came to my office while I was working and fixed my car in the parking lot. Saved me so much time and the quality of work was excellent.", 
        date: "2023-10-10" 
      },
      { 
        id: "2", 
        userId: "140", 
        rating: 4, 
        comment: "Great service! Miguel helped me avoid buying a car with hidden problems by doing a pre-purchase inspection. His report was detailed and he explained everything clearly. The only reason for 4 stars is that he was running a bit late.", 
        date: "2023-09-22",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
    ],
  },

  // ENTERTAINMENT PROFESSIONALS (Category 9)
  {
    id: "p9-1",
    name: "Carolina Jimenez",
    categoryId: "9",
    avatar: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.9,
    reviewCount: 82,
    hourlyRate: 120,
    description: "Professional DJ with experience in weddings, corporate events, and private parties. Creating the perfect atmosphere with music tailored to your event.",
    location: "Panama City",
    distance: 2.8,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/carolinadj",
        username: "carolinadj"
      },
      {
        platform: "facebook",
        url: "https://facebook.com/carolinadj",
        username: "Carolina DJ Services"
      },
      {
        platform: "soundcloud",
        url: "https://soundcloud.com/carolinadj",
        username: "Carolina DJ"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Wedding DJ Package", 
        price: 600,
        description: "Complete DJ service for weddings including ceremony music, cocktail hour, dinner, and reception. Includes professional sound system, lighting, and MC services.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1429962714451-bb934ecdc4ec?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "5-6 hours"
      },
      { 
        id: "2", 
        name: "Corporate Event DJ", 
        price: 450,
        description: "Professional DJ services for corporate events, holiday parties, and business functions. Includes appropriate music selection, announcements, and sound equipment.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "3-4 hours"
      },
      { 
        id: "3", 
        name: "Private Party DJ", 
        price: 350,
        description: "DJ services for birthday parties, anniversaries, and other private celebrations. Includes customized playlist, sound system, and basic lighting.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1516873240891-4bf014598ab4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "3-4 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "141", 
        rating: 5, 
        comment: "Carolina was the DJ for our wedding and she was absolutely amazing! She kept the dance floor packed all night and perfectly read the crowd. So many guests commented on how great the music was.", 
        date: "2023-10-18",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1429962714451-bb934ecdc4ec?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1429962714451-bb934ecdc4ec?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "142", 
        rating: 5, 
        comment: "We hired Carolina for our company holiday party and she was fantastic. Professional, well-prepared, and played the perfect mix of music. Everyone had a great time and she was easy to work with from start to finish.", 
        date: "2023-09-30" 
      },
    ],
  },
  {
    id: "p9-2",
    name: "Alejandro Vargas",
    categoryId: "9",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.8,
    reviewCount: 65,
    hourlyRate: 150,
    description: "Professional live musician and band leader. Providing live music for weddings, corporate events, and private parties with a repertoire spanning multiple genres.",
    location: "Panama City",
    distance: 3.5,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/alejandromusic",
        username: "alejandromusic"
      },
      {
        platform: "facebook",
        url: "https://facebook.com/alejandromusic",
        username: "Alejandro & The Rhythms"
      },
      {
        platform: "youtube",
        url: "https://youtube.com/c/alejandromusic",
        username: "Alejandro Music"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Live Band Performance", 
        price: 800,
        description: "Full band performance for weddings, corporate events, and private parties. Includes professional sound equipment, lighting, and a diverse repertoire of music.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "3-4 hours"
      },
      { 
        id: "2", 
        name: "Acoustic Solo Performance", 
        price: 300,
        description: "Intimate acoustic performance perfect for ceremonies, cocktail hours, or smaller gatherings. Includes professional sound equipment and personalized song selection.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-2 hours"
      },
      { 
        id: "3", 
        name: "Custom Song Recording", 
        price: 250,
        description: "Professional recording of a custom song for special occasions, proposals, or gifts. Includes consultation, arrangement, recording, and digital delivery.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1516873240891-4bf014598ab4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "Production time varies"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "143", 
        rating: 5, 
        comment: "Alejandro and his band performed at our wedding and were absolutely incredible! They had everyone dancing all night long and were so accommodating with our special song requests. Highly recommend!", 
        date: "2023-10-15",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "144", 
        rating: 5, 
        comment: "We hired Alejandro for an acoustic set during our cocktail hour and it was perfect. His voice is amazing and he created exactly the atmosphere we wanted. Very professional and talented!", 
        date: "2023-09-25" 
      },
    ],
  },
  {
    id: "p9-3",
    name: "Valentina Rojas",
    categoryId: "9",
    avatar: "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.9,
    reviewCount: 71,
    hourlyRate: 100,
    description: "Professional event entertainer specializing in children's parties. Offering character performances, face painting, balloon art, and interactive games.",
    location: "David",
    distance: 4.9,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/valentinaparties",
        username: "valentinaparties"
      },
      {
        platform: "facebook",
        url: "https://facebook.com/valentinaparties",
        username: "Valentina's Party Entertainment"
      },
      {
        platform: "tiktok",
        url: "https://tiktok.com/@valentinaparties",
        username: "@valentinaparties"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Character Performance", 
        price: 180,
        description: "Interactive character performance for children's parties. Includes costume, themed activities, games, and photo opportunities. Various characters available.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1 hour"
      },
      { 
        id: "2", 
        name: "Face Painting & Balloon Art", 
        price: 150,
        description: "Professional face painting and balloon art for children's parties and events. Includes a variety of designs and all supplies.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1516873240891-4bf014598ab4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2 hours"
      },
      { 
        id: "3", 
        name: "Complete Party Package", 
        price: 300,
        description: "Comprehensive entertainment package including character performance, face painting, balloon art, games, and activities. Perfect for children's birthday parties.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "3 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "145", 
        rating: 5, 
        comment: "Valentina was amazing at my daughter's 5th birthday party! She came as a princess character and the kids were absolutely mesmerized. Her face painting was beautiful and the balloon animals were a huge hit. Worth every penny!", 
        date: "2023-10-10",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "146", 
        rating: 5, 
        comment: "We hired Valentina for our community event and she was fantastic with the children. Professional, punctual, and incredibly talented. The face painting was especially impressive - true artistic talent!", 
        date: "2023-09-20" 
      },
    ],
  },

  // DECORATING PROFESSIONALS (Category 10)
  {
    id: "p10-1",
    name: "Isabella Moreno",
    categoryId: "10",
    avatar: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.9,
    reviewCount: 68,
    hourlyRate: 45,
    description: "Interior decorator and stylist with an eye for creating beautiful, functional spaces. Specializing in residential design and home staging.",
    location: "Panama City",
    distance: 2.7,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/isabellainteriors",
        username: "isabellainteriors"
      },
      {
        platform: "pinterest",
        url: "https://pinterest.com/isabellainteriors",
        username: "Isabella Interiors"
      },
      {
        platform: "website",
        url: "https://isabellainteriors.com"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Interior Decoration Consultation", 
        price: 150,
        description: "In-home consultation to assess your space and provide design recommendations. Includes color schemes, furniture layout, and styling suggestions.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2 hours"
      },
      { 
        id: "2", 
        name: "Room Styling", 
        price: 300,
        description: "Complete styling of a single room using your existing furniture and new accessories as needed. Includes shopping list, arrangement, and final styling.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1 day"
      },
      { 
        id: "3", 
        name: "Home Staging", 
        price: 500,
        description: "Professional staging service for homes on the market. Enhances your property's appeal to potential buyers through strategic furniture and decor placement.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1-2 days"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "147", 
        rating: 5, 
        comment: "Isabella transformed our living room with just a consultation and some styling! She has an amazing eye for design and worked within our budget to create a space we love. Highly recommend her services.", 
        date: "2023-10-20",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "148", 
        rating: 5, 
        comment: "We hired Isabella to stage our home before selling and it made a huge difference! The house sold in just one week for above asking price. Her staging highlighted all the best features of our home. Worth every penny!", 
        date: "2023-09-30" 
      },
    ],
  },
  {
    id: "p10-2",
    name: "Rafael Guzman",
    categoryId: "10",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.8,
    reviewCount: 54,
    hourlyRate: 50,
    description: "Event decorator specializing in weddings, corporate events, and special celebrations. Creating stunning, memorable environments for all occasions.",
    location: "Panama City",
    distance: 3.2,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/rafaelevents",
        username: "rafaelevents"
      },
      {
        platform: "facebook",
        url: "https://facebook.com/rafaelevents",
        username: "Rafael Event Design"
      },
      {
        platform: "pinterest",
        url: "https://pinterest.com/rafaelevents",
        username: "Rafael Events"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Wedding Decoration", 
        price: 1200,
        description: "Complete wedding decoration service including ceremony and reception spaces. Includes consultation, design plan, setup, and breakdown.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1519741497674-611481863552?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "Setup day before/day of event"
      },
      { 
        id: "2", 
        name: "Corporate Event Decor", 
        price: 800,
        description: "Professional decoration for corporate events, galas, and business functions. Includes theme development, decor elements, and installation.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1505236858219-8359eb29e329?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "Setup day of event"
      },
      { 
        id: "3", 
        name: "Special Occasion Decoration", 
        price: 500,
        description: "Decoration services for birthdays, anniversaries, baby showers, and other special celebrations. Customized to your event theme and venue.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1464047736614-af63643285bf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "Setup day of event"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "149", 
        rating: 5, 
        comment: "Rafael decorated our wedding and exceeded all expectations! The venue was transformed into something magical and exactly matched our vision. His attention to detail is incredible and he was a pleasure to work with throughout the planning process.", 
        date: "2023-10-15",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1519741497674-611481863552?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1519741497674-611481863552?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "150", 
        rating: 4, 
        comment: "We hired Rafael for our company gala and the decor was stunning. He created an elegant atmosphere that impressed all our guests and clients. The only reason for 4 stars instead of 5 is that setup ran a bit behind schedule, but everything was perfect by the time the event started.", 
        date: "2023-09-28" 
      },
    ],
  },
  {
    id: "p10-3",
    name: "Camila Herrera",
    categoryId: "10",
    avatar: "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.7,
    reviewCount: 47,
    hourlyRate: 40,
    description: "Holiday and seasonal decorator for homes and businesses. Creating festive environments for Christmas, Halloween, and other special occasions.",
    location: "David",
    distance: 5.1,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/camilaholidaydecor",
        username: "camilaholidaydecor"
      },
      {
        platform: "facebook",
        url: "https://facebook.com/camilaholidaydecor",
        username: "Camila's Holiday Decorating"
      },
      {
        platform: "pinterest",
        url: "https://pinterest.com/camilaholidaydecor",
        username: "Camila's Holiday Decor"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Christmas Decoration", 
        price: 350,
        description: "Complete Christmas decoration service for homes or businesses. Includes tree setup and decoration, lighting, garlands, and festive accents.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1603794067602-9feaa4f70e0c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "4-6 hours"
      },
      { 
        id: "2", 
        name: "Halloween Decoration", 
        price: 250,
        description: "Spooky or family-friendly Halloween decorations for your home or business. Includes themed displays, lighting, and special effects.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1508731382312-c7191c6bfc4b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "3-5 hours"
      },
      { 
        id: "3", 
        name: "Seasonal Decoration Package", 
        price: 800,
        description: "Year-round decoration service with seasonal changes for homes or businesses. Includes four seasonal installations with all materials and setup.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1603794067602-9feaa4f70e0c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "Quarterly installations"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "151", 
        rating: 5, 
        comment: "Camila decorated our home for Christmas and it was magical! She transformed our space into a winter wonderland that delighted our family and guests. Her attention to detail and creative touches made all the difference.", 
        date: "2023-10-05",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1603794067602-9feaa4f70e0c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1603794067602-9feaa4f70e0c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "152", 
        rating: 4, 
        comment: "We hired Camila for our business's seasonal decoration package and have been very pleased with the results. Each season brings a fresh look that our customers love. The only reason for 4 stars is that sometimes the installations take longer than expected.", 
        date: "2023-09-20" 
      },
    ],
  },

  // ACADEMICS PROFESSIONALS (Category 11)
  {
    id: "p11-1",
    name: "Eduardo Mendez",
    categoryId: "11",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.9,
    reviewCount: 83,
    hourlyRate: 30,
    description: "Mathematics and physics tutor with 12 years of teaching experience. Specializing in high school and university level courses with a focus on building strong foundations.",
    location: "Panama City",
    distance: 2.5,
    available: true,
    socialMedia: [
      {
        platform: "facebook",
        url: "https://facebook.com/eduardomathtutoring",
        username: "Eduardo's Math & Physics Tutoring"
      },
      {
        platform: "linkedin",
        url: "https://linkedin.com/in/eduardomendez",
        username: "Eduardo Mendez"
      },
      {
        platform: "website",
        url: "https://eduardotutoring.com"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Math Tutoring", 
        price: 35,
        description: "One-on-one tutoring for mathematics subjects including algebra, calculus, geometry, and statistics. Customized to student's curriculum and learning style.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1 hour"
      },
      { 
        id: "2", 
        name: "Physics Tutoring", 
        price: 35,
        description: "Personalized physics tutoring covering mechanics, electricity, magnetism, thermodynamics, and modern physics. Includes problem-solving techniques and exam preparation.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1 hour"
      },
      { 
        id: "3", 
        name: "Exam Preparation", 
        price: 40,
        description: "Intensive preparation for standardized tests, final exams, and college entrance exams. Focuses on test-taking strategies and comprehensive content review.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1.5 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "153", 
        rating: 5, 
        comment: "Eduardo is an exceptional math tutor! He helped my son go from struggling with calculus to earning an A in the class. He explains concepts clearly and is patient with questions. Highly recommend!", 
        date: "2023-10-18" 
      },
      { 
        id: "2", 
        userId: "154", 
        rating: 5, 
        comment: "I was failing physics before I started working with Eduardo. His tutoring completely turned things around for me. He has a gift for making complex concepts understandable and builds your confidence along the way.", 
        date: "2023-09-30",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
    ],
  },
  {
    id: "p11-2",
    name: "Gabriela Santos",
    categoryId: "11",
    avatar: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.8,
    reviewCount: 75,
    hourlyRate: 28,
    description: "Language tutor specializing in Spanish, English, and Portuguese. Certified language instructor with experience teaching students of all ages and proficiency levels.",
    location: "Panama City",
    distance: 3.0,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/gabrielalanguages",
        username: "gabrielalanguages"
      },
      {
        platform: "facebook",
        url: "https://facebook.com/gabrielalanguages",
        username: "Gabriela's Language Tutoring"
      },
      {
        platform: "website",
        url: "https://gabrielalanguages.com"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Spanish Lessons", 
        price: 30,
        description: "Personalized Spanish language instruction for beginners to advanced learners. Focuses on conversation, grammar, reading, and writing skills.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1 hour"
      },
      { 
        id: "2", 
        name: "English as a Second Language", 
        price: 30,
        description: "ESL instruction tailored to your proficiency level and goals. Includes pronunciation, vocabulary building, grammar, and conversational practice.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1 hour"
      },
      { 
        id: "3", 
        name: "Business Language Training", 
        price: 40,
        description: "Specialized language instruction for business professionals. Focuses on industry-specific vocabulary, presentation skills, and business communication.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1 hour"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "155", 
        rating: 5, 
        comment: "Gabriela is an amazing Spanish teacher! I've been taking lessons with her for 6 months and my progress has been incredible. She makes learning fun and adapts her teaching style to how I learn best.", 
        date: "2023-10-15",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "156", 
        rating: 4, 
        comment: "I hired Gabriela for business English training before an international assignment. Her focus on relevant vocabulary and business communication was exactly what I needed. The only reason for 4 stars is that sometimes lessons ran a bit over time.", 
        date: "2023-09-25" 
      },
    ],
  },
  {
    id: "p11-3",
    name: "Mateo Rivera",
    categoryId: "11",
    avatar: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.7,
    reviewCount: 61,
    hourlyRate: 32,
    description: "Computer science and programming tutor with expertise in multiple languages and frameworks. Helping students and professionals develop coding skills and complete projects.",
    location: "Colon",
    distance: 4.5,
    available: true,
    socialMedia: [
      {
        platform: "github",
        url: "https://github.com/mateorivera",
        username: "mateorivera"
      },
      {
        platform: "linkedin",
        url: "https://linkedin.com/in/mateorivera",
        username: "Mateo Rivera"
      },
      {
        platform: "website",
        url: "https://mateocoding.com"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Programming Tutoring", 
        price: 35,
        description: "One-on-one tutoring for programming languages including Python, Java, JavaScript, and C++. Customized to your learning goals and experience level.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1 hour"
      },
      { 
        id: "2", 
        name: "Web Development Coaching", 
        price: 40,
        description: "Hands-on coaching for web development using HTML, CSS, JavaScript, and popular frameworks. Includes project guidance and code reviews.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1 hour"
      },
      { 
        id: "3", 
        name: "Project Assistance", 
        price: 45,
        description: "Support for computer science projects and assignments. Includes problem-solving, debugging, and guidance on best practices and implementation.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1 hour"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "157", 
        rating: 5, 
        comment: "Mateo is an excellent programming tutor! He helped me understand complex concepts in Python and guided me through building my first real application. He's patient, knowledgeable, and explains things in a way that's easy to understand.", 
        date: "2023-10-10" 
      },
      { 
        id: "2", 
        userId: "158", 
        rating: 4, 
        comment: "I hired Mateo for help with a web development project and he was incredibly helpful. He identified issues in my code quickly and taught me better approaches. The only reason for 4 stars is that sometimes our sessions went over the scheduled time.", 
        date: "2023-09-20",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
    ],
  },

  // BEAUTY PROFESSIONALS (Category 12)
  {
    id: "p12-1",
    name: "Sofia Ramirez",
    categoryId: "12",
    avatar: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.9,
    reviewCount: 94,
    hourlyRate: 45,
    description: "Professional makeup artist with experience in bridal, special occasion, and editorial makeup. Creating beautiful, personalized looks for all skin types and tones.",
    location: "Panama City",
    distance: 2.4,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/sofiamakeup",
        username: "sofiamakeup"
      },
      {
        platform: "facebook",
        url: "https://facebook.com/sofiamakeup",
        username: "Sofia Ramirez Makeup Artistry"
      },
      {
        platform: "tiktok",
        url: "https://tiktok.com/@sofiamakeup",
        username: "@sofiamakeup"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Bridal Makeup", 
        price: 120,
        description: "Complete bridal makeup service including consultation, trial, and day-of application. Uses high-quality, long-lasting products for a flawless look.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1.5 hours"
      },
      { 
        id: "2", 
        name: "Special Occasion Makeup", 
        price: 80,
        description: "Professional makeup application for special events, parties, and celebrations. Customized to complement your outfit, event, and personal style.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1503236823255-94609f598e71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1 hour"
      },
      { 
        id: "3", 
        name: "Makeup Lesson", 
        price: 90,
        description: "Personalized makeup lesson teaching techniques tailored to your features and preferences. Includes product recommendations and step-by-step instruction.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1.5 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "159", 
        rating: 5, 
        comment: "Sofia did my bridal makeup and I couldn't have been happier! She listened to exactly what I wanted and created a look that felt like me but elevated. My makeup lasted all day and photographed beautifully.", 
        date: "2023-10-20",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "160", 
        rating: 5, 
        comment: "I booked a makeup lesson with Sofia and learned so much! She taught me techniques specific to my eye shape and showed me how to apply products I already owned in better ways. Worth every penny for the confidence it's given me.", 
        date: "2023-09-30" 
      },
    ],
  },
  {
    id: "p12-2",
    name: "Daniela Ortiz",
    categoryId: "12",
    avatar: "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.8,
    reviewCount: 78,
    hourlyRate: 40,
    description: "Professional hairstylist specializing in cuts, color, and styling. Creating beautiful, manageable hairstyles tailored to each client's features and lifestyle.",
    location: "Panama City",
    distance: 3.1,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/danielahair",
        username: "danielahair"
      },
      {
        platform: "facebook",
        url: "https://facebook.com/danielahair",
        username: "Daniela Ortiz Hair Design"
      },
      {
        platform: "pinterest",
        url: "https://pinterest.com/danielahair",
        username: "Daniela Hair"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Haircut & Style", 
        price: 55,
        description: "Professional haircut and styling service. Includes consultation, shampoo, precision cut, and blow dry styling tailored to your preferences.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1560869713-7d0a29430803?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1 hour"
      },
      { 
        id: "2", 
        name: "Hair Color", 
        price: 90,
        description: "Professional hair coloring service including root touch-ups, all-over color, or highlights. Consultation to determine the best color for your skin tone and style.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1562322140-8baeececf3df?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "2-3 hours"
      },
      { 
        id: "3", 
        name: "Bridal Hair", 
        price: 120,
        description: "Complete bridal hair service including consultation, trial, and day-of styling. Creates elegant, long-lasting styles for your special day.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1560869713-7d0a29430803?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "1.5 hours"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "161", 
        rating: 5, 
        comment: "Daniela is an amazing hairstylist! She gave me the best haircut I've ever had - she really listened to what I wanted and offered suggestions based on my face shape and hair texture. I've received so many compliments!", 
        date: "2023-10-15",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1560869713-7d0a29430803?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1560869713-7d0a29430803?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "162", 
        rating: 4, 
        comment: "I've been going to Daniela for color for over a year and she always does a fantastic job. She's great at creating natural-looking highlights that grow out beautifully. The only reason for 4 stars instead of 5 is that appointments sometimes run a bit behind schedule.", 
        date: "2023-09-28" 
      },
    ],
  },
  {
    id: "p12-3",
    name: "Manuel Torres",
    categoryId: "12",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=256&q=80",
    rating: 4.7,
    reviewCount: 65,
    hourlyRate: 35,
    description: "Professional barber specializing in men's haircuts, beard grooming, and traditional straight razor shaves. Creating clean, precise styles with attention to detail.",
    location: "David",
    distance: 5.3,
    available: true,
    socialMedia: [
      {
        platform: "instagram",
        url: "https://instagram.com/manuelbarbershop",
        username: "manuelbarbershop"
      },
      {
        platform: "facebook",
        url: "https://facebook.com/manuelbarbershop",
        username: "Manuel's Classic Barbershop"
      }
    ],
    services: [
      { 
        id: "1", 
        name: "Men's Haircut", 
        price: 25,
        description: "Professional men's haircut service. Includes consultation, shampoo, precision cut, and styling with quality products.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "45 minutes"
      },
      { 
        id: "2", 
        name: "Beard Trim & Shape", 
        price: 15,
        description: "Professional beard grooming service. Includes trimming, shaping, and styling to enhance your facial features and maintain a well-groomed appearance.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1621605815971-fbc98d665033?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "30 minutes"
      },
      { 
        id: "3", 
        name: "Traditional Straight Razor Shave", 
        price: 30,
        description: "Classic straight razor shave experience. Includes hot towel treatment, pre-shave oil, precision shave, and aftershave balm for a smooth, comfortable finish.",
        media: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
          }
        ],
        duration: "45 minutes"
      },
    ],
    reviews: [
      { 
        id: "1", 
        userId: "163", 
        rating: 5, 
        comment: "Manuel gives the best haircuts I've ever had. He takes his time to understand exactly what you want and has amazing attention to detail. The straight razor shave is an experience every man should try at least once!", 
        date: "2023-10-10",
        images: [
          {
            id: "img1",
            type: "image",
            url: "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            thumbnailUrl: "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&q=80"
          }
        ]
      },
      { 
        id: "2", 
        userId: "164", 
        rating: 4, 
        comment: "Great barber! Manuel shaped my beard perfectly and gave me some good tips for maintaining it between visits. The only reason for 4 stars is that the shop can get quite busy so sometimes there's a wait even with an appointment.", 
        date: "2023-09-22" 
      },
    ],
  },
];