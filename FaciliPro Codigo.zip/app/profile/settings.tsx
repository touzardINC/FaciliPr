import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  Switch,
  TouchableOpacity,
  Alert,
  Platform,
} from "react-native";
import { Stack, useRouter } from "expo-router";
import {
  Bell,
  Moon,
  Globe,
  Lock,
  Trash2,
  ChevronRight,
  LogOut,
} from "lucide-react-native";
import Colors from "@/constants/colors";
import { useAuthStore } from "@/store/auth-store";

export default function SettingsScreen() {
  const router = useRouter();
  const { logout } = useAuthStore();
  
  // Notification settings
  const [pushNotifications, setPushNotifications] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [bookingReminders, setBookingReminders] = useState(true);
  const [marketingEmails, setMarketingEmails] = useState(false);
  
  // Appearance settings
  const [darkMode, setDarkMode] = useState(false);
  
  // Language settings
  const [language, setLanguage] = useState("English");
  
  const handleLanguageSelection = () => {
    Alert.alert(
      "Select Language",
      "Choose your preferred language",
      [
        { text: "English", onPress: () => setLanguage("English") },
        { text: "Spanish", onPress: () => setLanguage("Spanish") },
        { text: "French", onPress: () => setLanguage("French") },
        { text: "German", onPress: () => setLanguage("German") },
        { text: "Cancel", style: "cancel" }
      ]
    );
  };
  
  const handleDeleteAccount = () => {
    Alert.alert(
      "Delete Account",
      "Are you sure you want to delete your account? This action cannot be undone.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          onPress: () => {
            // In a real app, this would delete the user's account
            Alert.alert(
              "Account Deleted",
              "Your account has been successfully deleted.",
              [
                {
                  text: "OK",
                  onPress: () => {
                    logout();
                    router.replace("/");
                  }
                }
              ]
            );
          },
          style: "destructive"
        }
      ]
    );
  };
  
  const handleLogout = () => {
    Alert.alert(
      "Logout",
      "Are you sure you want to logout?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Logout",
          onPress: () => {
            logout();
            router.replace("/");
          },
          style: "destructive"
        }
      ]
    );
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <Stack.Screen options={{ title: "Settings" }} />
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Notifications</Text>
        
        <View style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <Text style={styles.settingLabel}>Push Notifications</Text>
            <Text style={styles.settingDescription}>
              Receive push notifications for bookings and updates
            </Text>
          </View>
          <Switch
            value={pushNotifications}
            onValueChange={setPushNotifications}
            trackColor={{ false: Colors.border, true: Colors.primary }}
            thumbColor={Colors.white}
          />
        </View>
        
        <View style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <Text style={styles.settingLabel}>Email Notifications</Text>
            <Text style={styles.settingDescription}>
              Receive email notifications for bookings and updates
            </Text>
          </View>
          <Switch
            value={emailNotifications}
            onValueChange={setEmailNotifications}
            trackColor={{ false: Colors.border, true: Colors.primary }}
            thumbColor={Colors.white}
          />
        </View>
        
        <View style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <Text style={styles.settingLabel}>Booking Reminders</Text>
            <Text style={styles.settingDescription}>
              Receive reminders before your scheduled bookings
            </Text>
          </View>
          <Switch
            value={bookingReminders}
            onValueChange={setBookingReminders}
            trackColor={{ false: Colors.border, true: Colors.primary }}
            thumbColor={Colors.white}
          />
        </View>
        
        <View style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <Text style={styles.settingLabel}>Marketing Emails</Text>
            <Text style={styles.settingDescription}>
              Receive promotional emails and special offers
            </Text>
          </View>
          <Switch
            value={marketingEmails}
            onValueChange={setMarketingEmails}
            trackColor={{ false: Colors.border, true: Colors.primary }}
            thumbColor={Colors.white}
          />
        </View>
        
        <TouchableOpacity
          style={styles.linkItem}
          onPress={() => router.push("/profile/notifications")}
        >
          <View style={styles.linkItemLeft}>
            <Bell size={20} color={Colors.primary} />
            <Text style={styles.linkItemText}>Advanced Notification Settings</Text>
          </View>
          <ChevronRight size={20} color={Colors.text.secondary} />
        </TouchableOpacity>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Appearance</Text>
        
        <View style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <Text style={styles.settingLabel}>Dark Mode</Text>
            <Text style={styles.settingDescription}>
              Switch between light and dark themes
            </Text>
          </View>
          <Switch
            value={darkMode}
            onValueChange={setDarkMode}
            trackColor={{ false: Colors.border, true: Colors.primary }}
            thumbColor={Colors.white}
          />
        </View>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Language & Region</Text>
        
        <TouchableOpacity
          style={styles.selectItem}
          onPress={handleLanguageSelection}
        >
          <View style={styles.selectItemLeft}>
            <Globe size={20} color={Colors.primary} />
            <View>
              <Text style={styles.selectItemLabel}>Language</Text>
              <Text style={styles.selectItemValue}>{language}</Text>
            </View>
          </View>
          <ChevronRight size={20} color={Colors.text.secondary} />
        </TouchableOpacity>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Privacy & Security</Text>
        
        <TouchableOpacity
          style={styles.linkItem}
          onPress={() => {
            // In a real app, this would navigate to the privacy settings
            Alert.alert(
              "Privacy Settings",
              "This would navigate to privacy settings",
              [{ text: "OK" }]
            );
          }}
        >
          <View style={styles.linkItemLeft}>
            <Lock size={20} color={Colors.primary} />
            <Text style={styles.linkItemText}>Privacy Settings</Text>
          </View>
          <ChevronRight size={20} color={Colors.text.secondary} />
        </TouchableOpacity>
        
        <TouchableOpacity
          style={styles.linkItem}
          onPress={() => {
            // In a real app, this would navigate to the change password screen
            Alert.alert(
              "Change Password",
              "This would navigate to change password screen",
              [{ text: "OK" }]
            );
          }}
        >
          <View style={styles.linkItemLeft}>
            <Lock size={20} color={Colors.primary} />
            <Text style={styles.linkItemText}>Change Password</Text>
          </View>
          <ChevronRight size={20} color={Colors.text.secondary} />
        </TouchableOpacity>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Account</Text>
        
        <TouchableOpacity
          style={[styles.linkItem, styles.dangerItem]}
          onPress={handleDeleteAccount}
        >
          <View style={styles.linkItemLeft}>
            <Trash2 size={20} color={Colors.error} />
            <Text style={[styles.linkItemText, styles.dangerText]}>Delete Account</Text>
          </View>
          <ChevronRight size={20} color={Colors.text.secondary} />
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.linkItem, styles.dangerItem]}
          onPress={handleLogout}
        >
          <View style={styles.linkItemLeft}>
            <LogOut size={20} color={Colors.error} />
            <Text style={[styles.linkItemText, styles.dangerText]}>Logout</Text>
          </View>
          <ChevronRight size={20} color={Colors.text.secondary} />
        </TouchableOpacity>
      </View>
      
      <View style={styles.appInfo}>
        <Text style={styles.appVersion}>Version 1.0.0</Text>
        {Platform.OS === "ios" && (
          <Text style={styles.appBuild}>Build 2023.10.15.1</Text>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  section: {
    backgroundColor: Colors.white,
    marginBottom: 16,
    paddingVertical: 8,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.text.primary,
    marginVertical: 8,
    paddingHorizontal: 16,
  },
  settingItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  settingInfo: {
    flex: 1,
    paddingRight: 16,
  },
  settingLabel: {
    fontSize: 16,
    color: Colors.text.primary,
    marginBottom: 4,
  },
  settingDescription: {
    fontSize: 14,
    color: Colors.text.secondary,
  },
  linkItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  linkItemLeft: {
    flexDirection: "row",
    alignItems: "center",
  },
  linkItemText: {
    fontSize: 16,
    color: Colors.text.primary,
    marginLeft: 12,
  },
  selectItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  selectItemLeft: {
    flexDirection: "row",
    alignItems: "center",
  },
  selectItemLabel: {
    fontSize: 16,
    color: Colors.text.primary,
    marginLeft: 12,
  },
  selectItemValue: {
    fontSize: 14,
    color: Colors.text.secondary,
    marginLeft: 12,
  },
  dangerItem: {
    borderBottomWidth: 0,
  },
  dangerText: {
    color: Colors.error,
  },
  appInfo: {
    alignItems: "center",
    paddingVertical: 24,
    paddingHorizontal: 16,
  },
  appVersion: {
    fontSize: 14,
    color: Colors.text.secondary,
  },
  appBuild: {
    fontSize: 12,
    color: Colors.text.placeholder,
  },
});