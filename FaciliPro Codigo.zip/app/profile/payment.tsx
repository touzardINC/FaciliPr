import React, { useEffect, useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  ActivityIndicator,
} from "react-native";
import { useRouter, Stack } from "expo-router";
import { PlusCircle } from "lucide-react-native";
import Colors from "@/constants/colors";
import { usePaymentStore } from "@/store/payment-store";
import { useAuthStore } from "@/store/auth-store";
import PaymentMethodCard from "@/components/PaymentMethodCard";
import Button from "@/components/Button";

export default function PaymentMethodsScreen() {
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();
  const { paymentMethods, getPaymentMethods, removePaymentMethod, setDefaultPaymentMethod, isLoading } = usePaymentStore();

  useEffect(() => {
    if (isAuthenticated) {
      getPaymentMethods();
    }
  }, [isAuthenticated]);

  const handleAddPaymentMethod = () => {
    router.push("/profile/payment/add");
  };

  const handleDeletePaymentMethod = (id: string) => {
    Alert.alert(
      "Remove Payment Method",
      "Are you sure you want to remove this payment method?",
      [
        {
          text: "Cancel",
          style: "cancel",
        },
        {
          text: "Remove",
          onPress: async () => {
            try {
              await removePaymentMethod(id);
              Alert.alert("Success", "Payment method removed successfully");
            } catch (error) {
              Alert.alert("Error", "Failed to remove payment method");
            }
          },
          style: "destructive",
        },
      ]
    );
  };

  const handleSetDefaultPaymentMethod = async (id: string) => {
    try {
      await setDefaultPaymentMethod(id);
    } catch (error) {
      Alert.alert("Error", "Failed to set default payment method");
    }
  };

  if (!isAuthenticated) {
    return (
      <SafeAreaView style={styles.container}>
        <Stack.Screen options={{ title: "Payment Methods" }} />
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyTitle}>Sign in to manage payment methods</Text>
          <Button
            title="Sign In"
            onPress={() => router.push("/login")}
            style={styles.signInButton}
          />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen options={{ title: "Payment Methods" }} />
      
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={styles.title}>Your Payment Methods</Text>
          <Text style={styles.subtitle}>
            Manage your saved payment methods for quick checkout
          </Text>
        </View>

        <TouchableOpacity
          style={styles.addButton}
          onPress={handleAddPaymentMethod}
        >
          <PlusCircle size={24} color={Colors.primary} />
          <Text style={styles.addButtonText}>Add Payment Method</Text>
        </TouchableOpacity>

        {isLoading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={Colors.primary} />
            <Text style={styles.loadingText}>Loading payment methods...</Text>
          </View>
        ) : paymentMethods.length === 0 ? (
          <View style={styles.emptyListContainer}>
            <Text style={styles.emptyListTitle}>No payment methods</Text>
            <Text style={styles.emptyListText}>
              Add a payment method to make booking services easier
            </Text>
          </View>
        ) : (
          <View style={styles.paymentMethodsContainer}>
            {paymentMethods.map((paymentMethod) => (
              <PaymentMethodCard
                key={paymentMethod.id}
                paymentMethod={paymentMethod}
                onDelete={handleDeletePaymentMethod}
                onSetDefault={handleSetDefaultPaymentMethod}
              />
            ))}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 32,
  },
  header: {
    marginBottom: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: "700",
    color: Colors.text.primary,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: Colors.text.secondary,
  },
  addButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    borderWidth: 1,
    borderStyle: "dashed",
    borderColor: Colors.primary,
  },
  addButtonText: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.primary,
    marginLeft: 12,
  },
  paymentMethodsContainer: {
    marginBottom: 16,
  },
  loadingContainer: {
    alignItems: "center",
    justifyContent: "center",
    padding: 32,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: Colors.text.secondary,
  },
  emptyListContainer: {
    alignItems: "center",
    justifyContent: "center",
    padding: 32,
    backgroundColor: Colors.white,
    borderRadius: 12,
  },
  emptyListTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.text.primary,
    marginBottom: 8,
  },
  emptyListText: {
    fontSize: 14,
    color: Colors.text.secondary,
    textAlign: "center",
  },
  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 32,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.text.primary,
    marginBottom: 24,
    textAlign: "center",
  },
  signInButton: {
    width: "100%",
    maxWidth: 250,
  },
});