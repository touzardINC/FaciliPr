import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  Image,
  ScrollView,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { Stack, useRouter } from "expo-router";
import { Camera, Upload, X, User as UserIcon } from "lucide-react-native";
import Colors from "@/constants/colors";
import Button from "@/components/Button";
import { useAuthStore } from "@/store/auth-store";

export default function EditProfileScreen() {
  const router = useRouter();
  const { user, updateUser } = useAuthStore();
  
  const [name, setName] = useState(user?.name || "");
  const [email, setEmail] = useState(user?.email || "");
  const [phone, setPhone] = useState(user?.phone || "");
  const [bio, setBio] = useState(user?.bio || "");
  const [avatar, setAvatar] = useState(user?.avatar || "https://images.unsplash.com/photo-1599566150163-29194dcaad36");
  const [isUploading, setIsUploading] = useState(false);

  const handleSave = () => {
    if (!name.trim()) {
      Alert.alert("Error", "Name is required");
      return;
    }

    if (!email.trim()) {
      Alert.alert("Error", "Email is required");
      return;
    }

    // Simple email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      Alert.alert("Error", "Please enter a valid email address");
      return;
    }

    // Update user profile
    if (user) {
      updateUser({
        ...user,
        name,
        email,
        phone,
        bio,
        avatar,
      });
    }

    Alert.alert("Success", "Profile updated successfully", [
      { text: "OK", onPress: () => router.back() }
    ]);
  };

  const handleUploadImage = () => {
    // In a real app, this would open the image picker
    setIsUploading(true);
    
    // Simulate upload delay
    setTimeout(() => {
      // Random avatar from Unsplash
      const avatars = [
        "https://images.unsplash.com/photo-1599566150163-29194dcaad36",
        "https://images.unsplash.com/photo-1494790108377-be9c29b29330",
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d",
        "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
        "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e",
      ];
      const randomAvatar = avatars[Math.floor(Math.random() * avatars.length)];
      setAvatar(randomAvatar);
      setIsUploading(false);
    }, 1000);
  };

  const handleTakePhoto = () => {
    // In a real app, this would open the camera
    Alert.alert(
      "Camera Access",
      "This would open the camera to take a new profile photo",
      [{ text: "OK" }]
    );
  };

  const handleRemovePhoto = () => {
    setAvatar("");
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={100}
    >
      <Stack.Screen options={{ title: "Edit Profile" }} />
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.avatarContainer}>
          {avatar ? (
            <Image source={{ uri: avatar }} style={styles.avatar} />
          ) : (
            <View style={[styles.avatar, styles.avatarPlaceholder]}>
              <UserIcon size={40} color={Colors.text.secondary} />
            </View>
          )}
          <View style={styles.avatarActions}>
            <TouchableOpacity
              style={styles.avatarButton}
              onPress={handleUploadImage}
              disabled={isUploading}
            >
              <Upload size={20} color={Colors.primary} />
              <Text style={styles.avatarButtonText}>
                {isUploading ? "Uploading..." : "Upload"}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.avatarButton}
              onPress={handleTakePhoto}
            >
              <Camera size={20} color={Colors.primary} />
              <Text style={styles.avatarButtonText}>Camera</Text>
            </TouchableOpacity>
            {avatar && (
              <TouchableOpacity
                style={[styles.avatarButton, styles.removeButton]}
                onPress={handleRemovePhoto}
              >
                <X size={20} color={Colors.error} />
                <Text style={[styles.avatarButtonText, styles.removeButtonText]}>
                  Remove
                </Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        <View style={styles.formContainer}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Full Name</Text>
            <TextInput
              style={styles.input}
              value={name}
              onChangeText={setName}
              placeholder="Enter your full name"
              placeholderTextColor={Colors.text.placeholder}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Email</Text>
            <TextInput
              style={styles.input}
              value={email}
              onChangeText={setEmail}
              placeholder="Enter your email"
              placeholderTextColor={Colors.text.placeholder}
              keyboardType="email-address"
              autoCapitalize="none"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Phone Number</Text>
            <TextInput
              style={styles.input}
              value={phone}
              onChangeText={setPhone}
              placeholder="Enter your phone number"
              placeholderTextColor={Colors.text.placeholder}
              keyboardType="phone-pad"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Bio</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              value={bio}
              onChangeText={setBio}
              placeholder="Tell us about yourself"
              placeholderTextColor={Colors.text.placeholder}
              multiline
              numberOfLines={4}
              textAlignVertical="top"
            />
          </View>
        </View>

        <View style={styles.buttonContainer}>
          <Button title="Save Changes" onPress={handleSave} />
          <TouchableOpacity
            style={styles.cancelButton}
            onPress={() => router.back()}
          >
            <Text style={styles.cancelButtonText}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  avatarContainer: {
    alignItems: "center",
    marginTop: 24,
    marginBottom: 16,
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  avatarPlaceholder: {
    backgroundColor: Colors.border,
    justifyContent: "center",
    alignItems: "center",
  },
  avatarActions: {
    flexDirection: "row",
    marginTop: 16,
  },
  avatarButton: {
    flexDirection: "row",
    alignItems: "center",
    padding: 8,
    marginHorizontal: 8,
  },
  avatarButtonText: {
    marginLeft: 4,
    fontSize: 14,
    color: Colors.primary,
    fontWeight: "500",
  },
  removeButton: {
    marginLeft: 8,
  },
  removeButtonText: {
    color: Colors.error,
  },
  formContainer: {
    paddingHorizontal: 16,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: "500",
    color: Colors.text.secondary,
    marginBottom: 8,
  },
  input: {
    backgroundColor: Colors.white,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: Colors.text.primary,
  },
  textArea: {
    minHeight: 100,
    paddingTop: 12,
  },
  buttonContainer: {
    paddingHorizontal: 16,
    marginTop: 16,
    marginBottom: 32,
  },
  cancelButton: {
    marginTop: 12,
    padding: 12,
    alignItems: "center",
  },
  cancelButtonText: {
    fontSize: 16,
    color: Colors.text.secondary,
    fontWeight: "500",
  },
});