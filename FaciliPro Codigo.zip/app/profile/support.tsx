import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Linking,
} from "react-native";
import { Stack } from "expo-router";
import {
  ChevronRight,
  MessageSquare,
  Phone,
  Mail,
  HelpCircle,
  FileText,
  ChevronDown,
} from "lucide-react-native";
import Colors from "@/constants/colors";
import Button from "@/components/Button";

export default function SupportScreen() {
  const [expanded, setExpanded] = useState<string | null>(null);
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");

  const toggleFAQ = (id: string) => {
    setExpanded(expanded === id ? null : id);
  };

  const handleSendMessage = () => {
    if (!subject.trim()) {
      Alert.alert("Error", "Please enter a subject");
      return;
    }

    if (!message.trim()) {
      Alert.alert("Error", "Please enter your message");
      return;
    }

    // In a real app, this would send the message to the support team
    Alert.alert(
      "Message Sent",
      "Thank you for contacting us. We'll get back to you as soon as possible.",
      [
        {
          text: "OK",
          onPress: () => {
            setSubject("");
            setMessage("");
          },
        },
      ]
    );
  };

  const handleCall = () => {
    Linking.openURL("tel:+18001234567");
  };

  const handleEmail = () => {
    Linking.openURL("mailto:support@example.com");
  };

  const handleChat = () => {
    Alert.alert(
      "Live Chat",
      "This would open a live chat with our support team",
      [{ text: "OK" }]
    );
  };

  const faqs = [
    {
      id: "1",
      question: "How do I book a service?",
      answer:
        "To book a service, browse through the available professionals, select one that matches your needs, choose a service, select a date and time, and confirm your booking. You can pay using various payment methods including credit/debit cards.",
    },
    {
      id: "2",
      question: "How do I cancel or reschedule a booking?",
      answer:
        "You can cancel or reschedule a booking by going to the Bookings tab, selecting the booking you want to modify, and tapping on the Cancel or Reschedule button. Please note that cancellations made less than 24 hours before the appointment may incur a cancellation fee.",
    },
    {
      id: "3",
      question: "What payment methods are accepted?",
      answer:
        "We accept various payment methods including credit/debit cards, PayPal, and Apple Pay. All payments are processed securely through our platform.",
    },
    {
      id: "4",
      question: "How do I leave a review?",
      answer:
        "After your service is completed, you'll receive a notification to leave a review. You can also go to your Bookings tab, find the completed booking, and tap on 'Leave a Review'. You can rate the service and leave comments and photos.",
    },
    {
      id: "5",
      question: "What if I'm not satisfied with the service?",
      answer:
        "If you're not satisfied with the service, please contact our support team immediately. We have a satisfaction guarantee and will work with you to resolve any issues.",
    },
  ];

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={100}
    >
      <Stack.Screen options={{ title: "Help & Support" }} />
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.contactSection}>
          <Text style={styles.sectionTitle}>Contact Us</Text>
          <Text style={styles.sectionDescription}>
            We're here to help. Reach out to us through any of these channels.
          </Text>

          <View style={styles.contactOptions}>
            <TouchableOpacity
              style={styles.contactOption}
              onPress={handleChat}
            >
              <View style={[styles.contactIcon, styles.chatIcon]}>
                <MessageSquare size={24} color={Colors.white} />
              </View>
              <Text style={styles.contactLabel}>Live Chat</Text>
              <Text style={styles.contactDetail}>Available 24/7</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.contactOption}
              onPress={handleCall}
            >
              <View style={[styles.contactIcon, styles.phoneIcon]}>
                <Phone size={24} color={Colors.white} />
              </View>
              <Text style={styles.contactLabel}>Call Us</Text>
              <Text style={styles.contactDetail}>1-800-123-4567</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.contactOption}
              onPress={handleEmail}
            >
              <View style={[styles.contactIcon, styles.emailIcon]}>
                <Mail size={24} color={Colors.white} />
              </View>
              <Text style={styles.contactLabel}>Email</Text>
              <Text style={styles.contactDetail}>support@example.com</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.faqSection}>
          <Text style={styles.sectionTitle}>Frequently Asked Questions</Text>

          <View style={styles.faqList}>
            {faqs.map((faq) => (
              <TouchableOpacity
                key={faq.id}
                style={styles.faqItem}
                onPress={() => toggleFAQ(faq.id)}
                activeOpacity={0.7}
              >
                <View style={styles.faqHeader}>
                  <Text style={styles.faqQuestion}>{faq.question}</Text>
                  {expanded === faq.id ? (
                    <ChevronDown size={20} color={Colors.text.secondary} />
                  ) : (
                    <ChevronRight size={20} color={Colors.text.secondary} />
                  )}
                </View>
                {expanded === faq.id && (
                  <Text style={styles.faqAnswer}>{faq.answer}</Text>
                )}
              </TouchableOpacity>
            ))}
          </View>

          <TouchableOpacity
            style={styles.viewAllButton}
            onPress={() => {
              // In a real app, this would navigate to a full FAQ page
              Alert.alert(
                "View All FAQs",
                "This would navigate to a full FAQ page",
                [{ text: "OK" }]
              );
            }}
          >
            <Text style={styles.viewAllButtonText}>View All FAQs</Text>
            <ChevronRight size={16} color={Colors.primary} />
          </TouchableOpacity>
        </View>

        <View style={styles.helpLinks}>
          <TouchableOpacity
            style={styles.helpLink}
            onPress={() => {
              // In a real app, this would navigate to the help center
              Alert.alert(
                "Help Center",
                "This would navigate to the help center",
                [{ text: "OK" }]
              );
            }}
          >
            <HelpCircle size={20} color={Colors.primary} />
            <Text style={styles.helpLinkText}>Help Center</Text>
            <ChevronRight size={16} color={Colors.text.secondary} />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.helpLink}
            onPress={() => {
              // In a real app, this would navigate to the terms of service
              Alert.alert(
                "Terms of Service",
                "This would navigate to the terms of service",
                [{ text: "OK" }]
              );
            }}
          >
            <FileText size={20} color={Colors.primary} />
            <Text style={styles.helpLinkText}>Terms of Service</Text>
            <ChevronRight size={16} color={Colors.text.secondary} />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.helpLink}
            onPress={() => {
              // In a real app, this would navigate to the privacy policy
              Alert.alert(
                "Privacy Policy",
                "This would navigate to the privacy policy",
                [{ text: "OK" }]
              );
            }}
          >
            <FileText size={20} color={Colors.primary} />
            <Text style={styles.helpLinkText}>Privacy Policy</Text>
            <ChevronRight size={16} color={Colors.text.secondary} />
          </TouchableOpacity>
        </View>

        <View style={styles.messageSection}>
          <Text style={styles.sectionTitle}>Send Us a Message</Text>
          <Text style={styles.sectionDescription}>
            Have a specific question or issue? Send us a message and we'll get
            back to you as soon as possible.
          </Text>

          <View style={styles.messageForm}>
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Subject</Text>
              <TextInput
                style={styles.input}
                value={subject}
                onChangeText={setSubject}
                placeholder="What's your question about?"
                placeholderTextColor={Colors.text.placeholder}
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Message</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                value={message}
                onChangeText={setMessage}
                placeholder="Please describe your issue or question in detail"
                placeholderTextColor={Colors.text.placeholder}
                multiline
                numberOfLines={6}
                textAlignVertical="top"
              />
            </View>

            <Button
              title="Send Message"
              onPress={handleSendMessage}
              style={styles.sendButton}
            />
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  contactSection: {
    padding: 16,
    backgroundColor: Colors.white,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.text.primary,
    marginBottom: 8,
  },
  sectionDescription: {
    fontSize: 14,
    color: Colors.text.secondary,
    marginBottom: 16,
    lineHeight: 20,
  },
  contactOptions: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  contactOption: {
    alignItems: "center",
    flex: 1,
    padding: 12,
  },
  contactIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8,
  },
  chatIcon: {
    backgroundColor: "#4CAF50",
  },
  phoneIcon: {
    backgroundColor: "#2196F3",
  },
  emailIcon: {
    backgroundColor: "#FF9800",
  },
  contactLabel: {
    fontSize: 14,
    fontWeight: "600",
    color: Colors.text.primary,
    marginBottom: 4,
  },
  contactDetail: {
    fontSize: 12,
    color: Colors.text.secondary,
    textAlign: "center",
  },
  faqSection: {
    padding: 16,
    backgroundColor: Colors.white,
    marginBottom: 16,
  },
  faqList: {
    marginTop: 8,
  },
  faqItem: {
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    paddingVertical: 12,
  },
  faqHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  faqQuestion: {
    fontSize: 16,
    fontWeight: "500",
    color: Colors.text.primary,
    flex: 1,
    paddingRight: 16,
  },
  faqAnswer: {
    fontSize: 14,
    color: Colors.text.secondary,
    marginTop: 8,
    lineHeight: 20,
  },
  viewAllButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 16,
  },
  viewAllButtonText: {
    fontSize: 14,
    fontWeight: "600",
    color: Colors.primary,
    marginRight: 4,
  },
  helpLinks: {
    backgroundColor: Colors.white,
    marginBottom: 16,
  },
  helpLink: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  helpLinkText: {
    fontSize: 16,
    color: Colors.text.primary,
    flex: 1,
    marginLeft: 12,
  },
  messageSection: {
    padding: 16,
    backgroundColor: Colors.white,
    marginBottom: 32,
  },
  messageForm: {
    marginTop: 8,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: "500",
    color: Colors.text.secondary,
    marginBottom: 8,
  },
  input: {
    backgroundColor: Colors.background,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: Colors.text.primary,
  },
  textArea: {
    minHeight: 120,
    textAlignVertical: "top",
  },
  sendButton: {
    marginTop: 8,
  },
});