import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from "react-native";
import { useRouter, Stack } from "expo-router";
import { CreditCard } from "lucide-react-native";
import Colors from "@/constants/colors";
import { usePaymentStore } from "@/store/payment-store";
import Button from "@/components/Button";
import { PaymentMethodType } from "@/types/payment";

export default function AddPaymentMethodScreen() {
  const router = useRouter();
  const { addPaymentMethod, isLoading } = usePaymentStore();
  
  const [paymentType, setPaymentType] = useState<PaymentMethodType>("credit_card");
  const [cardNumber, setCardNumber] = useState("");
  const [cardholderName, setCardholderName] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [cvv, setCvv] = useState("");
  const [isDefault, setIsDefault] = useState(false);
  const [errors, setErrors] = useState({
    cardNumber: "",
    cardholderName: "",
    expiryDate: "",
    cvv: "",
  });

  const formatCardNumber = (value: string) => {
    // Remove all non-digit characters
    const digits = value.replace(/\D/g, "");
    
    // Format with spaces every 4 digits
    let formatted = "";
    for (let i = 0; i < digits.length; i += 4) {
      formatted += digits.slice(i, i + 4) + " ";
    }
    
    // Trim the trailing space and limit to 19 characters (16 digits + 3 spaces)
    return formatted.trim().slice(0, 19);
  };

  const formatExpiryDate = (value: string) => {
    // Remove all non-digit characters
    const digits = value.replace(/\D/g, "");
    
    // Format as MM/YY
    if (digits.length > 2) {
      return digits.slice(0, 2) + "/" + digits.slice(2, 4);
    } else {
      return digits;
    }
  };

  const handleCardNumberChange = (text: string) => {
    setCardNumber(formatCardNumber(text));
  };

  const handleExpiryDateChange = (text: string) => {
    setExpiryDate(formatExpiryDate(text));
  };

  const validateForm = () => {
    let isValid = true;
    const newErrors = {
      cardNumber: "",
      cardholderName: "",
      expiryDate: "",
      cvv: "",
    };

    // Validate card number (should be 16 digits)
    const cardDigits = cardNumber.replace(/\D/g, "");
    if (!cardDigits) {
      newErrors.cardNumber = "Card number is required";
      isValid = false;
    } else if (cardDigits.length !== 16) {
      newErrors.cardNumber = "Card number must be 16 digits";
      isValid = false;
    }

    // Validate cardholder name
    if (!cardholderName.trim()) {
      newErrors.cardholderName = "Cardholder name is required";
      isValid = false;
    }

    // Validate expiry date (should be in MM/YY format)
    if (!expiryDate) {
      newErrors.expiryDate = "Expiry date is required";
      isValid = false;
    } else {
      const [month, year] = expiryDate.split("/");
      const currentYear = new Date().getFullYear() % 100; // Get last 2 digits of year
      const currentMonth = new Date().getMonth() + 1; // Months are 0-indexed
      
      if (!month || !year || month.length !== 2 || year.length !== 2) {
        newErrors.expiryDate = "Expiry date must be in MM/YY format";
        isValid = false;
      } else if (parseInt(month) < 1 || parseInt(month) > 12) {
        newErrors.expiryDate = "Month must be between 01 and 12";
        isValid = false;
      } else if (
        parseInt(year) < currentYear ||
        (parseInt(year) === currentYear && parseInt(month) < currentMonth)
      ) {
        newErrors.expiryDate = "Card has expired";
        isValid = false;
      }
    }

    // Validate CVV (should be 3 or 4 digits)
    if (!cvv) {
      newErrors.cvv = "CVV is required";
      isValid = false;
    } else if (!/^\d{3,4}$/.test(cvv)) {
      newErrors.cvv = "CVV must be 3 or 4 digits";
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleAddPaymentMethod = async () => {
    if (!validateForm()) return;

    try {
      // Get the last 4 digits of the card number
      const last4 = cardNumber.replace(/\D/g, "").slice(-4);
      
      // Determine card brand based on first digit
      // This is a simplified version - in a real app, you'd use a more comprehensive check
      const firstDigit = cardNumber.replace(/\D/g, "")[0];
      let brand = "unknown";
      if (firstDigit === "4") brand = "visa";
      else if (firstDigit === "5") brand = "mastercard";
      else if (firstDigit === "3") brand = "amex";
      else if (firstDigit === "6") brand = "discover";
      
      await addPaymentMethod({
        type: paymentType,
        name: `${brand.charAt(0).toUpperCase() + brand.slice(1)} ending in ${last4}`,
        last4,
        expiryDate,
        isDefault,
        brand,
        icon: "credit-card",
      });
      
      Alert.alert(
        "Success",
        "Payment method added successfully",
        [
          {
            text: "OK",
            onPress: () => router.back(),
          },
        ]
      );
    } catch (error) {
      Alert.alert("Error", "Failed to add payment method");
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen
        options={{
          title: "Add Payment Method",
          headerTitleStyle: {
            fontWeight: "600",
          },
        }}
      />
      
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.keyboardAvoidingView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.header}>
            <Text style={styles.title}>Add a Payment Method</Text>
            <Text style={styles.subtitle}>
              Add a new card for faster checkout
            </Text>
          </View>

          <View style={styles.form}>
            <View style={styles.paymentTypeContainer}>
              <TouchableOpacity
                style={[
                  styles.paymentTypeButton,
                  paymentType === "credit_card" && styles.activePaymentType,
                ]}
                onPress={() => setPaymentType("credit_card")}
              >
                <CreditCard
                  size={24}
                  color={
                    paymentType === "credit_card"
                      ? Colors.white
                      : Colors.text.secondary
                  }
                />
                <Text
                  style={[
                    styles.paymentTypeText,
                    paymentType === "credit_card" && styles.activePaymentTypeText,
                  ]}
                >
                  Credit Card
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[
                  styles.paymentTypeButton,
                  paymentType === "debit_card" && styles.activePaymentType,
                ]}
                onPress={() => setPaymentType("debit_card")}
              >
                <CreditCard
                  size={24}
                  color={
                    paymentType === "debit_card"
                      ? Colors.white
                      : Colors.text.secondary
                  }
                />
                <Text
                  style={[
                    styles.paymentTypeText,
                    paymentType === "debit_card" && styles.activePaymentTypeText,
                  ]}
                >
                  Debit Card
                </Text>
              </TouchableOpacity>
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Card Number</Text>
              <TextInput
                style={[styles.input, errors.cardNumber && styles.inputError]}
                value={cardNumber}
                onChangeText={handleCardNumberChange}
                placeholder="1234 5678 9012 3456"
                keyboardType="numeric"
                maxLength={19} // 16 digits + 3 spaces
              />
              {errors.cardNumber ? (
                <Text style={styles.errorText}>{errors.cardNumber}</Text>
              ) : null}
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Cardholder Name</Text>
              <TextInput
                style={[styles.input, errors.cardholderName && styles.inputError]}
                value={cardholderName}
                onChangeText={setCardholderName}
                placeholder="John Doe"
                autoCapitalize="words"
              />
              {errors.cardholderName ? (
                <Text style={styles.errorText}>{errors.cardholderName}</Text>
              ) : null}
            </View>

            <View style={styles.rowContainer}>
              <View style={[styles.inputContainer, styles.halfInput]}>
                <Text style={styles.label}>Expiry Date</Text>
                <TextInput
                  style={[styles.input, errors.expiryDate && styles.inputError]}
                  value={expiryDate}
                  onChangeText={handleExpiryDateChange}
                  placeholder="MM/YY"
                  keyboardType="numeric"
                  maxLength={5} // MM/YY format
                />
                {errors.expiryDate ? (
                  <Text style={styles.errorText}>{errors.expiryDate}</Text>
                ) : null}
              </View>

              <View style={[styles.inputContainer, styles.halfInput]}>
                <Text style={styles.label}>CVV</Text>
                <TextInput
                  style={[styles.input, errors.cvv && styles.inputError]}
                  value={cvv}
                  onChangeText={setCvv}
                  placeholder="123"
                  keyboardType="numeric"
                  maxLength={4}
                  secureTextEntry
                />
                {errors.cvv ? (
                  <Text style={styles.errorText}>{errors.cvv}</Text>
                ) : null}
              </View>
            </View>

            <View style={styles.checkboxContainer}>
              <TouchableOpacity
                style={styles.checkbox}
                onPress={() => setIsDefault(!isDefault)}
              >
                <View
                  style={[
                    styles.checkboxInner,
                    isDefault && styles.checkboxChecked,
                  ]}
                />
              </TouchableOpacity>
              <Text style={styles.checkboxLabel}>
                Set as default payment method
              </Text>
            </View>

            <Button
              title="Add Payment Method"
              onPress={handleAddPaymentMethod}
              loading={isLoading}
              style={styles.addButton}
            />
          </View>

          <View style={styles.securityNote}>
            <Text style={styles.securityNoteText}>
              Your payment information is securely stored and processed.
            </Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  keyboardAvoidingView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  header: {
    marginBottom: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: "700",
    color: Colors.text.primary,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: Colors.text.secondary,
  },
  form: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 16,
    marginBottom: 24,
  },
  paymentTypeContainer: {
    flexDirection: "row",
    marginBottom: 16,
  },
  paymentTypeButton: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.background,
    borderRadius: 8,
    padding: 12,
    marginRight: 8,
  },
  activePaymentType: {
    backgroundColor: Colors.primary,
  },
  paymentTypeText: {
    fontSize: 14,
    fontWeight: "500",
    color: Colors.text.secondary,
    marginLeft: 8,
  },
  activePaymentTypeText: {
    color: Colors.white,
  },
  inputContainer: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: "600",
    color: Colors.text.primary,
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 16,
  },
  inputError: {
    borderColor: Colors.error,
  },
  errorText: {
    color: Colors.error,
    fontSize: 12,
    marginTop: 4,
  },
  rowContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  halfInput: {
    width: "48%",
  },
  checkboxContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 24,
  },
  checkbox: {
    width: 20,
    height: 20,
    borderRadius: 4,
    borderWidth: 2,
    borderColor: Colors.primary,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 8,
  },
  checkboxInner: {
    width: 12,
    height: 12,
    borderRadius: 2,
  },
  checkboxChecked: {
    backgroundColor: Colors.primary,
  },
  checkboxLabel: {
    fontSize: 14,
    color: Colors.text.primary,
  },
  addButton: {
    marginTop: 8,
  },
  securityNote: {
    alignItems: "center",
    marginBottom: 24,
  },
  securityNoteText: {
    fontSize: 14,
    color: Colors.text.secondary,
    textAlign: "center",
  },
});