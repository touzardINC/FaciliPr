import React, { useState, useEffect } from "react";
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Alert,
  SafeAreaView,
} from "react-native";
import { useRouter, Stack } from "expo-router";
import { MapPin, Plus, Home, Briefcase, CheckCircle, Trash2 } from "lucide-react-native";
import Colors from "@/constants/colors";
import { useLocationStore } from "@/store/location-store";
import Button from "@/components/Button";
import LocationPicker from "@/components/LocationPicker";

export default function AddressesScreen() {
  const router = useRouter();
  const { savedLocations, addSavedLocation, removeSavedLocation, setDefaultLocation } = useLocationStore();
  const [showAddForm, setShowAddForm] = useState(false);
  const [newLocationName, setNewLocationName] = useState("");
  const [newLocationAddress, setNewLocationAddress] = useState("");
  const [newLocationCoords, setNewLocationCoords] = useState<{
    latitude: number;
    longitude: number;
  } | null>(null);

  const handleAddLocation = () => {
    if (!newLocationName.trim()) {
      Alert.alert("Error", "Please enter a name for this location");
      return;
    }

    if (!newLocationAddress || !newLocationCoords) {
      Alert.alert("Error", "Please select a location");
      return;
    }

    addSavedLocation({
      name: newLocationName,
      address: newLocationAddress,
      latitude: newLocationCoords.latitude,
      longitude: newLocationCoords.longitude,
      isDefault: savedLocations.length === 0, // Make default if it's the first one
    });

    // Reset form
    setNewLocationName("");
    setNewLocationAddress("");
    setNewLocationCoords(null);
    setShowAddForm(false);

    Alert.alert("Success", "Location added successfully");
  };

  const handleDeleteLocation = (id: string) => {
    Alert.alert(
      "Delete Location",
      "Are you sure you want to delete this location?",
      [
        {
          text: "Cancel",
          style: "cancel",
        },
        {
          text: "Delete",
          onPress: () => {
            removeSavedLocation(id);
          },
          style: "destructive",
        },
      ]
    );
  };

  const handleSetDefaultLocation = (id: string) => {
    setDefaultLocation(id);
  };

  const getLocationIcon = (name: string) => {
    const lowerName = name.toLowerCase();
    if (lowerName.includes("home")) {
      return <Home size={20} color={Colors.primary} />;
    } else if (lowerName.includes("work") || lowerName.includes("office")) {
      return <Briefcase size={20} color={Colors.primary} />;
    } else {
      return <MapPin size={20} color={Colors.primary} />;
    }
  };

  const handleLocationSelect = (location: {
    latitude: number;
    longitude: number;
    address: string;
  }) => {
    setNewLocationAddress(location.address);
    setNewLocationCoords({
      latitude: location.latitude,
      longitude: location.longitude,
    });
  };

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen options={{ title: "My Addresses" }} />
      
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={styles.title}>Saved Locations</Text>
          <Text style={styles.subtitle}>
            Manage your saved addresses for service bookings
          </Text>
        </View>

        <TouchableOpacity
          style={styles.addButton}
          onPress={() => setShowAddForm(!showAddForm)}
        >
          <Plus size={24} color={Colors.primary} />
          <Text style={styles.addButtonText}>Add New Address</Text>
        </TouchableOpacity>

        {showAddForm && (
          <View style={styles.addFormContainer}>
            <TextInput
              style={styles.input}
              placeholder="Location Name (e.g., Home, Work)"
              value={newLocationName}
              onChangeText={setNewLocationName}
            />

            <LocationPicker onLocationSelect={handleLocationSelect} />

            <Button
              title="Save Location"
              onPress={handleAddLocation}
              style={styles.saveButton}
            />
          </View>
        )}

        {savedLocations.length === 0 ? (
          <View style={styles.emptyContainer}>
            <MapPin size={48} color={Colors.text.light} />
            <Text style={styles.emptyText}>No saved locations yet</Text>
            <Text style={styles.emptySubtext}>
              Add locations to make booking services easier
            </Text>
          </View>
        ) : (
          <View style={styles.locationsContainer}>
            {savedLocations.map((location) => (
              <View key={location.id} style={styles.locationCard}>
                <View style={styles.locationHeader}>
                  <View style={styles.locationNameContainer}>
                    {getLocationIcon(location.name)}
                    <Text style={styles.locationName}>{location.name}</Text>
                    {location.isDefault && (
                      <View style={styles.defaultBadge}>
                        <Text style={styles.defaultText}>Default</Text>
                      </View>
                    )}
                  </View>
                  <View style={styles.actionButtons}>
                    {!location.isDefault && (
                      <TouchableOpacity
                        onPress={() => handleSetDefaultLocation(location.id)}
                        style={styles.actionButton}
                      >
                        <CheckCircle size={20} color={Colors.primary} />
                      </TouchableOpacity>
                    )}
                    <TouchableOpacity
                      onPress={() => handleDeleteLocation(location.id)}
                      style={styles.actionButton}
                    >
                      <Trash2 size={20} color={Colors.error} />
                    </TouchableOpacity>
                  </View>
                </View>
                <Text style={styles.locationAddress}>{location.address}</Text>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

// This component is needed for the form
import { TextInput } from "react-native";

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 32,
  },
  header: {
    marginBottom: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: "700",
    color: Colors.text.primary,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: Colors.text.secondary,
  },
  addButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderStyle: "dashed",
    borderColor: Colors.primary,
  },
  addButtonText: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.primary,
    marginLeft: 12,
  },
  addFormContainer: {
    backgroundColor: Colors.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
  },
  input: {
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    fontSize: 16,
  },
  saveButton: {
    marginTop: 8,
  },
  emptyContainer: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.white,
    borderRadius: 12,
    padding: 32,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: "600",
    color: Colors.text.primary,
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 14,
    color: Colors.text.secondary,
    textAlign: "center",
  },
  locationsContainer: {
    marginBottom: 16,
  },
  locationCard: {
    backgroundColor: Colors.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  locationHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  locationNameContainer: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  locationName: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.text.primary,
    marginLeft: 8,
    marginRight: 8,
  },
  defaultBadge: {
    backgroundColor: Colors.primary,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
  },
  defaultText: {
    color: Colors.white,
    fontSize: 12,
    fontWeight: "500",
  },
  locationAddress: {
    fontSize: 14,
    color: Colors.text.secondary,
    marginLeft: 28, // Align with the text after the icon
  },
  actionButtons: {
    flexDirection: "row",
  },
  actionButton: {
    padding: 8,
    marginLeft: 4,
  },
});