import React, { useState, useEffect, useRef } from "react";
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  Image,
  TouchableOpacity,
  SafeAreaView,
  Animated,
  Alert,
  Platform,
} from "react-native";
import { useLocalSearchParams, useRouter, Stack } from "expo-router";
import {
  Star,
  MapPin,
  Phone,
  MessageCircle,
  Calendar,
  ChevronDown,
  ChevronUp,
  Clock,
  DollarSign,
  Info,
  Share2,
} from "lucide-react-native";
import Colors from "@/constants/colors";
import { professionals } from "@/mocks/professionals";
import { Professional, Service, ReviewMedia } from "@/types/professional";
import Button from "@/components/Button";
import ReviewItem from "@/components/ReviewItem";
import ServiceDetailModal from "@/components/ServiceDetailModal";
import AddReviewForm from "@/components/AddReviewForm";
import { useAuthStore } from "@/store/auth-store";
import { useBookingStore } from "@/store/booking-store";
import MediaThumbnails from "@/components/MediaThumbnails";
import SocialMediaLinks from "@/components/SocialMediaLinks";

export default function ProfessionalDetailScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams();
  const { user, isAuthenticated } = useAuthStore();
  const { addReview, isLoading: isReviewLoading } = useBookingStore();
  
  const [professional, setProfessional] = useState<Professional | null>(null);
  const [showAllReviews, setShowAllReviews] = useState(false);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [showServiceModal, setShowServiceModal] = useState(false);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [activeTab, setActiveTab] = useState<"services" | "reviews">("services");
  
  const servicesOpacity = useRef(new Animated.Value(1)).current;
  const reviewsOpacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (id) {
      const foundProfessional = professionals.find((p) => p.id === id);
      if (foundProfessional) {
        setProfessional(foundProfessional);
      }
    }
  }, [id]);

  useEffect(() => {
    // Animate tab transitions
    Animated.parallel([
      Animated.timing(servicesOpacity, {
        toValue: activeTab === "services" ? 1 : 0,
        duration: 300,
        useNativeDriver: true,
      }),
      Animated.timing(reviewsOpacity, {
        toValue: activeTab === "reviews" ? 1 : 0,
        duration: 300,
        useNativeDriver: true,
      }),
    ]).start();
  }, [activeTab]);

  const handleBookNow = () => {
    if (professional) {
      router.push({
        pathname: "/booking/new",
        params: { professionalId: professional.id },
      });
    }
  };

  const handleServicePress = (service: Service) => {
    setSelectedService(service);
    setShowServiceModal(true);
  };

  const handleBookService = (service: Service) => {
    if (professional) {
      router.push({
        pathname: "/booking/new",
        params: { 
          professionalId: professional.id,
          serviceId: service.id 
        },
      });
    }
  };

  const handleAddReview = () => {
    if (!isAuthenticated) {
      Alert.alert(
        "Sign In Required",
        "Please sign in to leave a review",
        [
          {
            text: "Cancel",
            style: "cancel",
          },
          {
            text: "Sign In",
            onPress: () => router.push("/login"),
          },
        ]
      );
      return;
    }
    
    setShowReviewForm(true);
  };

  const handleSubmitReview = async (rating: number, comment: string, media: ReviewMedia[]) => {
    try {
      // In a real app, you would upload the media to a server and get URLs back
      // For this demo, we'll just simulate the review submission
      
      // Create a mock booking ID for the review
      const mockBookingId = `booking-${Date.now()}`;
      
      await addReview(mockBookingId, rating, comment);
      
      // Update the professional's reviews locally
      if (professional) {
        const newReview = {
          id: `review-${Date.now()}`,
          userId: user?.id || "user1",
          rating,
          comment,
          date: new Date().toISOString(),
          images: media.length > 0 ? media : undefined,
        };
        
        setProfessional({
          ...professional,
          reviews: [newReview, ...professional.reviews],
          reviewCount: professional.reviewCount + 1,
          rating: ((professional.rating * professional.reviewCount) + rating) / (professional.reviewCount + 1),
        });
      }
      
      setShowReviewForm(false);
      Alert.alert("Success", "Thank you for your review!");
    } catch (error) {
      Alert.alert("Error", "Failed to submit review. Please try again.");
    }
  };

  const handleShare = () => {
    if (professional) {
      const message = `Check out ${professional.name}, a professional ${professional.services[0]?.name || "service provider"} on our platform!`;
      
      if (Platform.OS === "web") {
        // Web sharing
        if (navigator.share) {
          navigator.share({
            title: professional.name,
            text: message,
            url: window.location.href,
          }).catch((error) => console.log("Error sharing", error));
        } else {
          // Fallback for browsers that don't support the Web Share API
          Alert.alert("Share", "Copy this link to share: " + window.location.href);
        }
      } else {
        // Native sharing
        Alert.alert("Share", "Sharing functionality would be implemented here in a real app.");
      }
    }
  };

  if (!professional) {
    return (
      <SafeAreaView style={styles.container}>
        <Text>Professional not found</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen
        options={{
          title: professional.name,
          headerTitleStyle: {
            fontWeight: "600",
          },
          headerRight: () => (
            <TouchableOpacity style={styles.shareButton} onPress={handleShare}>
              <Share2 size={20} color={Colors.primary} />
            </TouchableOpacity>
          ),
        }}
      />
      
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Image source={{ uri: professional.avatar }} style={styles.avatar} />
          
          <View style={styles.headerContent}>
            <Text style={styles.name}>{professional.name}</Text>
            
            <View style={styles.ratingContainer}>
              <Star size={16} color={Colors.accent} fill={Colors.accent} />
              <Text style={styles.rating}>
                {professional.rating.toFixed(1)} ({professional.reviewCount} reviews)
              </Text>
            </View>
            
            <View style={styles.locationContainer}>
              <MapPin size={14} color={Colors.text.secondary} />
              <Text style={styles.location}>
                {professional.location} • {professional.distance} km away
              </Text>
            </View>

            {professional.socialMedia && professional.socialMedia.length > 0 && (
              <View style={styles.socialMediaContainer}>
                <SocialMediaLinks socialMedia={professional.socialMedia} size="small" />
              </View>
            )}
          </View>
        </View>

        <View style={styles.actionButtons}>
          <TouchableOpacity style={styles.actionButton}>
            <Phone size={20} color={Colors.primary} />
            <Text style={styles.actionButtonText}>Call</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.actionButton}>
            <MessageCircle size={20} color={Colors.primary} />
            <Text style={styles.actionButtonText}>Message</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>About</Text>
          <Text style={styles.description}>{professional.description}</Text>
          
          {professional.socialMedia && professional.socialMedia.length > 0 && (
            <View style={styles.socialMediaSection}>
              <Text style={styles.socialMediaTitle}>Connect with {professional.name.split(' ')[0]}</Text>
              <SocialMediaLinks 
                socialMedia={professional.socialMedia} 
                size="medium" 
                showLabels={true} 
              />
            </View>
          )}
        </View>

        {/* Tab Navigation */}
        <View style={styles.tabContainer}>
          <TouchableOpacity
            style={[
              styles.tab,
              activeTab === "services" && styles.activeTab,
            ]}
            onPress={() => setActiveTab("services")}
          >
            <Text
              style={[
                styles.tabText,
                activeTab === "services" && styles.activeTabText,
              ]}
            >
              Services
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.tab,
              activeTab === "reviews" && styles.activeTab,
            ]}
            onPress={() => setActiveTab("reviews")}
          >
            <Text
              style={[
                styles.tabText,
                activeTab === "reviews" && styles.activeTabText,
              ]}
            >
              Reviews ({professional.reviewCount})
            </Text>
          </TouchableOpacity>
        </View>

        {/* Services Tab Content */}
        <Animated.View
          style={[
            styles.tabContent,
            { opacity: servicesOpacity, display: activeTab === "services" ? "flex" : "none" },
          ]}
        >
          {professional.services.map((service) => {
            // Convert legacy imageUrl to media format if needed
            const serviceMedia = service.media || 
              (service.imageUrl ? [{ id: "legacy", type: "image" as const, url: service.imageUrl }] : []);
            
            return (
              <TouchableOpacity
                key={service.id}
                style={styles.serviceCard}
                onPress={() => handleServicePress(service)}
                activeOpacity={0.7}
              >
                <View style={styles.serviceCardContent}>
                  {serviceMedia.length > 0 ? (
                    <View style={styles.serviceMediaContainer}>
                      <Image
                        source={{ uri: serviceMedia[0].thumbnailUrl || serviceMedia[0].url }}
                        style={styles.serviceImage}
                        resizeMode="cover"
                      />
                      {serviceMedia.length > 1 && (
                        <View style={styles.mediaCountBadge}>
                          <Text style={styles.mediaCountText}>+{serviceMedia.length - 1}</Text>
                        </View>
                      )}
                    </View>
                  ) : (
                    <View style={styles.noMediaContainer}>
                      <Text style={styles.noMediaText}>No image</Text>
                    </View>
                  )}
                  
                  <View style={styles.serviceInfo}>
                    <Text style={styles.serviceName}>{service.name}</Text>
                    
                    <View style={styles.serviceMetaContainer}>
                      <View style={styles.serviceMeta}>
                        <DollarSign size={14} color={Colors.primary} />
                        <Text style={styles.serviceMetaText}>${service.price}</Text>
                      </View>
                      
                      {service.duration && (
                        <View style={styles.serviceMeta}>
                          <Clock size={14} color={Colors.primary} />
                          <Text style={styles.serviceMetaText}>{service.duration}</Text>
                        </View>
                      )}
                    </View>
                    
                    {service.description && (
                      <Text style={styles.serviceDescription} numberOfLines={2}>
                        {service.description}
                      </Text>
                    )}
                  </View>
                </View>
                
                <View style={styles.serviceCardFooter}>
                  <TouchableOpacity
                    style={styles.viewDetailsButton}
                    onPress={() => handleServicePress(service)}
                  >
                    <Info size={16} color={Colors.primary} />
                    <Text style={styles.viewDetailsText}>View Details</Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity
                    style={styles.bookServiceButton}
                    onPress={() => handleBookService(service)}
                  >
                    <Text style={styles.bookServiceText}>Book</Text>
                  </TouchableOpacity>
                </View>
              </TouchableOpacity>
            );
          })}
        </Animated.View>

        {/* Reviews Tab Content */}
        <Animated.View
          style={[
            styles.tabContent,
            { opacity: reviewsOpacity, display: activeTab === "reviews" ? "flex" : "none" },
          ]}
        >
          <View style={styles.reviewsHeader}>
            <Text style={styles.reviewsTitle}>Customer Reviews</Text>
            <TouchableOpacity
              style={styles.addReviewButton}
              onPress={handleAddReview}
            >
              <Text style={styles.addReviewText}>Write a Review</Text>
            </TouchableOpacity>
          </View>
          
          {showReviewForm && (
            <AddReviewForm
              onSubmit={handleSubmitReview}
              onCancel={() => setShowReviewForm(false)}
              isLoading={isReviewLoading}
            />
          )}
          
          {(showAllReviews
            ? professional.reviews
            : professional.reviews.slice(0, 3)
          ).map((review) => (
            <ReviewItem key={review.id} review={review} />
          ))}
          
          {!showAllReviews && professional.reviews.length > 3 && (
            <TouchableOpacity
              style={styles.showMoreButton}
              onPress={() => setShowAllReviews(true)}
            >
              <Text style={styles.showMoreText}>Show More Reviews</Text>
              <ChevronDown size={16} color={Colors.primary} />
            </TouchableOpacity>
          )}
          
          {showAllReviews && professional.reviews.length > 3 && (
            <TouchableOpacity
              style={styles.showMoreButton}
              onPress={() => setShowAllReviews(false)}
            >
              <Text style={styles.showMoreText}>Show Less</Text>
              <ChevronUp size={16} color={Colors.primary} />
            </TouchableOpacity>
          )}
        </Animated.View>
      </ScrollView>

      <View style={styles.footer}>
        <View style={styles.priceContainer}>
          <Text style={styles.priceLabel}>Hourly Rate</Text>
          <Text style={styles.price}>${professional.hourlyRate}/hr</Text>
        </View>
        
        <Button
          title="Book Now"
          onPress={handleBookNow}
          icon={<Calendar size={18} color={Colors.white} style={{ marginRight: 8 }} />}
          disabled={!professional.available}
          style={styles.bookButton}
        />
      </View>

      {/* Service Detail Modal */}
      <ServiceDetailModal
        visible={showServiceModal}
        service={selectedService}
        onClose={() => setShowServiceModal(false)}
        onBook={handleBookService}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: "row",
    padding: 16,
    backgroundColor: Colors.white,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: 16,
  },
  headerContent: {
    flex: 1,
    justifyContent: "center",
  },
  name: {
    fontSize: 20,
    fontWeight: "700",
    color: Colors.text.primary,
    marginBottom: 4,
  },
  ratingContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 4,
  },
  rating: {
    fontSize: 14,
    color: Colors.text.secondary,
    marginLeft: 4,
  },
  locationContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  location: {
    fontSize: 12,
    color: Colors.text.secondary,
    marginLeft: 4,
  },
  socialMediaContainer: {
    marginTop: 4,
  },
  actionButtons: {
    flexDirection: "row",
    backgroundColor: Colors.white,
    paddingHorizontal: 16,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  actionButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.background,
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
    marginRight: 12,
  },
  actionButtonText: {
    fontSize: 14,
    fontWeight: "500",
    color: Colors.primary,
    marginLeft: 8,
  },
  section: {
    backgroundColor: Colors.white,
    padding: 16,
    marginTop: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.text.primary,
    marginBottom: 12,
  },
  description: {
    fontSize: 14,
    color: Colors.text.primary,
    lineHeight: 20,
    marginBottom: 16,
  },
  socialMediaSection: {
    marginTop: 8,
  },
  socialMediaTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.text.primary,
    marginBottom: 12,
  },
  tabContainer: {
    flexDirection: "row",
    backgroundColor: Colors.white,
    marginTop: 8,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  tab: {
    flex: 1,
    paddingVertical: 16,
    alignItems: "center",
    borderBottomWidth: 2,
    borderBottomColor: "transparent",
  },
  activeTab: {
    borderBottomColor: Colors.primary,
  },
  tabText: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.text.secondary,
  },
  activeTabText: {
    color: Colors.primary,
  },
  tabContent: {
    backgroundColor: Colors.white,
    padding: 16,
    paddingBottom: 24,
  },
  serviceCard: {
    backgroundColor: Colors.background,
    borderRadius: 12,
    marginBottom: 16,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: Colors.border,
  },
  serviceCardContent: {
    flexDirection: "row",
    padding: 12,
  },
  serviceMediaContainer: {
    position: "relative",
    marginRight: 12,
  },
  serviceImage: {
    width: 80,
    height: 80,
    borderRadius: 8,
  },
  mediaCountBadge: {
    position: "absolute",
    bottom: 4,
    right: 4,
    backgroundColor: "rgba(0, 0, 0, 0.7)",
    borderRadius: 10,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  mediaCountText: {
    color: Colors.white,
    fontSize: 10,
    fontWeight: "600",
  },
  noMediaContainer: {
    width: 80,
    height: 80,
    borderRadius: 8,
    backgroundColor: Colors.background,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 1,
    borderColor: Colors.border,
    marginRight: 12,
  },
  noMediaText: {
    fontSize: 12,
    color: Colors.text.secondary,
  },
  serviceInfo: {
    flex: 1,
  },
  serviceName: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.text.primary,
    marginBottom: 4,
  },
  serviceMetaContainer: {
    flexDirection: "row",
    marginBottom: 8,
  },
  serviceMeta: {
    flexDirection: "row",
    alignItems: "center",
    marginRight: 16,
  },
  serviceMetaText: {
    fontSize: 14,
    color: Colors.text.secondary,
    marginLeft: 4,
  },
  serviceDescription: {
    fontSize: 14,
    color: Colors.text.secondary,
    lineHeight: 18,
  },
  serviceCardFooter: {
    flexDirection: "row",
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  viewDetailsButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 12,
    flex: 1,
    borderRightWidth: 1,
    borderRightColor: Colors.border,
  },
  viewDetailsText: {
    fontSize: 14,
    color: Colors.primary,
    fontWeight: "500",
    marginLeft: 6,
  },
  bookServiceButton: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 12,
    flex: 1,
    backgroundColor: Colors.primary,
  },
  bookServiceText: {
    fontSize: 14,
    color: Colors.white,
    fontWeight: "600",
  },
  reviewsHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  reviewsTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.text.primary,
  },
  addReviewButton: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    backgroundColor: Colors.background,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: Colors.primary,
  },
  addReviewText: {
    fontSize: 12,
    color: Colors.primary,
    fontWeight: "500",
  },
  showMoreButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 12,
  },
  showMoreText: {
    fontSize: 14,
    color: Colors.primary,
    fontWeight: "500",
    marginRight: 4,
  },
  footer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.white,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  priceContainer: {
    flex: 1,
  },
  priceLabel: {
    fontSize: 12,
    color: Colors.text.secondary,
  },
  price: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.primary,
  },
  bookButton: {
    flex: 1,
  },
  shareButton: {
    padding: 8,
  },
});