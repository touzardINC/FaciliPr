import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Image,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Switch,
} from "react-native";
import { Stack, useRouter } from "expo-router";
import {
  Camera,
  Upload,
  Plus,
  X,
  ChevronRight,
  ChevronDown,
  Instagram,
  Facebook,
  Twitter,
  Linkedin,
  Youtube,
  Globe,
  Music,
  Github,
} from "lucide-react-native";
import Colors from "@/constants/colors";
import Button from "@/components/Button";
import { useAuthStore } from "@/store/auth-store";

const categories = [
  "Hair Stylist",
  "Makeup Artist",
  "Nail Technician",
  "Massage Therapist",
  "Personal Trainer",
  "Yoga Instructor",
  "Nutritionist",
  "Life Coach",
  "Photographer",
  "Videographer",
  "Tutor",
  "Music Teacher",
  "Language Instructor",
  "Interior Designer",
  "Personal Shopper",
];

export default function ProfessionalDetailsScreen() {
  const router = useRouter();
  const { user } = useAuthStore();
  
  // Professional details
  const [businessName, setBusinessName] = useState("");
  const [bio, setBio] = useState("");
  const [category, setCategory] = useState("");
  const [experience, setExperience] = useState("");
  const [portfolio, setPortfolio] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  
  // Services
  const [services, setServices] = useState<Array<{
    name: string;
    description: string;
    price: string;
    duration: string;
  }>>([{ name: "", description: "", price: "", duration: "" }]);
  
  // Social media
  const [socialMedia, setSocialMedia] = useState<Array<{
    platform: string;
    url: string;
    username: string;
  }>>([]);
  
  // Availability
  const [availableWeekdays, setAvailableWeekdays] = useState({
    monday: true,
    tuesday: true,
    wednesday: true,
    thursday: true,
    friday: true,
    saturday: false,
    sunday: false,
  });
  
  const [startTime, setStartTime] = useState("09:00");
  const [endTime, setEndTime] = useState("17:00");
  const [travelDistance, setTravelDistance] = useState("10");
  const [inHomeServices, setInHomeServices] = useState(true);
  
  // Terms and conditions
  const [agreeToTerms, setAgreeToTerms] = useState(false);
  
  const handleCategorySelection = () => {
    Alert.alert(
      "Select Category",
      "Choose your professional category",
      [
        ...categories.map((cat) => ({
          text: cat,
          onPress: () => setCategory(cat),
        })),
        { text: "Cancel", style: "cancel" },
      ]
    );
  };
  
  const handleAddService = () => {
    setServices([
      ...services,
      { name: "", description: "", price: "", duration: "" },
    ]);
  };
  
  const handleRemoveService = (index: number) => {
    const updatedServices = [...services];
    updatedServices.splice(index, 1);
    setServices(updatedServices);
  };
  
  const handleServiceChange = (
    index: number,
    field: string,
    value: string
  ) => {
    const updatedServices = [...services];
    updatedServices[index] = {
      ...updatedServices[index],
      [field]: value,
    };
    setServices(updatedServices);
  };
  
  const handleAddSocialMedia = () => {
    Alert.alert(
      "Add Social Media",
      "Select a platform to add",
      [
        { text: "Instagram", onPress: () => addSocialMediaPlatform("instagram") },
        { text: "Facebook", onPress: () => addSocialMediaPlatform("facebook") },
        { text: "Twitter", onPress: () => addSocialMediaPlatform("twitter") },
        { text: "LinkedIn", onPress: () => addSocialMediaPlatform("linkedin") },
        { text: "YouTube", onPress: () => addSocialMediaPlatform("youtube") },
        { text: "TikTok", onPress: () => addSocialMediaPlatform("tiktok") },
        { text: "Pinterest", onPress: () => addSocialMediaPlatform("pinterest") },
        { text: "SoundCloud", onPress: () => addSocialMediaPlatform("soundcloud") },
        { text: "GitHub", onPress: () => addSocialMediaPlatform("github") },
        { text: "Website", onPress: () => addSocialMediaPlatform("website") },
        { text: "Cancel", style: "cancel" },
      ]
    );
  };
  
  const addSocialMediaPlatform = (platform: string) => {
    // Check if platform already exists
    const exists = socialMedia.some((item) => item.platform === platform);
    if (exists) {
      Alert.alert("Error", `You've already added ${platform}`);
      return;
    }
    
    setSocialMedia([
      ...socialMedia,
      { platform, url: "", username: "" },
    ]);
  };
  
  const handleRemoveSocialMedia = (index: number) => {
    const updatedSocialMedia = [...socialMedia];
    updatedSocialMedia.splice(index, 1);
    setSocialMedia(updatedSocialMedia);
  };
  
  const handleSocialMediaChange = (
    index: number,
    field: string,
    value: string
  ) => {
    const updatedSocialMedia = [...socialMedia];
    updatedSocialMedia[index] = {
      ...updatedSocialMedia[index],
      [field]: value,
    };
    setSocialMedia(updatedSocialMedia);
  };
  
  const handleUploadPortfolio = () => {
    if (portfolio.length >= 5) {
      Alert.alert("Error", "You can upload a maximum of 5 portfolio images");
      return;
    }
    
    setIsUploading(true);
    
    // Simulate upload delay
    setTimeout(() => {
      // Random images from Unsplash
      const portfolioImages = [
        "https://images.unsplash.com/photo-1562259929-b4e1fd230771",
        "https://images.unsplash.com/photo-1534349762230-e0cadf78f5da",
        "https://images.unsplash.com/photo-1560066984-138dadb4c035",
        "https://images.unsplash.com/photo-1607006483222-9a95e4a5dbd2",
        "https://images.unsplash.com/photo-1595867818082-083862f3d630",
      ];
      
      const randomImage = portfolioImages[Math.floor(Math.random() * portfolioImages.length)];
      setPortfolio([...portfolio, randomImage]);
      setIsUploading(false);
    }, 1000);
  };
  
  const handleRemovePortfolio = (index: number) => {
    const updatedPortfolio = [...portfolio];
    updatedPortfolio.splice(index, 1);
    setPortfolio(updatedPortfolio);
  };
  
  const handleSubmit = () => {
    // Validate required fields
    if (!businessName.trim()) {
      Alert.alert("Error", "Business name is required");
      return;
    }
    
    if (!category) {
      Alert.alert("Error", "Category is required");
      return;
    }
    
    if (!bio.trim()) {
      Alert.alert("Error", "Bio is required");
      return;
    }
    
    if (!experience.trim()) {
      Alert.alert("Error", "Experience is required");
      return;
    }
    
    // Validate services
    const invalidServices = services.some(
      (service) => !service.name.trim() || !service.price.trim()
    );
    if (invalidServices) {
      Alert.alert(
        "Error",
        "All services must have at least a name and price"
      );
      return;
    }
    
    // Validate social media
    const invalidSocialMedia = socialMedia.some(
      (item) => !item.url.trim()
    );
    if (invalidSocialMedia) {
      Alert.alert(
        "Error",
        "All social media entries must have a URL"
      );
      return;
    }
    
    // Validate terms agreement
    if (!agreeToTerms) {
      Alert.alert(
        "Error",
        "You must agree to the terms and conditions"
      );
      return;
    }
    
    // Submit application
    Alert.alert(
      "Application Submitted",
      "Thank you for applying! We'll review your application and get back to you within 2-3 business days.",
      [
        {
          text: "OK",
          onPress: () => router.replace("/"),
        },
      ]
    );
  };
  
  const getSocialMediaIcon = (platform: string) => {
    switch (platform) {
      case "instagram":
        return <Instagram size={20} color="#E1306C" />;
      case "facebook":
        return <Facebook size={20} color="#1877F2" />;
      case "twitter":
        return <Twitter size={20} color="#1DA1F2" />;
      case "linkedin":
        return <Linkedin size={20} color="#0077B5" />;
      case "youtube":
        return <Youtube size={20} color="#FF0000" />;
      case "tiktok":
        return (
          <View style={styles.tiktokIcon}>
            <Text style={styles.tiktokText}>TT</Text>
          </View>
        );
      case "pinterest":
        return (
          <View style={[styles.customIcon, { backgroundColor: "#BD081C" }]}>
            <Text style={styles.customIconText}>P</Text>
          </View>
        );
      case "soundcloud":
        return <Music size={20} color="#FF7700" />;
      case "github":
        return <Github size={20} color="#333333" />;
      case "website":
      default:
        return <Globe size={20} color={Colors.primary} />;
    }
  };
  
  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={100}
    >
      <Stack.Screen options={{ title: "Professional Application" }} />
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={styles.headerText}>
            Complete your professional profile to start offering your services
          </Text>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Basic Information</Text>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Business Name</Text>
            <TextInput
              style={styles.input}
              value={businessName}
              onChangeText={setBusinessName}
              placeholder="Enter your business name"
              placeholderTextColor={Colors.text.placeholder}
            />
          </View>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Category</Text>
            <TouchableOpacity
              style={[styles.input, styles.selectInput]}
              onPress={handleCategorySelection}
            >
              <Text
                style={
                  category
                    ? styles.selectText
                    : styles.selectPlaceholder
                }
              >
                {category || "Select your category"}
              </Text>
              <ChevronDown size={20} color={Colors.text.secondary} />
            </TouchableOpacity>
          </View>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Bio</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              value={bio}
              onChangeText={setBio}
              placeholder="Tell clients about yourself and your services"
              placeholderTextColor={Colors.text.placeholder}
              multiline
              numberOfLines={4}
              textAlignVertical="top"
            />
          </View>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Experience</Text>
            <TextInput
              style={styles.input}
              value={experience}
              onChangeText={setExperience}
              placeholder="Years of experience"
              placeholderTextColor={Colors.text.placeholder}
              keyboardType="number-pad"
            />
          </View>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Portfolio</Text>
          <Text style={styles.sectionDescription}>
            Upload photos of your work to showcase your skills
          </Text>
          
          <View style={styles.portfolioContainer}>
            {portfolio.map((image, index) => (
              <View key={index} style={styles.portfolioItem}>
                <Image source={{ uri: image }} style={styles.portfolioImage} />
                <TouchableOpacity
                  style={styles.removePortfolioButton}
                  onPress={() => handleRemovePortfolio(index)}
                >
                  <X size={16} color={Colors.white} />
                </TouchableOpacity>
              </View>
            ))}
            
            <TouchableOpacity
              style={styles.addPortfolioButton}
              onPress={handleUploadPortfolio}
              disabled={isUploading || portfolio.length >= 5}
            >
              {isUploading ? (
                <Text style={styles.addPortfolioText}>Uploading...</Text>
              ) : (
                <>
                  <Plus size={24} color={Colors.primary} />
                  <Text style={styles.addPortfolioText}>
                    {portfolio.length >= 5
                      ? "Maximum reached"
                      : "Add Photo"}
                  </Text>
                </>
              )}
            </TouchableOpacity>
          </View>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Services</Text>
          <Text style={styles.sectionDescription}>
            Add the services you offer with pricing and duration
          </Text>
          
          {services.map((service, index) => (
            <View key={index} style={styles.serviceItem}>
              <View style={styles.serviceHeader}>
                <Text style={styles.serviceNumber}>Service {index + 1}</Text>
                {services.length > 1 && (
                  <TouchableOpacity
                    onPress={() => handleRemoveService(index)}
                  >
                    <X size={20} color={Colors.error} />
                  </TouchableOpacity>
                )}
              </View>
              
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Service Name</Text>
                <TextInput
                  style={styles.input}
                  value={service.name}
                  onChangeText={(value) =>
                    handleServiceChange(index, "name", value)
                  }
                  placeholder="e.g. Haircut, Massage, etc."
                  placeholderTextColor={Colors.text.placeholder}
                />
              </View>
              
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Description</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  value={service.description}
                  onChangeText={(value) =>
                    handleServiceChange(index, "description", value)
                  }
                  placeholder="Describe what this service includes"
                  placeholderTextColor={Colors.text.placeholder}
                  multiline
                  numberOfLines={3}
                  textAlignVertical="top"
                />
              </View>
              
              <View style={styles.rowInputs}>
                <View style={[styles.inputGroup, { flex: 1, marginRight: 8 }]}>
                  <Text style={styles.label}>Price ($)</Text>
                  <TextInput
                    style={styles.input}
                    value={service.price}
                    onChangeText={(value) =>
                      handleServiceChange(index, "price", value)
                    }
                    placeholder="0.00"
                    placeholderTextColor={Colors.text.placeholder}
                    keyboardType="decimal-pad"
                  />
                </View>
                
                <View style={[styles.inputGroup, { flex: 1, marginLeft: 8 }]}>
                  <Text style={styles.label}>Duration (min)</Text>
                  <TextInput
                    style={styles.input}
                    value={service.duration}
                    onChangeText={(value) =>
                      handleServiceChange(index, "duration", value)
                    }
                    placeholder="30"
                    placeholderTextColor={Colors.text.placeholder}
                    keyboardType="number-pad"
                  />
                </View>
              </View>
            </View>
          ))}
          
          <TouchableOpacity
            style={styles.addButton}
            onPress={handleAddService}
          >
            <Plus size={20} color={Colors.primary} />
            <Text style={styles.addButtonText}>Add Another Service</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Social Media</Text>
          <Text style={styles.sectionDescription}>
            Add your social media profiles to connect with clients
          </Text>
          
          {socialMedia.map((item, index) => (
            <View key={index} style={styles.socialMediaItem}>
              <View style={styles.socialMediaHeader}>
                <View style={styles.socialMediaPlatform}>
                  {getSocialMediaIcon(item.platform)}
                  <Text style={styles.socialMediaPlatformText}>
                    {item.platform.charAt(0).toUpperCase() + item.platform.slice(1)}
                  </Text>
                </View>
                <TouchableOpacity
                  onPress={() => handleRemoveSocialMedia(index)}
                >
                  <X size={20} color={Colors.error} />
                </TouchableOpacity>
              </View>
              
              <View style={styles.inputGroup}>
                <Text style={styles.label}>URL</Text>
                <TextInput
                  style={styles.input}
                  value={item.url}
                  onChangeText={(value) =>
                    handleSocialMediaChange(index, "url", value)
                  }
                  placeholder={`https://${item.platform}.com/yourusername`}
                  placeholderTextColor={Colors.text.placeholder}
                  autoCapitalize="none"
                  keyboardType="url"
                />
              </View>
              
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Username (optional)</Text>
                <TextInput
                  style={styles.input}
                  value={item.username}
                  onChangeText={(value) =>
                    handleSocialMediaChange(index, "username", value)
                  }
                  placeholder="@yourusername"
                  placeholderTextColor={Colors.text.placeholder}
                  autoCapitalize="none"
                />
              </View>
            </View>
          ))}
          
          <TouchableOpacity
            style={styles.addButton}
            onPress={handleAddSocialMedia}
          >
            <Plus size={20} color={Colors.primary} />
            <Text style={styles.addButtonText}>Add Social Media</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Availability</Text>
          <Text style={styles.sectionDescription}>
            Set your working days and hours
          </Text>
          
          <View style={styles.weekdaysContainer}>
            <View style={styles.weekdayItem}>
              <Text style={styles.weekdayText}>Monday</Text>
              <Switch
                value={availableWeekdays.monday}
                onValueChange={(value) =>
                  setAvailableWeekdays({ ...availableWeekdays, monday: value })
                }
                trackColor={{ false: Colors.gray[300], true: Colors.primary }}
                thumbColor={Colors.white}
              />
            </View>
            
            <View style={styles.weekdayItem}>
              <Text style={styles.weekdayText}>Tuesday</Text>
              <Switch
                value={availableWeekdays.tuesday}
                onValueChange={(value) =>
                  setAvailableWeekdays({ ...availableWeekdays, tuesday: value })
                }
                trackColor={{ false: Colors.gray[300], true: Colors.primary }}
                thumbColor={Colors.white}
              />
            </View>
            
            <View style={styles.weekdayItem}>
              <Text style={styles.weekdayText}>Wednesday</Text>
              <Switch
                value={availableWeekdays.wednesday}
                onValueChange={(value) =>
                  setAvailableWeekdays({ ...availableWeekdays, wednesday: value })
                }
                trackColor={{ false: Colors.gray[300], true: Colors.primary }}
                thumbColor={Colors.white}
              />
            </View>
            
            <View style={styles.weekdayItem}>
              <Text style={styles.weekdayText}>Thursday</Text>
              <Switch
                value={availableWeekdays.thursday}
                onValueChange={(value) =>
                  setAvailableWeekdays({ ...availableWeekdays, thursday: value })
                }
                trackColor={{ false: Colors.gray[300], true: Colors.primary }}
                thumbColor={Colors.white}
              />
            </View>
            
            <View style={styles.weekdayItem}>
              <Text style={styles.weekdayText}>Friday</Text>
              <Switch
                value={availableWeekdays.friday}
                onValueChange={(value) =>
                  setAvailableWeekdays({ ...availableWeekdays, friday: value })
                }
                trackColor={{ false: Colors.gray[300], true: Colors.primary }}
                thumbColor={Colors.white}
              />
            </View>
            
            <View style={styles.weekdayItem}>
              <Text style={styles.weekdayText}>Saturday</Text>
              <Switch
                value={availableWeekdays.saturday}
                onValueChange={(value) =>
                  setAvailableWeekdays({ ...availableWeekdays, saturday: value })
                }
                trackColor={{ false: Colors.gray[300], true: Colors.primary }}
                thumbColor={Colors.white}
              />
            </View>
            
            <View style={styles.weekdayItem}>
              <Text style={styles.weekdayText}>Sunday</Text>
              <Switch
                value={availableWeekdays.sunday}
                onValueChange={(value) =>
                  setAvailableWeekdays({ ...availableWeekdays, sunday: value })
                }
                trackColor={{ false: Colors.gray[300], true: Colors.primary }}
                thumbColor={Colors.white}
              />
            </View>
          </View>
          
          <View style={styles.rowInputs}>
            <View style={[styles.inputGroup, { flex: 1, marginRight: 8 }]}>
              <Text style={styles.label}>Start Time</Text>
              <TextInput
                style={styles.input}
                value={startTime}
                onChangeText={setStartTime}
                placeholder="09:00"
                placeholderTextColor={Colors.text.placeholder}
              />
            </View>
            
            <View style={[styles.inputGroup, { flex: 1, marginLeft: 8 }]}>
              <Text style={styles.label}>End Time</Text>
              <TextInput
                style={styles.input}
                value={endTime}
                onChangeText={setEndTime}
                placeholder="17:00"
                placeholderTextColor={Colors.text.placeholder}
              />
            </View>
          </View>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Travel Distance (miles)</Text>
            <TextInput
              style={styles.input}
              value={travelDistance}
              onChangeText={setTravelDistance}
              placeholder="10"
              placeholderTextColor={Colors.text.placeholder}
              keyboardType="number-pad"
            />
          </View>
          
          <View style={styles.switchItem}>
            <View>
              <Text style={styles.switchLabel}>In-Home Services</Text>
              <Text style={styles.switchDescription}>
                Are you willing to provide services at client's location?
              </Text>
            </View>
            <Switch
              value={inHomeServices}
              onValueChange={setInHomeServices}
              trackColor={{ false: Colors.gray[300], true: Colors.primary }}
              thumbColor={Colors.white}
            />
          </View>
        </View>
        
        <View style={styles.termsContainer}>
          <View style={styles.termsCheckbox}>
            <TouchableOpacity
              style={[
                styles.checkbox,
                agreeToTerms && styles.checkboxChecked,
              ]}
              onPress={() => setAgreeToTerms(!agreeToTerms)}
            >
              {agreeToTerms && <ChevronRight size={16} color={Colors.white} />}
            </TouchableOpacity>
            <Text style={styles.termsText}>
              I agree to the{" "}
              <Text
                style={styles.termsLink}
                onPress={() => {
                  // In a real app, this would navigate to the terms and conditions
                  Alert.alert(
                    "Terms and Conditions",
                    "This would show the terms and conditions",
                    [{ text: "OK" }]
                  );
                }}
              >
                Terms and Conditions
              </Text>{" "}
              and{" "}
              <Text
                style={styles.termsLink}
                onPress={() => {
                  // In a real app, this would navigate to the privacy policy
                  Alert.alert(
                    "Privacy Policy",
                    "This would show the privacy policy",
                    [{ text: "OK" }]
                  );
                }}
              >
                Privacy Policy
              </Text>
            </Text>
          </View>
        </View>
        
        <View style={styles.buttonContainer}>
          <Button
            title="Submit Application"
            onPress={handleSubmit}
            disabled={!agreeToTerms}
          />
          <TouchableOpacity
            style={styles.cancelButton}
            onPress={() => router.back()}
          >
            <Text style={styles.cancelButtonText}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    padding: 16,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.gray[300],
  },
  headerText: {
    fontSize: 14,
    color: Colors.text.secondary,
    lineHeight: 20,
  },
  section: {
    backgroundColor: Colors.white,
    marginTop: 16,
    padding: 16,
    borderRadius: 8,
    marginHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.text.primary,
    marginBottom: 8,
  },
  sectionDescription: {
    fontSize: 14,
    color: Colors.text.secondary,
    marginBottom: 16,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: "500",
    color: Colors.text.secondary,
    marginBottom: 8,
  },
  input: {
    backgroundColor: Colors.background,
    borderWidth: 1,
    borderColor: Colors.gray[300],
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: Colors.text.primary,
  },
  textArea: {
    minHeight: 100,
    textAlignVertical: "top",
  },
  selectInput: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  selectText: {
    fontSize: 16,
    color: Colors.text.primary,
  },
  selectPlaceholder: {
    fontSize: 16,
    color: Colors.text.placeholder,
  },
  portfolioContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginTop: 8,
  },
  portfolioItem: {
    width: 100,
    height: 100,
    borderRadius: 8,
    marginRight: 8,
    marginBottom: 8,
    position: "relative",
  },
  portfolioImage: {
    width: "100%",
    height: "100%",
    borderRadius: 8,
  },
  removePortfolioButton: {
    position: "absolute",
    top: 4,
    right: 4,
    backgroundColor: "rgba(0, 0, 0, 0.6)",
    borderRadius: 12,
    width: 24,
    height: 24,
    alignItems: "center",
    justifyContent: "center",
  },
  addPortfolioButton: {
    width: 100,
    height: 100,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.gray[300],
    borderStyle: "dashed",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.background,
  },
  addPortfolioText: {
    fontSize: 12,
    color: Colors.primary,
    marginTop: 4,
    textAlign: "center",
  },
  serviceItem: {
    backgroundColor: Colors.background,
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
  },
  serviceHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  serviceNumber: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.text.primary,
  },
  rowInputs: {
    flexDirection: "row",
  },
  addButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 12,
    borderWidth: 1,
    borderColor: Colors.primary,
    borderRadius: 8,
    marginTop: 8,
  },
  addButtonText: {
    fontSize: 14,
    fontWeight: "500",
    color: Colors.primary,
    marginLeft: 8,
  },
  socialMediaItem: {
    backgroundColor: Colors.background,
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
  },
  socialMediaHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  socialMediaPlatform: {
    flexDirection: "row",
    alignItems: "center",
  },
  socialMediaPlatformText: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.text.primary,
    marginLeft: 8,
  },
  weekdaysContainer: {
    marginBottom: 16,
  },
  weekdayItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.gray[300],
  },
  weekdayText: {
    fontSize: 16,
    color: Colors.text.primary,
  },
  switchItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 8,
  },
  switchLabel: {
    fontSize: 16,
    fontWeight: "500",
    color: Colors.text.primary,
    marginBottom: 4,
  },
  switchDescription: {
    fontSize: 14,
    color: Colors.text.secondary,
    maxWidth: "80%",
  },
  termsContainer: {
    marginHorizontal: 16,
    marginTop: 24,
    marginBottom: 16,
  },
  termsCheckbox: {
    flexDirection: "row",
    alignItems: "flex-start",
  },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 4,
    borderWidth: 2,
    borderColor: Colors.primary,
    marginRight: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  checkboxChecked: {
    backgroundColor: Colors.primary,
  },
  termsText: {
    fontSize: 14,
    color: Colors.text.secondary,
    flex: 1,
    lineHeight: 20,
  },
  termsLink: {
    color: Colors.primary,
    fontWeight: "500",
  },
  buttonContainer: {
    marginHorizontal: 16,
    marginBottom: 32,
  },
  cancelButton: {
    marginTop: 12,
    padding: 12,
    alignItems: "center",
  },
  cancelButtonText: {
    fontSize: 16,
    color: Colors.text.secondary,
    fontWeight: "500",
  },
  tiktokIcon: {
    alignItems: "center",
    justifyContent: "center",
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: "#000000",
  },
  tiktokText: {
    fontSize: 12,
    fontWeight: "700",
    color: "#FFFFFF",
  },
  customIcon: {
    alignItems: "center",
    justifyContent: "center",
    width: 20,
    height: 20,
    borderRadius: 10,
  },
  customIconText: {
    fontSize: 12,
    fontWeight: "700",
    color: "#FFFFFF",
  },
});