import React, { useState, useEffect } from "react";
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  ActivityIndicator,
} from "react-native";
import { useLocalSearchParams, useRouter, Stack } from "expo-router";
import {
  Calendar,
  Clock,
  MapPin,
  CreditCard,
  ChevronRight,
} from "lucide-react-native";
import Colors from "@/constants/colors";
import { professionals } from "@/mocks/professionals";
import { useAuthStore } from "@/store/auth-store";
import { useBookingStore } from "@/store/booking-store";
import { usePaymentStore } from "@/store/payment-store";
import { useLocationStore } from "@/store/location-store";
import Button from "@/components/Button";
import ServiceItem from "@/components/ServiceItem";
import PaymentMethodCard from "@/components/PaymentMethodCard";
import LocationPicker from "@/components/LocationPicker";
import { Professional, Service } from "@/types/professional";
import { PaymentMethod } from "@/types/payment";

export default function NewBookingScreen() {
  const router = useRouter();
  const { professionalId } = useLocalSearchParams();
  const { user, isAuthenticated } = useAuthStore();
  const { addBooking, isLoading: isBookingLoading } = useBookingStore();
  const { paymentMethods, getPaymentMethods, isLoading: isPaymentLoading } = usePaymentStore();
  const { savedLocations, currentLocation, getCurrentLocation } = useLocationStore();
  
  const [professional, setProfessional] = useState<Professional | null>(null);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [selectedTime, setSelectedTime] = useState<string>("");
  const [selectedAddress, setSelectedAddress] = useState<string>("");
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<PaymentMethod | null>(null);
  const [notes, setNotes] = useState<string>("");
  const [showPaymentMethods, setShowPaymentMethods] = useState(false);
  const [showLocationPicker, setShowLocationPicker] = useState(false);

  // Mock data for date and time selection
  const availableDates = [
    "2023-11-15",
    "2023-11-16",
    "2023-11-17",
    "2023-11-18",
    "2023-11-19",
  ];
  
  const availableTimes = [
    "09:00",
    "10:00",
    "11:00",
    "13:00",
    "14:00",
    "15:00",
    "16:00",
  ];

  useEffect(() => {
    if (professionalId) {
      const foundProfessional = professionals.find((p) => p.id === professionalId);
      if (foundProfessional) {
        setProfessional(foundProfessional);
        if (foundProfessional.services.length > 0) {
          setSelectedService(foundProfessional.services[0]);
        }
      }
    }
    
    // Set default address from saved locations
    if (savedLocations.length > 0) {
      const defaultLocation = savedLocations.find(loc => loc.isDefault);
      if (defaultLocation) {
        setSelectedAddress(defaultLocation.address);
      } else {
        setSelectedAddress(savedLocations[0].address);
      }
    } else if (currentLocation) {
      setSelectedAddress(currentLocation.address);
    }

    if (isAuthenticated) {
      getPaymentMethods();
    }
  }, [professionalId, savedLocations, currentLocation, isAuthenticated]);

  // Fixed: Only set payment method when paymentMethods changes and has items
  useEffect(() => {
    if (paymentMethods.length > 0 && !selectedPaymentMethod) {
      const defaultPaymentMethod = paymentMethods.find(pm => pm.isDefault);
      setSelectedPaymentMethod(defaultPaymentMethod || paymentMethods[0]);
    }
  }, [paymentMethods]);

  const handleServiceSelect = (service: Service) => {
    setSelectedService(service);
  };

  const handleDateSelect = (date: string) => {
    setSelectedDate(date);
  };

  const handleTimeSelect = (time: string) => {
    setSelectedTime(time);
  };

  const handlePaymentMethodSelect = (paymentMethod: PaymentMethod) => {
    setSelectedPaymentMethod(paymentMethod);
    setShowPaymentMethods(false);
  };

  const handleLocationSelect = (location: {
    latitude: number;
    longitude: number;
    address: string;
  }) => {
    setSelectedAddress(location.address);
    setShowLocationPicker(false);
  };

  const handleBookNow = async () => {
    if (!isAuthenticated) {
      Alert.alert(
        "Sign In Required",
        "Please sign in to book a service",
        [
          {
            text: "Cancel",
            style: "cancel",
          },
          {
            text: "Sign In",
            onPress: () => router.push("/login"),
          },
        ]
      );
      return;
    }

    if (!selectedService || !selectedDate || !selectedTime || !selectedAddress || !selectedPaymentMethod) {
      Alert.alert("Missing Information", "Please fill in all required fields");
      return;
    }

    try {
      const booking = await addBooking({
        userId: user!.id,
        professionalId: professional!.id,
        serviceId: selectedService.id,
        date: selectedDate,
        time: selectedTime,
        status: "pending",
        price: selectedService.price,
        address: selectedAddress,
        notes: notes,
      });

      // Navigate to confirmation screen
      router.push("/booking/confirmation");
    } catch (error) {
      Alert.alert("Error", "Failed to create booking. Please try again.");
    }
  };

  if (!professional) {
    return (
      <SafeAreaView style={styles.container}>
        <Text>Professional not found</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen
        options={{
          title: "Book a Service",
          headerTitleStyle: {
            fontWeight: "600",
          },
        }}
      />
      
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.professionalCard}>
          <View style={styles.professionalInfo}>
            <Text style={styles.professionalName}>{professional.name}</Text>
            <View style={styles.ratingContainer}>
              <Text style={styles.rating}>
                ★ {professional.rating.toFixed(1)} ({professional.reviewCount} reviews)
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Select Service</Text>
          {professional.services.map((service) => (
            <ServiceItem
              key={service.id}
              service={service}
              isSelected={selectedService?.id === service.id}
              onSelect={handleServiceSelect}
            />
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Select Date</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {availableDates.map((date) => (
              <TouchableOpacity
                key={date}
                style={[
                  styles.dateItem,
                  selectedDate === date && styles.selectedDateItem,
                ]}
                onPress={() => handleDateSelect(date)}
              >
                <Text
                  style={[
                    styles.dateText,
                    selectedDate === date && styles.selectedDateText,
                  ]}
                >
                  {new Date(date).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                  })}
                </Text>
                <Text
                  style={[
                    styles.dayText,
                    selectedDate === date && styles.selectedDateText,
                  ]}
                >
                  {new Date(date).toLocaleDateString("en-US", {
                    weekday: "short",
                  })}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Select Time</Text>
          <View style={styles.timeContainer}>
            {availableTimes.map((time) => (
              <TouchableOpacity
                key={time}
                style={[
                  styles.timeItem,
                  selectedTime === time && styles.selectedTimeItem,
                ]}
                onPress={() => handleTimeSelect(time)}
              >
                <Text
                  style={[
                    styles.timeText,
                    selectedTime === time && styles.selectedTimeText,
                  ]}
                >
                  {time}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Location</Text>
          {!showLocationPicker ? (
            <TouchableOpacity
              style={styles.addressItem}
              onPress={() => setShowLocationPicker(true)}
            >
              <View style={styles.addressContent}>
                <MapPin size={20} color={Colors.primary} />
                <Text style={styles.addressText}>{selectedAddress || "Select a location"}</Text>
              </View>
              <ChevronRight size={20} color={Colors.text.secondary} />
            </TouchableOpacity>
          ) : (
            <View style={styles.locationPickerContainer}>
              <LocationPicker 
                onLocationSelect={handleLocationSelect}
                initialAddress={selectedAddress}
              />
              <View style={styles.savedLocationsContainer}>
                <Text style={styles.savedLocationsTitle}>Saved Locations</Text>
                {savedLocations.map((location) => (
                  <TouchableOpacity
                    key={location.id}
                    style={styles.savedLocationItem}
                    onPress={() => {
                      setSelectedAddress(location.address);
                      setShowLocationPicker(false);
                    }}
                  >
                    <MapPin size={16} color={Colors.primary} />
                    <View style={styles.savedLocationContent}>
                      <Text style={styles.savedLocationName}>{location.name}</Text>
                      <Text style={styles.savedLocationAddress} numberOfLines={1}>
                        {location.address}
                      </Text>
                    </View>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Payment Method</Text>
          {isPaymentLoading ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="small" color={Colors.primary} />
              <Text style={styles.loadingText}>Loading payment methods...</Text>
            </View>
          ) : paymentMethods.length === 0 ? (
            <TouchableOpacity
              style={styles.addPaymentButton}
              onPress={() => router.push("/profile/payment/add")}
            >
              <CreditCard size={20} color={Colors.primary} />
              <Text style={styles.addPaymentText}>Add Payment Method</Text>
            </TouchableOpacity>
          ) : (
            <>
              {!showPaymentMethods ? (
                <TouchableOpacity
                  style={styles.paymentItem}
                  onPress={() => setShowPaymentMethods(true)}
                >
                  <View style={styles.paymentContent}>
                    <CreditCard size={20} color={Colors.primary} />
                    <Text style={styles.paymentText}>
                      {selectedPaymentMethod?.name || "Select Payment Method"}
                    </Text>
                  </View>
                  <ChevronRight size={20} color={Colors.text.secondary} />
                </TouchableOpacity>
              ) : (
                <View style={styles.paymentMethodsContainer}>
                  {paymentMethods.map((paymentMethod) => (
                    <PaymentMethodCard
                      key={paymentMethod.id}
                      paymentMethod={paymentMethod}
                      isSelected={selectedPaymentMethod?.id === paymentMethod.id}
                      onSelect={handlePaymentMethodSelect}
                      showActions={false}
                    />
                  ))}
                  <TouchableOpacity
                    style={styles.addNewPaymentButton}
                    onPress={() => router.push("/profile/payment/add")}
                  >
                    <Text style={styles.addNewPaymentText}>
                      + Add New Payment Method
                    </Text>
                  </TouchableOpacity>
                </View>
              )}
            </>
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Notes (Optional)</Text>
          <TextInput
            style={styles.notesInput}
            placeholder="Add any special instructions or details..."
            value={notes}
            onChangeText={setNotes}
            multiline
            numberOfLines={4}
          />
        </View>

        <View style={styles.summarySection}>
          <Text style={styles.sectionTitle}>Booking Summary</Text>
          
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Service</Text>
            <Text style={styles.summaryValue}>{selectedService?.name}</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Date & Time</Text>
            <Text style={styles.summaryValue}>
              {selectedDate && selectedTime
                ? `${new Date(selectedDate).toLocaleDateString("en-US", {
                    month: "long",
                    day: "numeric",
                    year: "numeric",
                  })} at ${selectedTime}`
                : "Not selected"}
            </Text>
          </View>
          
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Professional</Text>
            <Text style={styles.summaryValue}>{professional.name}</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Location</Text>
            <Text style={styles.summaryValue}>{selectedAddress || "Not selected"}</Text>
          </View>
          
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Payment Method</Text>
            <Text style={styles.summaryValue}>
              {selectedPaymentMethod?.name || "Not selected"}
            </Text>
          </View>
          
          <View style={styles.divider} />
          
          <View style={styles.totalItem}>
            <Text style={styles.totalLabel}>Total</Text>
            <Text style={styles.totalValue}>
              ${selectedService?.price.toFixed(2)}
            </Text>
          </View>
        </View>
      </ScrollView>

      <View style={styles.footer}>
        <Button
          title="Book Now"
          onPress={handleBookNow}
          loading={isBookingLoading}
          disabled={
            !selectedService || 
            !selectedDate || 
            !selectedTime || 
            !selectedAddress ||
            !selectedPaymentMethod
          }
        />
      </View>
    </SafeAreaView>
  );
}

// This component is needed for the notes input
import { TextInput } from "react-native";

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  professionalCard: {
    backgroundColor: Colors.white,
    padding: 16,
    marginBottom: 8,
  },
  professionalInfo: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  professionalName: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.text.primary,
  },
  ratingContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  rating: {
    fontSize: 14,
    color: Colors.text.secondary,
  },
  section: {
    backgroundColor: Colors.white,
    padding: 16,
    marginBottom: 8,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: Colors.text.primary,
    marginBottom: 12,
  },
  dateItem: {
    width: 80,
    height: 80,
    borderRadius: 12,
    backgroundColor: Colors.background,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 12,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  selectedDateItem: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  dateText: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.text.primary,
    marginBottom: 4,
  },
  dayText: {
    fontSize: 14,
    color: Colors.text.secondary,
  },
  selectedDateText: {
    color: Colors.white,
  },
  timeContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  timeItem: {
    width: "30%",
    borderRadius: 8,
    backgroundColor: Colors.background,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 12,
    marginRight: "5%",
    marginBottom: 12,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  timeItem3n: {
    marginRight: 0,
  },
  selectedTimeItem: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  timeText: {
    fontSize: 14,
    fontWeight: "500",
    color: Colors.text.primary,
  },
  selectedTimeText: {
    color: Colors.white,
  },
  addressItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    paddingHorizontal: 12,
  },
  addressContent: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  addressText: {
    fontSize: 14,
    color: Colors.text.primary,
    marginLeft: 8,
    flex: 1,
  },
  locationPickerContainer: {
    marginBottom: 16,
  },
  savedLocationsContainer: {
    marginTop: 16,
  },
  savedLocationsTitle: {
    fontSize: 14,
    fontWeight: "600",
    color: Colors.text.primary,
    marginBottom: 8,
  },
  savedLocationItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: 12,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    marginBottom: 8,
  },
  savedLocationContent: {
    marginLeft: 8,
    flex: 1,
  },
  savedLocationName: {
    fontSize: 14,
    fontWeight: "500",
    color: Colors.text.primary,
  },
  savedLocationAddress: {
    fontSize: 12,
    color: Colors.text.secondary,
  },
  paymentItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    paddingHorizontal: 12,
  },
  paymentContent: {
    flexDirection: "row",
    alignItems: "center",
  },
  paymentText: {
    fontSize: 14,
    color: Colors.text.primary,
    marginLeft: 8,
  },
  paymentMethodsContainer: {
    marginTop: 8,
  },
  addNewPaymentButton: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 12,
    marginTop: 8,
  },
  addNewPaymentText: {
    fontSize: 14,
    color: Colors.primary,
    fontWeight: "500",
  },
  addPaymentButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 12,
    borderWidth: 1,
    borderStyle: "dashed",
    borderColor: Colors.primary,
    borderRadius: 8,
  },
  addPaymentText: {
    fontSize: 14,
    color: Colors.primary,
    fontWeight: "500",
    marginLeft: 8,
  },
  notesInput: {
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    padding: 12,
    height: 100,
    textAlignVertical: "top",
    fontSize: 14,
  },
  loadingContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 16,
  },
  loadingText: {
    fontSize: 14,
    color: Colors.text.secondary,
    marginLeft: 8,
  },
  summarySection: {
    backgroundColor: Colors.white,
    padding: 16,
    marginBottom: 100,
  },
  summaryItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  summaryLabel: {
    fontSize: 14,
    color: Colors.text.secondary,
  },
  summaryValue: {
    fontSize: 14,
    color: Colors.text.primary,
    fontWeight: "500",
  },
  divider: {
    height: 1,
    backgroundColor: Colors.border,
    marginVertical: 12,
  },
  totalItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: "700",
    color: Colors.text.primary,
  },
  totalValue: {
    fontSize: 20,
    fontWeight: "700",
    color: Colors.primary,
  },
  footer: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: Colors.white,
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
});