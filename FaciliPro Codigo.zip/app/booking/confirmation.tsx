import React, { useEffect, useRef, useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  Animated,
  TouchableOpacity,
  Platform,
} from "react-native";
import { useRouter, Stack } from "expo-router";
import { CheckCircle, Calendar } from "lucide-react-native";
import { Audio } from "expo-av";
import Colors from "@/constants/colors";
import Button from "@/components/Button";

export default function BookingConfirmationScreen() {
  const router = useRouter();
  const [sound, setSound] = useState<Audio.Sound | null>(null);
  
  // Animation values
  const checkmarkScale = useRef(new Animated.Value(0)).current;
  const fadeIn = useRef(new Animated.Value(0)).current;
  
  useEffect(() => {
    // Start animations
    Animated.sequence([
      Animated.timing(checkmarkScale, {
        toValue: 1.2,
        duration: 400,
        useNativeDriver: true,
      }),
      Animated.spring(checkmarkScale, {
        toValue: 1,
        friction: 4,
        useNativeDriver: true,
      }),
    ]).start();
    
    Animated.timing(fadeIn, {
      toValue: 1,
      duration: 600,
      delay: 300,
      useNativeDriver: true,
    }).start();
    
    // Play success sound
    const playSound = async () => {
      try {
        const { sound } = await Audio.Sound.createAsync(
          require("@/assets/sounds/success.mp3"),
          { shouldPlay: true }
        );
        setSound(sound);
        
        // Listen for playback status updates
        sound.setOnPlaybackStatusUpdate((status) => {
          if (status.isLoaded && status.didJustFinish) {
            // Release the sound resource when finished
            sound.unloadAsync();
          }
        });
      } catch (error) {
        console.log("Error playing sound:", error);
      }
    };
    
    // Only play sound on native platforms
    if (Platform.OS !== "web") {
      playSound();
    }
    
    // Cleanup
    return () => {
      if (sound) {
        sound.unloadAsync();
      }
    };
  }, []);
  
  const handleViewBookings = () => {
    router.replace("/(tabs)/bookings");
  };
  
  const handleBookAnother = () => {
    router.replace("/(tabs)/index");
  };
  
  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen
        options={{
          title: "Booking Confirmation",
          headerShown: false,
        }}
      />
      
      <View style={styles.content}>
        <Animated.View
          style={[
            styles.checkmarkContainer,
            {
              transform: [{ scale: checkmarkScale }],
            },
          ]}
        >
          <CheckCircle size={100} color={Colors.success} fill={Colors.success} />
        </Animated.View>
        
        <Animated.View
          style={[
            styles.textContainer,
            {
              opacity: fadeIn,
              transform: [
                {
                  translateY: fadeIn.interpolate({
                    inputRange: [0, 1],
                    outputRange: [20, 0],
                  }),
                },
              ],
            },
          ]}
        >
          <Text style={styles.title}>Your service was booked!</Text>
          <Text style={styles.subtitle}>
            Your booking has been confirmed. You'll receive a notification with all the details.
          </Text>
        </Animated.View>
        
        <Animated.View
          style={[
            styles.buttonContainer,
            {
              opacity: fadeIn,
            },
          ]}
        >
          <Button
            title="View My Bookings"
            onPress={handleViewBookings}
            icon={<Calendar size={18} color={Colors.white} style={{ marginRight: 8 }} />}
            style={styles.viewBookingsButton}
          />
          
          <TouchableOpacity
            style={styles.bookAnotherButton}
            onPress={handleBookAnother}
          >
            <Text style={styles.bookAnotherText}>Book Another Service</Text>
          </TouchableOpacity>
        </Animated.View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  content: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  checkmarkContainer: {
    marginBottom: 32,
  },
  textContainer: {
    alignItems: "center",
    marginBottom: 40,
  },
  title: {
    fontSize: 24,
    fontWeight: "700",
    color: Colors.text.primary,
    marginBottom: 12,
    textAlign: "center",
  },
  subtitle: {
    fontSize: 16,
    color: Colors.text.secondary,
    textAlign: "center",
    lineHeight: 24,
  },
  buttonContainer: {
    width: "100%",
  },
  viewBookingsButton: {
    marginBottom: 16,
  },
  bookAnotherButton: {
    alignItems: "center",
    paddingVertical: 12,
  },
  bookAnotherText: {
    fontSize: 16,
    color: Colors.primary,
    fontWeight: "500",
  },
});