import React, { useState, useEffect } from "react";
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  Image,
} from "react-native";
import { useLocalSearchParams, useRouter, Stack } from "expo-router";
import {
  Calendar,
  Clock,
  MapPin,
  CheckCircle,
  XCircle,
  Star,
  CreditCard,
  Camera,
  X,
} from "lucide-react-native";
import * as ImagePicker from "expo-image-picker";
import Colors from "@/constants/colors";
import { professionals } from "@/mocks/professionals";
import { useBookingStore } from "@/store/booking-store";
import { usePaymentStore } from "@/store/payment-store";
import Button from "@/components/Button";
import { Booking } from "@/types/booking";
import { Professional } from "@/types/professional";
import { PaymentMethod } from "@/types/payment";
import AddReviewForm from "@/components/AddReviewForm";

export default function BookingDetailScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams();
  const { bookings, updateBookingStatus, addReview, isLoading } = useBookingStore();
  const { paymentMethods, processPayment, isLoading: isPaymentLoading } = usePaymentStore();
  
  const [booking, setBooking] = useState<Booking | null>(null);
  const [professional, setProfessional] = useState<Professional | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod | null>(null);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);

  useEffect(() => {
    if (id) {
      const foundBooking = bookings.find((b) => b.id === id);
      if (foundBooking) {
        setBooking(foundBooking);
        
        const foundProfessional = professionals.find(
          (p) => p.id === foundBooking.professionalId
        );
        if (foundProfessional) {
          setProfessional(foundProfessional);
        }
      }
    }
  }, [id, bookings]);

  useEffect(() => {
    if (paymentMethods.length > 0 && !paymentMethod) {
      const defaultPaymentMethod = paymentMethods.find(pm => pm.isDefault);
      setPaymentMethod(defaultPaymentMethod || paymentMethods[0]);
    }
  }, [paymentMethods]);

  const handleCancelBooking = () => {
    Alert.alert(
      "Cancel Booking",
      "Are you sure you want to cancel this booking?",
      [
        {
          text: "No",
          style: "cancel",
        },
        {
          text: "Yes, Cancel",
          onPress: async () => {
            try {
              await updateBookingStatus(booking!.id, "cancelled");
              Alert.alert("Success", "Booking has been cancelled");
            } catch (error) {
              Alert.alert("Error", "Failed to cancel booking");
            }
          },
          style: "destructive",
        },
      ]
    );
  };

  const handleSubmitReview = async (rating: number, comment: string, images: string[]) => {
    if (!booking) return;
    
    try {
      // In a real app, you would upload the images to a server and get URLs back
      // For this demo, we'll just simulate the review submission
      await addReview(booking.id, rating, comment);
      
      // Update the booking locally with the new review
      setBooking({
        ...booking,
        status: "completed",
        review: {
          rating,
          comment,
          date: new Date().toISOString(),
        },
      });
      
      setShowReviewForm(false);
      Alert.alert("Success", "Thank you for your review!");
    } catch (error) {
      Alert.alert("Error", "Failed to submit review");
    }
  };

  const handlePayNow = async () => {
    if (!booking || !paymentMethod) {
      Alert.alert("Error", "Payment method not selected");
      return;
    }

    setIsProcessingPayment(true);
    try {
      await processPayment(booking.id, booking.price, paymentMethod.id);
      await updateBookingStatus(booking.id, "confirmed");
      
      // Navigate to confirmation screen
      router.push("/booking/confirmation");
    } catch (error) {
      Alert.alert("Payment Failed", "Please try again or use a different payment method");
      setIsProcessingPayment(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return Colors.primary; // Green
      case "pending":
        return Colors.accent; // Light Tan
      case "completed":
        return Colors.success; // Green
      case "cancelled":
        return Colors.error; // Red
      default:
        return Colors.text.secondary;
    }
  };

  if (!booking || !professional) {
    return (
      <SafeAreaView style={styles.container}>
        <Text>Booking not found</Text>
      </SafeAreaView>
    );
  }

  const service = professional.services.find(s => s.id === booking.serviceId);

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen
        options={{
          title: "Booking Details",
          headerTitleStyle: {
            fontWeight: "600",
          },
        }}
      />
      
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.statusContainer}>
          <View
            style={[
              styles.statusBadge,
              { backgroundColor: getStatusColor(booking.status) },
            ]}
          >
            <Text style={styles.statusText}>
              {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
            </Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Service Details</Text>
          
          <View style={styles.serviceCard}>
            {service?.imageUrl && (
              <Image
                source={{ uri: service.imageUrl }}
                style={styles.serviceImage}
                resizeMode="cover"
              />
            )}
            
            <View style={styles.serviceInfo}>
              <Text style={styles.serviceName}>{service?.name || "Service"}</Text>
              
              <View style={styles.serviceMetaContainer}>
                <View style={styles.serviceMeta}>
                  <Text style={styles.serviceProvider}>
                    by {professional.name}
                  </Text>
                </View>
                
                <View style={styles.serviceMeta}>
                  <Text style={styles.servicePrice}>
                    ${booking.price.toFixed(2)}
                  </Text>
                </View>
              </View>
              
              {service?.description && (
                <Text style={styles.serviceDescription} numberOfLines={3}>
                  {service.description}
                </Text>
              )}
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Schedule</Text>
          
          <View style={styles.scheduleItem}>
            <Calendar size={20} color={Colors.primary} />
            <Text style={styles.scheduleText}>
              {new Date(booking.date).toLocaleDateString("en-US", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </Text>
          </View>
          
          <View style={styles.scheduleItem}>
            <Clock size={20} color={Colors.primary} />
            <Text style={styles.scheduleText}>{booking.time}</Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Location</Text>
          
          <View style={styles.locationItem}>
            <MapPin size={20} color={Colors.primary} />
            <Text style={styles.locationText}>{booking.address}</Text>
          </View>
        </View>

        {booking.notes && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Notes</Text>
            <Text style={styles.notesText}>{booking.notes}</Text>
          </View>
        )}

        {booking.status === "pending" && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Payment</Text>
            <Text style={styles.paymentText}>
              Complete your payment to confirm this booking
            </Text>
            
            <View style={styles.paymentMethodContainer}>
              <View style={styles.paymentMethodHeader}>
                <Text style={styles.paymentMethodTitle}>Payment Method</Text>
                <TouchableOpacity onPress={() => router.push("/profile/payment")}>
                  <Text style={styles.changeText}>Change</Text>
                </TouchableOpacity>
              </View>
              
              <View style={styles.paymentMethodItem}>
                <CreditCard size={20} color={Colors.primary} />
                <Text style={styles.paymentMethodText}>
                  {paymentMethod?.name || "Select a payment method"}
                </Text>
              </View>
            </View>
            
            <View style={styles.totalContainer}>
              <Text style={styles.totalLabel}>Total</Text>
              <Text style={styles.totalValue}>${booking.price.toFixed(2)}</Text>
            </View>
            
            <Button
              title="Pay Now"
              onPress={handlePayNow}
              loading={isProcessingPayment}
              disabled={!paymentMethod}
              style={styles.payButton}
            />
          </View>
        )}

        {booking.status === "completed" && !booking.review && !showReviewForm && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Leave a Review</Text>
            <Text style={styles.reviewPrompt}>
              Share your experience with {professional.name}
            </Text>
            <Button
              title="Write a Review"
              onPress={() => setShowReviewForm(true)}
              variant="outline"
              style={styles.writeReviewButton}
            />
          </View>
        )}

        {showReviewForm && (
          <View style={styles.section}>
            <AddReviewForm
              onSubmit={handleSubmitReview}
              onCancel={() => setShowReviewForm(false)}
              isLoading={isLoading}
            />
          </View>
        )}

        {booking.review && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Your Review</Text>
            
            <View style={styles.reviewContainer}>
              <View style={styles.ratingDisplay}>
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    size={20}
                    color={Colors.accent}
                    fill={star <= booking.review!.rating ? Colors.accent : "transparent"}
                    style={styles.starIcon}
                  />
                ))}
              </View>
              
              <Text style={styles.reviewDate}>
                {new Date(booking.review.date).toLocaleDateString()}
              </Text>
              
              <Text style={styles.reviewComment}>{booking.review.comment}</Text>
            </View>
          </View>
        )}

        {(booking.status === "pending" || booking.status === "confirmed") && (
          <View style={styles.actionSection}>
            <Button
              title="Cancel Booking"
              onPress={handleCancelBooking}
              variant="outline"
              loading={isLoading}
              style={styles.cancelButton}
              textStyle={styles.cancelButtonText}
            />
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  statusContainer: {
    backgroundColor: Colors.white,
    padding: 16,
    alignItems: "center",
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  statusBadge: {
    paddingVertical: 6,
    paddingHorizontal: 16,
    borderRadius: 20,
  },
  statusText: {
    color: Colors.white,
    fontWeight: "600",
    fontSize: 14,
  },
  section: {
    backgroundColor: Colors.white,
    padding: 16,
    marginTop: 8,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: Colors.text.primary,
    marginBottom: 16,
  },
  serviceCard: {
    flexDirection: "row",
    backgroundColor: Colors.background,
    borderRadius: 12,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: Colors.border,
  },
  serviceImage: {
    width: 100,
    height: 100,
  },
  serviceInfo: {
    flex: 1,
    padding: 12,
  },
  serviceName: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.text.primary,
    marginBottom: 4,
  },
  serviceMetaContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 8,
  },
  serviceMeta: {
    flexDirection: "row",
    alignItems: "center",
  },
  serviceProvider: {
    fontSize: 14,
    color: Colors.text.secondary,
  },
  servicePrice: {
    fontSize: 16,
    fontWeight: "700",
    color: Colors.primary,
  },
  serviceDescription: {
    fontSize: 14,
    color: Colors.text.secondary,
    lineHeight: 18,
  },
  detailItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  detailLabel: {
    fontSize: 14,
    color: Colors.text.secondary,
  },
  detailValue: {
    fontSize: 14,
    fontWeight: "500",
    color: Colors.text.primary,
  },
  scheduleItem: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },
  scheduleText: {
    fontSize: 14,
    color: Colors.text.primary,
    marginLeft: 12,
  },
  locationItem: {
    flexDirection: "row",
    alignItems: "flex-start",
  },
  locationText: {
    fontSize: 14,
    color: Colors.text.primary,
    marginLeft: 12,
    flex: 1,
  },
  notesText: {
    fontSize: 14,
    color: Colors.text.primary,
    lineHeight: 20,
  },
  paymentText: {
    fontSize: 14,
    color: Colors.text.secondary,
    marginBottom: 16,
  },
  paymentMethodContainer: {
    backgroundColor: Colors.background,
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
  },
  paymentMethodHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  paymentMethodTitle: {
    fontSize: 14,
    fontWeight: "600",
    color: Colors.text.primary,
  },
  changeText: {
    fontSize: 14,
    color: Colors.primary,
    fontWeight: "500",
  },
  paymentMethodItem: {
    flexDirection: "row",
    alignItems: "center",
  },
  paymentMethodText: {
    fontSize: 14,
    color: Colors.text.primary,
    marginLeft: 12,
  },
  totalContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.text.primary,
  },
  totalValue: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.primary,
  },
  payButton: {
    marginTop: 8,
  },
  actionSection: {
    backgroundColor: Colors.white,
    padding: 16,
    marginTop: 8,
    marginBottom: 24,
  },
  cancelButton: {
    backgroundColor: "transparent",
    borderColor: Colors.error,
  },
  cancelButtonText: {
    color: Colors.error,
  },
  reviewPrompt: {
    fontSize: 14,
    color: Colors.text.secondary,
    marginBottom: 16,
  },
  writeReviewButton: {
    marginTop: 8,
  },
  reviewContainer: {
    backgroundColor: Colors.background,
    borderRadius: 8,
    padding: 12,
  },
  ratingDisplay: {
    flexDirection: "row",
    marginBottom: 8,
  },
  starIcon: {
    marginRight: 4,
  },
  reviewDate: {
    fontSize: 12,
    color: Colors.text.secondary,
    marginBottom: 8,
  },
  reviewComment: {
    fontSize: 14,
    color: Colors.text.primary,
    lineHeight: 20,
  },
  reviewForm: {
    marginTop: 8,
  },
  reviewLabel: {
    fontSize: 14,
    fontWeight: "600",
    color: Colors.text.primary,
    marginBottom: 8,
  },
  ratingContainer: {
    flexDirection: "row",
    marginBottom: 16,
  },
  commentInput: {
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 8,
    padding: 12,
    height: 100,
    textAlignVertical: "top",
    marginBottom: 16,
  },
  submitButton: {
    marginTop: 8,
  },
  imagesContainer: {
    marginBottom: 16,
  },
  imagesLabel: {
    fontSize: 14,
    fontWeight: "600",
    color: Colors.text.primary,
    marginBottom: 8,
  },
  imagesRow: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  imagePreviewContainer: {
    width: 80,
    height: 80,
    borderRadius: 8,
    marginRight: 8,
    marginBottom: 8,
    position: "relative",
  },
  imagePreview: {
    width: "100%",
    height: "100%",
    borderRadius: 8,
  },
  removeImageButton: {
    position: "absolute",
    top: -8,
    right: -8,
    backgroundColor: Colors.error,
    borderRadius: 12,
    width: 24,
    height: 24,
    alignItems: "center",
    justifyContent: "center",
  },
  addImageButton: {
    width: 80,
    height: 80,
    borderRadius: 8,
    borderWidth: 1,
    borderStyle: "dashed",
    borderColor: Colors.primary,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.background,
  },
});