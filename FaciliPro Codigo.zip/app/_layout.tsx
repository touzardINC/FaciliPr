import FontAwesome from "@expo/vector-icons/FontAwesome";
import { useFonts } from "expo-font";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import { useEffect } from "react";
import { Platform } from "react-native";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { trpc, trpcClient } from "@/lib/trpc";

import { ErrorBoundary } from "./error-boundary";
import Colors from "@/constants/colors";

export const unstable_settings = {
  // Ensure that reloading on `/modal` keeps a back button present.
  initialRouteName: "(tabs)",
};

// Create a client for React Query
const queryClient = new QueryClient();

// Prevent the splash screen from auto-hiding before asset loading is complete.
SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const [loaded, error] = useFonts({
    ...FontAwesome.font,
  });

  useEffect(() => {
    if (error) {
      console.error(error);
      throw error;
    }
  }, [error]);

  useEffect(() => {
    if (loaded) {
      SplashScreen.hideAsync();
    }
  }, [loaded]);

  if (!loaded) {
    return null;
  }

  return (
    <ErrorBoundary>
      <trpc.Provider client={trpcClient} queryClient={queryClient}>
        <QueryClientProvider client={queryClient}>
          <RootLayoutNav />
        </QueryClientProvider>
      </trpc.Provider>
    </ErrorBoundary>
  );
}

function RootLayoutNav() {
  return (
    <Stack
      screenOptions={{
        headerBackTitle: "Back",
        headerStyle: {
          backgroundColor: Colors.white,
        },
        headerShadowVisible: false,
        headerTitleStyle: {
          fontWeight: "600",
          color: Colors.text.primary,
        },
        headerTintColor: Colors.primary,
      }}
    >
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen name="modal" options={{ presentation: "modal" }} />
      <Stack.Screen name="login" options={{ headerShown: true }} />
      <Stack.Screen name="signup" options={{ headerShown: true, title: "Sign Up" }} />
      <Stack.Screen name="professional/[id]" options={{ headerShown: true }} />
      <Stack.Screen name="booking/[id]" options={{ headerShown: true }} />
      <Stack.Screen name="booking/new" options={{ headerShown: true }} />
      <Stack.Screen name="booking/confirmation" options={{ headerShown: false }} />
      <Stack.Screen name="profile/personal-info" options={{ headerShown: true, title: "Personal Information" }} />
      <Stack.Screen name="profile/addresses" options={{ headerShown: true, title: "My Addresses" }} />
      <Stack.Screen name="profile/payment" options={{ headerShown: true, title: "Payment Methods" }} />
      <Stack.Screen name="profile/payment/add" options={{ headerShown: true, title: "Add Payment Method" }} />
      <Stack.Screen name="profile/notifications" options={{ headerShown: true, title: "Notifications" }} />
      <Stack.Screen name="profile/support" options={{ headerShown: true, title: "Help & Support" }} />
      <Stack.Screen name="profile/settings" options={{ headerShown: true, title: "Settings" }} />
      <Stack.Screen name="profile/edit" options={{ headerShown: true, title: "Edit Profile" }} />
    </Stack>
  );
}