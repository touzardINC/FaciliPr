import React, { useEffect, useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  FlatList,
  TouchableOpacity,
  SafeAreaView,
  ActivityIndicator,
} from "react-native";
import { useRouter } from "expo-router";
import Colors from "@/constants/colors";
import { useBookingStore } from "@/store/booking-store";
import { useAuthStore } from "@/store/auth-store";
import BookingCard from "@/components/BookingCard";
import { Booking, BookingStatus } from "@/types/booking";

export default function BookingsScreen() {
  const router = useRouter();
  const { user, isAuthenticated } = useAuthStore();
  const { bookings, getBookings, isLoading } = useBookingStore();
  const [activeTab, setActiveTab] = useState<BookingStatus | "all">("all");
  const [filteredBookings, setFilteredBookings] = useState<Booking[]>([]);

  useEffect(() => {
    if (isAuthenticated) {
      getBookings();
    }
  }, [isAuthenticated]);

  useEffect(() => {
    if (activeTab === "all") {
      setFilteredBookings(bookings);
    } else {
      setFilteredBookings(bookings.filter((booking) => booking.status === activeTab));
    }
  }, [bookings, activeTab]);

  const handleBookingPress = (booking: Booking) => {
    router.push({
      pathname: "/booking/[id]",
      params: { id: booking.id },
    });
  };

  if (!isAuthenticated) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyTitle}>Sign in to view your bookings</Text>
          <TouchableOpacity
            style={styles.signInButton}
            onPress={() => router.push("/login")}
          >
            <Text style={styles.signInButtonText}>Sign In</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>My Bookings</Text>
      </View>

      <View style={styles.tabsContainer}>
        <ScrollableTab
          tabs={[
            { id: "all", label: "All" },
            { id: "pending", label: "Pending" },
            { id: "confirmed", label: "Confirmed" },
            { id: "completed", label: "Completed" },
            { id: "cancelled", label: "Cancelled" },
          ]}
          activeTab={activeTab}
          onTabChange={setActiveTab}
        />
      </View>

      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={Colors.primary} />
          <Text style={styles.loadingText}>Loading your bookings...</Text>
        </View>
      ) : filteredBookings.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyTitle}>No bookings found</Text>
          <Text style={styles.emptyText}>
            {activeTab === "all"
              ? "You haven't made any bookings yet."
              : `You don't have any ${activeTab} bookings.`}
          </Text>
          <TouchableOpacity
            style={styles.bookButton}
            onPress={() => router.push("/")}
          >
            <Text style={styles.bookButtonText}>Find Services</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={filteredBookings}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <BookingCard booking={item} onPress={handleBookingPress} />
          )}
          contentContainerStyle={styles.bookingsList}
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  );
}

interface Tab {
  id: string;
  label: string;
}

interface ScrollableTabProps {
  tabs: Tab[];
  activeTab: string;
  onTabChange: (tabId: any) => void;
}

function ScrollableTab({ tabs, activeTab, onTabChange }: ScrollableTabProps) {
  return (
    <FlatList
      data={tabs}
      keyExtractor={(item) => item.id}
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.tabsList}
      renderItem={({ item }) => (
        <TouchableOpacity
          style={[
            styles.tab,
            activeTab === item.id && styles.activeTab,
          ]}
          onPress={() => onTabChange(item.id)}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === item.id && styles.activeTabText,
            ]}
          >
            {item.label}
          </Text>
        </TouchableOpacity>
      )}
    />
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
  },
  title: {
    fontSize: 24,
    fontWeight: "700",
    color: Colors.text.primary,
  },
  tabsContainer: {
    marginVertical: 16,
  },
  tabsList: {
    paddingHorizontal: 16,
  },
  tab: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    marginRight: 8,
    backgroundColor: Colors.white,
  },
  activeTab: {
    backgroundColor: Colors.primary,
  },
  tabText: {
    fontSize: 14,
    fontWeight: "500",
    color: Colors.text.secondary,
  },
  activeTabText: {
    color: Colors.white,
  },
  bookingsList: {
    paddingHorizontal: 16,
    paddingBottom: 24,
  },
  loadingContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingBottom: 40,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: Colors.text.secondary,
  },
  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 32,
    paddingBottom: 40,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.text.primary,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 14,
    color: Colors.text.secondary,
    textAlign: "center",
    marginBottom: 24,
  },
  bookButton: {
    backgroundColor: Colors.primary,
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 12,
  },
  bookButtonText: {
    color: Colors.white,
    fontWeight: "600",
    fontSize: 16,
  },
  signInButton: {
    backgroundColor: Colors.primary,
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 12,
    marginTop: 16,
  },
  signInButtonText: {
    color: Colors.white,
    fontWeight: "600",
    fontSize: 16,
  },
});