import React, { useState, useEffect } from "react";
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  FlatList,
  TouchableOpacity,
  Image,
  SafeAreaView,
} from "react-native";
import { useRouter } from "expo-router";
import { MapPin, Bell } from "lucide-react-native";
import Colors from "@/constants/colors";
import { categories } from "@/constants/categories";
import { professionals } from "@/mocks/professionals";
import { useAuthStore } from "@/store/auth-store";
import { useLocationStore } from "@/store/location-store";
import CategoryCard from "@/components/CategoryCard";
import ProfessionalCard from "@/components/ProfessionalCard";
import SearchBar from "@/components/SearchBar";
import { Category } from "@/types/category";
import { Professional } from "@/types/professional";

export default function HomeScreen() {
  const router = useRouter();
  const { user } = useAuthStore();
  const { savedLocations, currentLocation, getCurrentLocation } = useLocationStore();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [topProfessionals, setTopProfessionals] = useState<Professional[]>([]);
  const [nearbyProfessionals, setNearbyProfessionals] = useState<Professional[]>([]);
  const [userLocation, setUserLocation] = useState<string>("");
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);

  useEffect(() => {
    // Filter professionals by rating for top professionals
    const top = [...professionals]
      .sort((a, b) => b.rating - a.rating)
      .slice(0, 3);
    setTopProfessionals(top);

    // Filter professionals by distance for nearby professionals
    const nearby = [...professionals]
      .sort((a, b) => a.distance - b.distance)
      .slice(0, 3);
    setNearbyProfessionals(nearby);

    // Get user location
    fetchUserLocation();
  }, []);

  // Update user location when savedLocations or currentLocation changes
  useEffect(() => {
    if (savedLocations.length > 0) {
      const defaultLocation = savedLocations.find(loc => loc.isDefault);
      if (defaultLocation) {
        setUserLocation(defaultLocation.address);
      } else {
        setUserLocation(savedLocations[0].address);
      }
    } else if (currentLocation) {
      setUserLocation(currentLocation.address);
    }
  }, [savedLocations, currentLocation]);

  const fetchUserLocation = async () => {
    setIsLoadingLocation(true);
    try {
      await getCurrentLocation();
    } catch (error) {
      console.error("Error getting location:", error);
    } finally {
      setIsLoadingLocation(false);
    }
  };

  const handleCategoryPress = (category: Category) => {
    setSelectedCategory(category);
    router.push({
      pathname: "/search",
      params: { categoryId: category.id },
    });
  };

  const handleProfessionalPress = (professional: Professional) => {
    router.push({
      pathname: "/professional/[id]",
      params: { id: professional.id },
    });
  };

  const handleSearch = () => {
    router.push({
      pathname: "/search",
      params: { query: searchQuery },
    });
  };

  const handleLocationPress = () => {
    router.push("/profile/addresses");
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Hello, {user?.name?.split(" ")[0] || "Guest"}</Text>
            <TouchableOpacity 
              style={styles.locationContainer}
              onPress={handleLocationPress}
            >
              <MapPin size={16} color={Colors.primary} />
              <Text style={styles.location}>
                {isLoadingLocation ? "Getting location..." : userLocation || "Set your location"}
              </Text>
            </TouchableOpacity>
          </View>
          <TouchableOpacity style={styles.notificationButton}>
            <Bell size={24} color={Colors.text.primary} />
          </TouchableOpacity>
        </View>

        {/* Search Bar */}
        <View style={styles.searchBarContainer}>
          <SearchBar
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder="What service do you need?"
            onLocationPress={handleLocationPress}
            onClear={() => setSearchQuery("")}
          />
        </View>

        {/* Banner */}
        <View style={styles.bannerContainer}>
          <Image
            source={{
              uri: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
            }}
            style={styles.bannerImage}
          />
          <View style={styles.bannerContent}>
            <Text style={styles.bannerTitle}>Need a helping hand?</Text>
            <Text style={styles.bannerSubtitle}>
              Find trusted professionals for your home
            </Text>
            <TouchableOpacity
              style={styles.bannerButton}
              onPress={() => router.push("/search")}
            >
              <Text style={styles.bannerButtonText}>Find Services</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Categories */}
        <View style={styles.sectionContainer}>
          <Text style={styles.sectionTitle}>Categories</Text>
          <FlatList
            data={categories}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <CategoryCard
                category={item}
                onPress={handleCategoryPress}
                isSelected={selectedCategory?.id === item.id}
              />
            )}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.categoriesContainer}
          />
        </View>

        {/* Top Rated Professionals */}
        <View style={styles.sectionContainer}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Top Rated Professionals</Text>
            <TouchableOpacity onPress={() => router.push("/search")}>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          {topProfessionals.map((professional) => (
            <ProfessionalCard
              key={professional.id}
              professional={professional}
              onPress={handleProfessionalPress}
            />
          ))}
        </View>

        {/* Nearby Professionals */}
        <View style={styles.sectionContainer}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Nearby Professionals</Text>
            <TouchableOpacity onPress={() => router.push("/search")}>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          {nearbyProfessionals.map((professional) => (
            <ProfessionalCard
              key={professional.id}
              professional={professional}
              onPress={handleProfessionalPress}
            />
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContent: {
    paddingBottom: 24,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
  },
  greeting: {
    fontSize: 24,
    fontWeight: "700",
    color: Colors.text.primary,
    marginBottom: 4,
  },
  locationContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  location: {
    fontSize: 14,
    color: Colors.text.secondary,
    marginLeft: 4,
  },
  notificationButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.white,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: Colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  searchBarContainer: {
    paddingHorizontal: 16,
    marginTop: 16,
    marginBottom: 16,
  },
  bannerContainer: {
    marginHorizontal: 16,
    borderRadius: 16,
    overflow: "hidden",
    height: 160,
    marginBottom: 24,
  },
  bannerImage: {
    width: "100%",
    height: "100%",
    position: "absolute",
  },
  bannerContent: {
    flex: 1,
    backgroundColor: "rgba(15, 31, 19, 0.6)", // Dark Green with opacity
    padding: 16,
    justifyContent: "center",
  },
  bannerTitle: {
    fontSize: 22,
    fontWeight: "700",
    color: Colors.white,
    marginBottom: 8,
  },
  bannerSubtitle: {
    fontSize: 14,
    color: Colors.white,
    marginBottom: 16,
  },
  bannerButton: {
    backgroundColor: Colors.primary,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignSelf: "flex-start",
  },
  bannerButtonText: {
    color: Colors.white,
    fontWeight: "600",
    fontSize: 14,
  },
  sectionContainer: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.text.primary,
  },
  seeAllText: {
    fontSize: 14,
    color: Colors.primary,
    fontWeight: "600",
  },
  categoriesContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
});