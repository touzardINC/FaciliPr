import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  SafeAreaView,
  Image,
  TouchableOpacity,
  Alert,
} from "react-native";
import { useRouter } from "expo-router";
import { ChevronRight, Star, Shield, DollarSign, Clock, Users } from "lucide-react-native";
import Colors from "@/constants/colors";
import Button from "@/components/Button";
import { useAuthStore } from "@/store/auth-store";

export default function ApplyScreen() {
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();
  const [expanded, setExpanded] = useState<string | null>(null);

  const handleApply = () => {
    if (!isAuthenticated) {
      Alert.alert(
        "Sign In Required",
        "You need to sign in before applying as a professional.",
        [
          { text: "Cancel", style: "cancel" },
          { text: "Sign In", onPress: () => router.push("/login") }
        ]
      );
      return;
    }
    
    router.push("/apply/professional-details");
  };

  const toggleFAQ = (id: string) => {
    setExpanded(expanded === id ? null : id);
  };

  const faqs = [
    {
      id: "1",
      question: "How do I become a professional on the platform?",
      answer: "To become a professional, you need to complete the application process, which includes providing your personal information, professional details, and verification documents. Once approved, you can start offering your services."
    },
    {
      id: "2",
      question: "What are the fees for professionals?",
      answer: "We charge a 15% service fee on each booking. This fee covers payment processing, marketing, and platform maintenance. There are no monthly or subscription fees."
    },
    {
      id: "3",
      question: "How long does the approval process take?",
      answer: "The approval process typically takes 2-3 business days. We'll review your application, verify your credentials, and conduct a background check if necessary."
    },
    {
      id: "4",
      question: "Can I set my own prices and availability?",
      answer: "Yes, you have full control over your pricing and availability. You can set different prices for different services and update your availability calendar at any time."
    },
    {
      id: "5",
      question: "How do I get paid?",
      answer: "Payments are processed through our secure payment system. After a service is completed, the payment is released to your account within 2-3 business days. You can withdraw funds to your bank account at any time."
    }
  ];

  const benefits = [
    {
      icon: <Users size={24} color={Colors.primary} />,
      title: "Expand Your Client Base",
      description: "Reach thousands of potential clients looking for your services."
    },
    {
      icon: <Clock size={24} color={Colors.primary} />,
      title: "Flexible Schedule",
      description: "Work when you want, where you want. Set your own availability."
    },
    {
      icon: <DollarSign size={24} color={Colors.primary} />,
      title: "Boost Your Income",
      description: "Earn more by offering your services to a wider audience."
    },
    {
      icon: <Shield size={24} color={Colors.primary} />,
      title: "Secure Payments",
      description: "Get paid securely and on time, every time."
    },
    {
      icon: <Star size={24} color={Colors.primary} />,
      title: "Build Your Reputation",
      description: "Collect reviews and ratings to showcase your expertise."
    }
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={styles.title}>Become a Professional</Text>
          <Text style={styles.subtitle}>
            Join our platform and start growing your business today
          </Text>
        </View>

        <View style={styles.heroContainer}>
          <Image
            source={{ uri: "https://images.unsplash.com/photo-1560250097-0b93528c311a" }}
            style={styles.heroImage}
          />
          <View style={styles.heroOverlay}>
            <Text style={styles.heroTitle}>Share Your Expertise</Text>
            <Text style={styles.heroSubtitle}>
              Connect with clients looking for your skills
            </Text>
            <Button
              title="Apply Now"
              onPress={handleApply}
              style={styles.applyButton}
            />
          </View>
        </View>

        <View style={styles.sectionContainer}>
          <Text style={styles.sectionTitle}>Why Join Us?</Text>
          <View style={styles.benefitsContainer}>
            {benefits.map((benefit, index) => (
              <View key={index} style={styles.benefitItem}>
                <View style={styles.benefitIcon}>{benefit.icon}</View>
                <View style={styles.benefitContent}>
                  <Text style={styles.benefitTitle}>{benefit.title}</Text>
                  <Text style={styles.benefitDescription}>{benefit.description}</Text>
                </View>
              </View>
            ))}
          </View>
        </View>

        <View style={styles.sectionContainer}>
          <Text style={styles.sectionTitle}>How It Works</Text>
          <View style={styles.stepsContainer}>
            <View style={styles.step}>
              <View style={styles.stepNumber}>
                <Text style={styles.stepNumberText}>1</Text>
              </View>
              <View style={styles.stepContent}>
                <Text style={styles.stepTitle}>Apply</Text>
                <Text style={styles.stepDescription}>
                  Fill out the application form with your professional details
                </Text>
              </View>
            </View>
            <View style={styles.stepDivider} />
            <View style={styles.step}>
              <View style={styles.stepNumber}>
                <Text style={styles.stepNumberText}>2</Text>
              </View>
              <View style={styles.stepContent}>
                <Text style={styles.stepTitle}>Get Verified</Text>
                <Text style={styles.stepDescription}>
                  We'll review your application and verify your credentials
                </Text>
              </View>
            </View>
            <View style={styles.stepDivider} />
            <View style={styles.step}>
              <View style={styles.stepNumber}>
                <Text style={styles.stepNumberText}>3</Text>
              </View>
              <View style={styles.stepContent}>
                <Text style={styles.stepTitle}>Set Up Profile</Text>
                <Text style={styles.stepDescription}>
                  Create your profile, add services, and set your availability
                </Text>
              </View>
            </View>
            <View style={styles.stepDivider} />
            <View style={styles.step}>
              <View style={styles.stepNumber}>
                <Text style={styles.stepNumberText}>4</Text>
              </View>
              <View style={styles.stepContent}>
                <Text style={styles.stepTitle}>Start Earning</Text>
                <Text style={styles.stepDescription}>
                  Accept bookings and grow your business
                </Text>
              </View>
            </View>
          </View>
        </View>

        <View style={styles.sectionContainer}>
          <Text style={styles.sectionTitle}>Frequently Asked Questions</Text>
          <View style={styles.faqContainer}>
            {faqs.map((faq) => (
              <TouchableOpacity
                key={faq.id}
                style={styles.faqItem}
                onPress={() => toggleFAQ(faq.id)}
                activeOpacity={0.7}
              >
                <View style={styles.faqHeader}>
                  <Text style={styles.faqQuestion}>{faq.question}</Text>
                  <ChevronRight
                    size={20}
                    color={Colors.text.secondary}
                    style={[
                      styles.faqIcon,
                      expanded === faq.id && styles.faqIconExpanded,
                    ]}
                  />
                </View>
                {expanded === faq.id && (
                  <Text style={styles.faqAnswer}>{faq.answer}</Text>
                )}
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.ctaContainer}>
          <Text style={styles.ctaTitle}>Ready to Get Started?</Text>
          <Text style={styles.ctaSubtitle}>
            Join thousands of professionals already growing their business with us
          </Text>
          <Button
            title="Apply as a Professional"
            onPress={handleApply}
            style={styles.ctaButton}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
  },
  title: {
    fontSize: 24,
    fontWeight: "700",
    color: Colors.text.primary,
  },
  subtitle: {
    fontSize: 16,
    color: Colors.text.secondary,
    marginTop: 4,
  },
  heroContainer: {
    position: "relative",
    height: 200,
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 16,
    overflow: "hidden",
  },
  heroImage: {
    width: "100%",
    height: "100%",
  },
  heroOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "rgba(0, 0, 0, 0.4)",
    padding: 16,
    justifyContent: "flex-end",
  },
  heroTitle: {
    fontSize: 24,
    fontWeight: "700",
    color: Colors.white,
    marginBottom: 4,
  },
  heroSubtitle: {
    fontSize: 16,
    color: Colors.white,
    marginBottom: 16,
  },
  applyButton: {
    alignSelf: "flex-start",
  },
  sectionContainer: {
    marginTop: 24,
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: Colors.text.primary,
    marginBottom: 16,
  },
  benefitsContainer: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 16,
    shadowColor: Colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  benefitItem: {
    flexDirection: "row",
    marginBottom: 16,
  },
  benefitIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.background,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 12,
  },
  benefitContent: {
    flex: 1,
  },
  benefitTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.text.primary,
    marginBottom: 4,
  },
  benefitDescription: {
    fontSize: 14,
    color: Colors.text.secondary,
  },
  stepsContainer: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 16,
    shadowColor: Colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  step: {
    flexDirection: "row",
    alignItems: "flex-start",
  },
  stepNumber: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.primary,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 12,
  },
  stepNumberText: {
    fontSize: 16,
    fontWeight: "700",
    color: Colors.white,
  },
  stepContent: {
    flex: 1,
  },
  stepTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.text.primary,
    marginBottom: 4,
  },
  stepDescription: {
    fontSize: 14,
    color: Colors.text.secondary,
  },
  stepDivider: {
    height: 16,
    width: 1,
    backgroundColor: Colors.border,
    marginLeft: 16,
    marginVertical: 4,
  },
  faqContainer: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    overflow: "hidden",
    shadowColor: Colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  faqItem: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  faqHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  faqQuestion: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.text.primary,
    flex: 1,
  },
  faqIcon: {
    marginLeft: 8,
    transform: [{ rotate: "0deg" }],
  },
  faqIconExpanded: {
    transform: [{ rotate: "90deg" }],
  },
  faqAnswer: {
    fontSize: 14,
    color: Colors.text.secondary,
    marginTop: 8,
    lineHeight: 20,
  },
  ctaContainer: {
    marginTop: 24,
    marginHorizontal: 16,
    backgroundColor: Colors.primary,
    borderRadius: 16,
    padding: 24,
    alignItems: "center",
    marginBottom: 32,
  },
  ctaTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: Colors.white,
    marginBottom: 8,
    textAlign: "center",
  },
  ctaSubtitle: {
    fontSize: 14,
    color: Colors.white,
    marginBottom: 16,
    textAlign: "center",
    opacity: 0.9,
  },
  ctaButton: {
    backgroundColor: Colors.white,
  },
});