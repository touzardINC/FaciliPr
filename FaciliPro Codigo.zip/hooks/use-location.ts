import { useState, useEffect } from "react";
import * as Location from "expo-location";
import { Alert, Platform } from "react-native";

interface LocationData {
  latitude: number;
  longitude: number;
  address: string;
}

export function useLocation() {
  const [location, setLocation] = useState<LocationData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);

  useEffect(() => {
    checkPermissions();
  }, []);

  const checkPermissions = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      setHasPermission(status === "granted");
      
      if (status !== "granted") {
        setErrorMsg("Permission to access location was denied");
      }
    } catch (error) {
      setErrorMsg("Error checking location permissions");
      setHasPermission(false);
    }
  };

  const getCurrentLocation = async () => {
    if (Platform.OS === "web") {
      // For web, use the browser's geolocation API
      if (!navigator.geolocation) {
        setErrorMsg("Geolocation is not supported by this browser");
        return;
      }

      setIsLoading(true);
      setErrorMsg(null);

      try {
        const position = await new Promise<GeolocationPosition>((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject, {
            enableHighAccuracy: true,
            timeout: 15000,
            maximumAge: 10000,
          });
        });

        // For web, we don't have reverse geocoding, so we'll just use coordinates
        setLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          address: `${position.coords.latitude.toFixed(6)}, ${position.coords.longitude.toFixed(6)}`,
        });
      } catch (error) {
        setErrorMsg("Failed to get location");
        Alert.alert("Error", "Failed to get your location. Please try again.");
      } finally {
        setIsLoading(false);
      }
      return;
    }

    // For native platforms
    if (!hasPermission) {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        setErrorMsg("Permission to access location was denied");
        Alert.alert(
          "Permission Required",
          "Please enable location services to use this feature"
        );
        return;
      }
      setHasPermission(true);
    }

    setIsLoading(true);
    setErrorMsg(null);

    try {
      const locationResult = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });

      // Reverse geocode to get address
      const addressResponse = await Location.reverseGeocodeAsync({
        latitude: locationResult.coords.latitude,
        longitude: locationResult.coords.longitude,
      });

      let address = "Unknown location";
      if (addressResponse && addressResponse.length > 0) {
        const addressObj = addressResponse[0];
        address = `${addressObj.street || ""} ${addressObj.name || ""}, ${
          addressObj.city || ""
        }, ${addressObj.region || ""}, ${addressObj.country || ""}`.trim();
      }

      setLocation({
        latitude: locationResult.coords.latitude,
        longitude: locationResult.coords.longitude,
        address,
      });
    } catch (error) {
      setErrorMsg("Could not fetch location. Please try again.");
      Alert.alert("Error", "Failed to get your location. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return {
    location,
    isLoading,
    errorMsg,
    hasPermission,
    getCurrentLocation,
  };
}