import { Category } from "@/types/category";

export const categories: Category[] = [
  // Very Dark Green (#0F1F13) categories
  {
    id: "3",
    name: "Electrical",
    icon: "zap",
    description: "Wiring, installations, and electrical repairs",
    color: "#0F1F13", // Very Dark Green
  },
  {
    id: "11",
    name: "Academics",
    icon: "book-open",
    description: "Tutoring, teaching, and educational services",
    color: "#0F1F13", // Very Dark Green
  },
  
  // Dark Forest Green (#2D4A33) categories
  {
    id: "1",
    name: "Plumbing",
    icon: "droplet",
    description: "Pipe repairs, installations, and maintenance",
    color: "#2D4A33", // Dark Forest Green
  },
  {
    id: "2",
    name: "Gardening",
    icon: "flower",
    description: "Lawn care, landscaping, and plant maintenance",
    color: "#2D4A33", // Dark Forest Green
  },
  {
    id: "8",
    name: "Mechanic",
    icon: "wrench",
    description: "Vehicle repair and maintenance services",
    color: "#2D4A33", // Dark Forest Green
  },
  
  // Medium Green (#4A6C4A) categories
  {
    id: "4",
    name: "Cleaning",
    icon: "spray-can",
    description: "Home cleaning, disinfection, and organization",
    color: "#4A6C4A", // Medium Green
  },
  {
    id: "7",
    name: "Catering",
    icon: "utensils",
    description: "Food preparation and service for events",
    color: "#4A6C4A", // Medium Green
  },
  {
    id: "12",
    name: "Beauty",
    icon: "scissors",
    description: "Hair styling, makeup, and beauty treatments",
    color: "#4A6C4A", // Medium Green
  },
  
  // Lighter Medium Green (#6A8E6A) categories
  {
    id: "5",
    name: "Carpentry",
    icon: "hammer",
    description: "Furniture repair, woodwork, and installations",
    color: "#6A8E6A", // Lighter Medium Green
  },
  {
    id: "6",
    name: "Painting",
    icon: "paintbrush",
    description: "Interior and exterior painting services",
    color: "#6A8E6A", // Lighter Medium Green
  },
  
  // Light Green (#9ABE9A) categories
  {
    id: "9",
    name: "Entertainment",
    icon: "music",
    description: "Music, performances, and event entertainment",
    color: "#9ABE9A", // Light Green
  },
  {
    id: "10",
    name: "Decorating",
    icon: "palette",
    description: "Interior design and event decoration services",
    color: "#9ABE9A", // Light Green
  },
];