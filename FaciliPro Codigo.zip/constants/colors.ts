const Colors = {
  primary: "#4A6C4A", // Medium Green
  secondary: "#9ABE9A", // Light Green
  accent: "#2D4A33", // Dark Forest Green
  
  background: "#F8F9FA", // Light Gray Background
  white: "#FFFFFF",
  black: "#000000",
  
  text: {
    primary: "#1A1A1A", // Almost Black
    secondary: "#6C757D", // Medium Gray
    light: "#ADB5BD", // Light Gray
    placeholder: "#CED4DA", // Lighter Gray for placeholders
  },
  
  success: "#28A745", // Green
  error: "#DC3545", // Red
  warning: "#FFC107", // Yellow
  info: "#17A2B8", // Teal
  
  gray: {
    100: "#F8F9FA",
    200: "#E9ECEF",
    300: "#DEE2E6",
    400: "#CED4DA",
    500: "#ADB5BD",
    600: "#6C757D",
    700: "#495057",
    800: "#343A40",
    900: "#212529",
  },
  
  green: {
    100: "#E8F5E9",
    200: "#C8E6C9",
    300: "#A5D6A7",
    400: "#81C784",
    500: "#66BB6A",
    600: "#4CAF50",
    700: "#43A047",
    800: "#388E3C",
    900: "#2E7D32",
  },
  
  shadow: "rgba(0, 0, 0, 0.1)",
  overlay: "rgba(0, 0, 0, 0.5)",
  border: "#DEE2E6", // Same as gray.300 for consistency
  
  // Category colors (from dark to light)
  categories: {
    darkest: "#0F1F13", // Very Dark Green
    dark: "#2D4A33", // Dark Forest Green
    medium: "#4A6C4A", // Medium Green
    light: "#6A8E6A", // Lighter Medium Green
    lightest: "#9ABE9A", // Light Green
  },
};

export default Colors;