export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  avatar?: string;
  bio?: string;
  dateOfBirth?: string;
  gender?: string;
  addresses?: Address[];
  isProfessional?: boolean;
  professionalDetails?: ProfessionalDetails;
}

export interface Address {
  id: string;
  name: string;
  street: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  isDefault: boolean;
  latitude?: number;
  longitude?: number;
}

export interface ProfessionalDetails {
  businessName: string;
  category: string;
  bio: string;
  experience: string;
  portfolio: string[];
  services: Service[];
  socialMedia: SocialMedia[];
  availability: Availability;
  rating: number;
  reviewCount: number;
  verified: boolean;
}

export interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
  duration: number;
}

export interface SocialMedia {
  platform: string;
  url: string;
  username?: string;
}

export interface Availability {
  weekdays: {
    monday: boolean;
    tuesday: boolean;
    wednesday: boolean;
    thursday: boolean;
    friday: boolean;
    saturday: boolean;
    sunday: boolean;
  };
  startTime: string;
  endTime: string;
  travelDistance: number;
  inHomeServices: boolean;
}