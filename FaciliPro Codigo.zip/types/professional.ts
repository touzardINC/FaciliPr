export interface ServiceMedia {
  id: string;
  type: "image" | "video";
  url: string;
  thumbnailUrl?: string;
  duration?: number; // For videos
}

export interface Service {
  id: string;
  name: string;
  price: number;
  description?: string;
  imageUrl?: string; // Legacy support
  media?: ServiceMedia[]; // New field for multiple images and videos
  duration?: string;
}

export interface SocialMedia {
  platform: "instagram" | "facebook" | "twitter" | "linkedin" | "youtube" | "tiktok" | "website" | "pinterest" | "soundcloud" | "github";
  url: string;
  username?: string;
}

export interface ReviewMedia {
  id: string;
  type: "image" | "video";
  url: string;
  thumbnailUrl?: string;
  duration?: number; // For videos
}

export interface Review {
  id: string;
  userId: string;
  rating: number;
  comment: string;
  date: string;
  images?: ReviewMedia[]; // Updated to support both images and videos
}

export interface Professional {
  id: string;
  name: string;
  categoryId: string;
  avatar: string;
  rating: number;
  reviewCount: number;
  hourlyRate: number;
  description: string;
  location: string;
  distance: number;
  available: boolean;
  services: Service[];
  reviews: Review[];
  socialMedia?: SocialMedia[]; // Added social media links
}