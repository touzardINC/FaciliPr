export type PaymentMethodType = "credit_card" | "debit_card" | "paypal";

export interface PaymentMethod {
  id: string;
  type: PaymentMethodType;
  name: string;
  last4: string;
  expiryDate?: string;
  isDefault: boolean;
  brand?: string;
  icon?: string;
}

export interface Transaction {
  id: string;
  userId: string;
  bookingId: string;
  amount: number;
  currency: string;
  status: "pending" | "completed" | "failed" | "refunded";
  paymentMethodId: string;
  createdAt: string;
  updatedAt: string;
}