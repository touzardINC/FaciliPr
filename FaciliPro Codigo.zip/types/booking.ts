export type BookingStatus = "pending" | "confirmed" | "completed" | "cancelled";

export interface BookingReview {
  rating: number;
  comment: string;
  date: string;
}

export interface Booking {
  id: string;
  userId: string;
  professionalId: string;
  serviceId: string;
  date: string;
  time: string;
  status: BookingStatus;
  price: number;
  address: string;
  notes?: string;
  createdAt: string;
  review?: BookingReview;
}